import { createEndpoint, createRouter, defineRoom, defineServer, matchMaker } from 'colyseus';
import { WebSocketTransport } from '@colyseus/ws-transport';
import { RoyaleRoom } from './rooms/RoyaleRoom.js';

const PORT = Number(process.env.PORT || 2567);
const HOST = process.env.HOST || '0.0.0.0';

const gameServer = defineServer({
  rooms: { royale: defineRoom(RoyaleRoom) },
  transport: new WebSocketTransport(),
  routes: createRouter({
    health: createEndpoint('/health', { method: 'GET' }, async () => ({
      ok: true,
      service: 'retardados-royale-colyseus',
      rooms: 'available'
    })),
    publicRooms: createEndpoint('/rooms/royale', { method: 'GET' }, async () => {
      // Colyseus 0.16+ removed Client.getAvailableRooms(). Query only unlocked public rooms server-side.
      const rooms = await matchMaker.query({ name: 'royale', locked: false, private: false });
      return rooms
        .filter((room) => Number(room.clients ?? 0) < Number(room.maxClients ?? 8))
        .map((room) => ({
          roomId: room.roomId,
          clients: room.clients,
          maxClients: room.maxClients,
          metadata: room.metadata ?? {}
        }));
    })
  })
});

gameServer.listen(PORT, HOST).then(() => {
  console.log(`Retardados Royale multiplayer server listening on ${HOST}:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
}).catch((error) => {
  console.error('Failed to start the Colyseus server:', error);
  process.exitCode = 1;
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, async () => {
    console.log(`Received ${signal}; shutting down Colyseus...`);
    try { await gameServer.gracefullyShutdown(false); }
    catch (error) { console.error('Graceful shutdown failed:', error); }
    finally { process.exit(0); }
  });
}
