import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
import { Client } from '@colyseus/sdk';

const endpoint = process.env.MULTIPLAYER_TEST_ENDPOINT || 'http://127.0.0.1:2567';
async function waitFor(predicate, description, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await delay(50);
  }
  throw new Error(`Timeout esperando: ${description}`);
}

const clientA = new Client(endpoint);
const clientB = new Client(endpoint);
async function getPublicRooms(client) {
  const response = await client.http.get('/rooms/royale');
  return Array.isArray(response?.data) ? response.data : (Array.isArray(response) ? response : []);
}
let roomA, roomB, privateRoom;
let lastA, lastB;
try {
  roomA = await clientA.create('royale', { nickname: 'TEST_A', characterId: 'enzo', visibility: 'public' });
  roomA.onMessage('snapshot', (snapshot) => { lastA = snapshot; });

  const firstListing = await getPublicRooms(clientB);
  const publicListingEntry = firstListing.find((item) => item.roomId === roomA.roomId);
  assert.ok(publicListingEntry, 'sala pública deve aparecer no navegador de salas');
  assert.equal(Number(publicListingEntry.maxClients), 8, 'o limite da sala deve ser de oito jogadores');
  assert.equal(Number(publicListingEntry.metadata?.maxPlayers), 8, 'o metadado deve anunciar o limite de oito jogadores');

  privateRoom = await clientA.create('royale', { nickname: 'TEST_PRIVATE', characterId: 'enzo', visibility: 'private' });
  const listingWithPrivate = await getPublicRooms(clientB);
  assert.ok(!listingWithPrivate.some((item) => item.roomId === privateRoom.roomId), 'sala privada não deve aparecer na lista pública');

  roomB = await clientB.joinById(roomA.roomId, { nickname: 'TEST_B', characterId: 'luan' });
  roomB.onMessage('snapshot', (snapshot) => { lastB = snapshot; });

  await waitFor(() => lastA?.players?.length === 2 && lastB?.players?.length === 2, 'dois clientes na mesma sala');
  assert.equal(roomA.roomId, roomB.roomId, 'os dois clientes devem estar na mesma sala');
  assert.ok(lastA.players.some((p) => p.sessionId === roomA.sessionId));
  assert.ok(lastA.players.some((p) => p.sessionId === roomB.sessionId));
  assert.ok(lastA.players.find((p) => p.sessionId === roomB.sessionId)?.characterId === 'luan', 'o personagem escolhido deve ser sincronizado');

  const before = lastA.players.find((p) => p.sessionId === roomA.sessionId);
  for (let i = 0; i < 16; i++) {
    roomA.send('input', { forward: 1, right: 0, yaw: 0, run: false, jump: false });
    await delay(50);
  }
  await waitFor(() => {
    const p = lastA?.players?.find((item) => item.sessionId === roomA.sessionId);
    return p && Math.hypot(p.x - before.x, p.z - before.z) > 0.6;
  }, 'movimento validado pelo servidor e recebido no snapshot');

  await roomB.leave();
  roomB = null;
  await waitFor(() => lastA?.players?.length === 1, 'remoção do jogador que desconectou');
  console.log(`PASS: a sala pública ${roomA.roomId} apareceu na lista, a sala privada ficou oculta, dois clientes sincronizaram movimento e a desconexão foi removida.`);
} finally {
  await Promise.allSettled([roomA?.leave(), roomB?.leave(), privateRoom?.leave()]);
}
