import test from 'node:test';
import assert from 'node:assert/strict';
import { generateArenaLayout, isBlocked } from '../../RetardadosRoyale_Web_v6/shared/arena-layout.js';

test('arena generation is deterministic for the same seed', () => {
  const a = generateArenaLayout(123456);
  const b = generateArenaLayout(123456);
  assert.deepEqual(a, b);
  assert.equal(a.obstacles.length, b.obstacles.length);
});

test('spawn area remains clear and boundaries are enforced', () => {
  const layout = generateArenaLayout(123456);
  assert.equal(isBlocked(layout, 0, 0), false);
  assert.equal(isBlocked(layout, 254, 0), true);
});
