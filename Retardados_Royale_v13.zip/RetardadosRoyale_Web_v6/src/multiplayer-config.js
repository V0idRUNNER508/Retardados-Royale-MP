// In local development the client connects to the local Colyseus server.
// Before publishing multiplayer publicly, set this to your persistent Node host URL,
// e.g. 'https://your-colyseus-host.example.com'. HTTPS is upgraded to secure WebSockets by the SDK.
export const COLYSEUS_ENDPOINT = '';

export function getColyseusEndpoint() {
  if (typeof COLYSEUS_ENDPOINT === 'string' && COLYSEUS_ENDPOINT.trim()) {
    return COLYSEUS_ENDPOINT.trim().replace(/\/$/, '');
  }
  const host = globalThis.location?.hostname || '';
  if (host === 'localhost' || host === '127.0.0.1' || host === '::1') return 'http://localhost:2567';
  return '';
}
