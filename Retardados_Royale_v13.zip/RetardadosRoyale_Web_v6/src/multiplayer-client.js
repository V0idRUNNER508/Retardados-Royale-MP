import { getColyseusEndpoint } from './multiplayer-config.js';

const SDK_CDNS = [
  'https://esm.sh/@colyseus/sdk@0.18.8?bundle',
  'https://cdn.jsdelivr.net/npm/@colyseus/sdk@0.18.8/+esm'
];
let sdkPromise;
let clientInstance;

async function loadSdk() {
  if (!sdkPromise) {
    sdkPromise = Promise.any(SDK_CDNS.map(async (url) => {
      const mod = await import(url);
      if (typeof mod.Client !== 'function') throw new Error(`Colyseus SDK inválido em ${url}`);
      return mod;
    })).catch((error) => {
      sdkPromise = null;
      throw new Error(`Não foi possível carregar o SDK Colyseus. Verifique sua conexão e o acesso a esm.sh/jsDelivr. ${error?.message || ''}`);
    });
  }
  return sdkPromise;
}

async function getClient() {
  const endpoint = getColyseusEndpoint();
  if (!endpoint) {
    throw new Error('O servidor multiplayer ainda não foi configurado. Edite src/multiplayer-config.js e informe o endereço HTTPS do servidor Colyseus publicado.');
  }
  const { Client } = await loadSdk();
  if (!clientInstance || clientInstance.endpoint !== endpoint) clientInstance = new Client(endpoint);
  return clientInstance;
}

export async function createPrivateRoom(options = {}) {
  const client = await getClient();
  return client.create('royale', { ...options, visibility: 'private' });
}

export async function createPublicRoom(options = {}) {
  const client = await getClient();
  return client.create('royale', { ...options, visibility: 'public' });
}

export async function listPublicRooms() {
  const client = await getClient();
  const response = await client.http.get('/rooms/royale');
  const rooms = Array.isArray(response?.data) ? response.data : (Array.isArray(response) ? response : []);
  // The backend endpoint returns only public rooms with spare slots.
  return rooms.filter((room) => {
    const players = Number(room.clients ?? room.metadata?.playerCount ?? 0);
    const maximum = Number(room.maxClients ?? room.metadata?.maxPlayers ?? 8);
    return players < maximum;
  });
}

export async function joinRoomByCode(roomId, options = {}) {
  const client = await getClient();
  return client.joinById(String(roomId).trim(), options);
}

// Backwards-compatible name for existing code that joins private rooms by invite code.
export async function joinPrivateRoom(roomId, options) {
  return joinRoomByCode(roomId, options);
}

export function leaveRoom(room) {
  if (!room) return Promise.resolve();
  try { return Promise.resolve(room.leave()); }
  catch (error) { return Promise.reject(error); }
}
