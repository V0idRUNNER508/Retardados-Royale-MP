# Retardados Royale — atualização v6: códigos de resgate e Vincent

## Nova interface de códigos
- Adicionada às **Configurações** uma caixa para digitar códigos de recompensa.
- O texto é convertido para MAIÚSCULAS ao digitar ou colar conteúdo.
- O botão **RESGATAR** aceita `VINCENT069`. Pressionar Enter dentro do campo também resgata.
- Códigos vazios, inválidos ou já usados apresentam mensagens explicativas.
- Após o resgate, aparece um botão para abrir diretamente a seleção de personagens.

## Personagem Vincent
- Vincent fica bloqueado até o código correto ser resgatado.
- Ao desbloquear, aparece em **PERSONAGENS** e pode ser selecionado.
- Modelo 3D low-poly original: pele clara, cabelo loiro longo, bagunçado e volumoso, camiseta preta e calça jeans azul.
- O desbloqueio é persistido em `localStorage`. É local ao navegador/origem e não sincroniza entre aparelhos.

## Publicação
Extraia o ZIP e publique o conteúdo desta pasta no Netlify, substituindo a versão anterior. Preserve `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`. O cache PWA foi atualizado para v6.

## Validação
Verificação estática de sintaxe e referências da interface; a partida 3D completa ainda precisa de teste no navegador publicado com WebGL ativo.
