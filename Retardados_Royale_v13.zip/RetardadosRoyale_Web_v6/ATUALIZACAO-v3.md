# Atualização v3 — Retardados Royale Web

## Mudanças incluídas

- O título/logotipo de Retardados Royale fica oculto durante a partida e aparece novamente no menu.
- O guia grande de teclas foi removido da HUD. As dicas compactas ficam nas Preferências Rápidas do menu principal e podem ser ocultadas em Configurações.
- Há seletor de plataforma **COMPUTADOR / MOBILE** no menu principal. O modo MOBILE força a exibição do joystick e dos botões independentemente de a largura da tela ultrapassar 700 px, resolvendo o caso típico do celular em paisagem.
- Há seletor de câmera **3ª PESSOA / 1ª PESSOA** no menu e botão para alternar a perspectiva durante a partida.
- Foram acrescentados modelos geométricos 3D originais para as armas de combate, equipados nos personagens/bots e uma versão de arma/ braço posicionada na câmera para a primeira pessoa.
- O cache do service worker foi atualizado para v3, para que o navegador substitua os arquivos antigos após a publicação.

## Publicar esta atualização

1. Descompacte `RetardadosRoyale_Atualizado_Web.zip`.
2. Abra a pasta `RetardadosRoyale_Web`.
3. Envie o **conteúdo da pasta** ao mesmo site já existente no Netlify, substituindo a versão anterior. Mantenha as subpastas `src` e `icons`.
4. Abra o site publicado. Se o cache antigo persistir, feche a aba e abra de novo. Como alternativa, limpe os dados do site no navegador e recarregue.

O pacote não publica diretamente na conta Netlify: é necessário fazer o novo deploy pelo painel/fluxo usado para publicar a versão anterior.

## Testes efetuados nesta entrega

- Sintaxe JavaScript verificada com `node --check`.
- Todos os IDs HTML referenciados estaticamente pela lógica principal foram encontrados.
- Integridade do arquivo ZIP verificada.
- O teste automatizado de renderização 3D não pôde ser concluído neste ambiente devido a uma falha do Chromium local ao iniciar o WebGL. Portanto, faça uma partida de teste após publicar, especialmente a troca de câmera e o HUD em mobile horizontal.
