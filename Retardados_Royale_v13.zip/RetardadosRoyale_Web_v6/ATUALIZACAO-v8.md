# Retardados Royale — correção v8

## Correção principal

A versão anterior tinha perdido a definição de `saveSettings`/`syncSettings` e outras funções chamadas pelo menu, incluindo as rotinas de plataforma/câmera e renderização da Loja, Inventário e Estatísticas. Isso podia interromper a inicialização do módulo com `SaveSettings is not defined` (ou erros consecutivos).

## O que foi restaurado

- Salvamento e restauração das configurações de qualidade, volume, sensibilidade, inversão vertical e dicas.
- Alias `SaveSettings()` por compatibilidade com o nome capitalizado do erro reportado.
- Seleção funcional de Computador/Mobile e primeira/terceira pessoa no menu e na HUD.
- Eventos de navegação do menu, seleção de personagem e edição de nickname.
- Renderização das telas Loja, Inventário/Arsenal e Estatísticas.
- Cache do service worker atualizado para v8.

## Publicação

Publique o conteúdo desta pasta na raiz do site Netlify, mantendo `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`. Após publicar, feche e reabra o site ou limpe os dados/cache do aplicativo instalado.

## Verificações

A sintaxe do JavaScript foi verificada com Node.js e os IDs utilizados pelas novas ligações foram conferidos no HTML. Não foi possível executar uma sessão 3D completa neste ambiente, então os menus e a partida ainda devem ser conferidos no navegador após a publicação.
