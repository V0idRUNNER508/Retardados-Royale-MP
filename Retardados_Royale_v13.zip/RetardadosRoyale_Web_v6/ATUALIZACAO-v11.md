# Retardados Royale — atualização v11: Verity

## Novo item especial
- Verity é um item quase-raro que surge em posição aleatória durante a partida. A primeira aparição ocorre após um atraso aleatório; aparições seguintes têm intervalo aleatório prolongado. Só pode existir uma Verity de chão por vez e uma unidade no chão desaparece depois de um tempo se ninguém a recolher.
- O modelo 3D dourado é identificável no mundo e marcado em amarelo no minimapa.
- Cada coleta dá ao jogador uma unidade consumível. Cada unidade permite exatamente um arremesso.
- No computador, pressione **G** para arremessar. No mobile, o botão **✹ V ×N** aparece quando você tem ao menos uma unidade.
- Quando toca o chão, Verity cria várias faíscas amarelas, uma onda visual expansiva e uma força radial de empurrão que pode lançar NPCs e jogadores próximos para longe.
- Verity não causa dano direto nesta versão; seu efeito principal é deslocamento/controle de área. NPCs não coletam esse item para não desperdiçá-lo.
- A seção Inventário explica o funcionamento do item.

## Publicação
Publique o conteúdo desta pasta na raiz do Netlify, preservando `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`. O cache PWA foi atualizado para v11.

## Verificação
Sintaxe JavaScript e estrutura do pacote verificadas. O jogo ainda precisa ser testado no navegador publicado para avaliar o equilíbrio do impulso e a apresentação visual no dispositivo final.
