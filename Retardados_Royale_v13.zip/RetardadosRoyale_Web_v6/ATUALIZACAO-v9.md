# Retardados Royale — Atualização v9 (controles Mobile)

## Correções

- O salto do Mobile agora é acionado pelo evento `pointerdown` do botão PULAR, com prevenção de ações padrão do navegador; há fallback para ativação por teclado/acessibilidade.
- O tiro no Mobile é exclusivo do botão ATIRAR. Toques na arena não podem ativar o disparo por eventos de mouse sintetizados; a tecla F e o mouse permanecem disponíveis no modo Computador.
- O botão E inicia oculto e só aparece enquanto houver um item coletável ao alcance do jogador. Ele fica logo acima do botão ATIRAR, com rótulo acessível e ação de coleta por toque.
- Eventos de toque usam captura e limpeza por `pointerup`/`pointercancel` para reduzir falhas de controles em orientação horizontal.
- O cache do PWA foi atualizado para `retardados-royale-web-v9`.

## Publicação

Publique o conteúdo desta pasta na raiz do site Netlify, substituindo os arquivos anteriores. Preserve `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`.

## Verificação

Sintaxe JavaScript e referências de IDs do HTML foram verificadas. Um teste visual real em navegador móvel não pôde ser executado neste ambiente; teste o botão PULAR, o botão ATIRAR e a aparição contextual do E depois de publicar.
