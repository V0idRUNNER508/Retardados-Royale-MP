# Retardados Royale — Atualização v10

## Armaduras e escudo

- Adicionados capacetes, peitorais, botas/calçados e sapatos blindados, com variantes reforçadas.
- Cada peça aumenta o escudo máximo. A HUD mostra escudo atual/máximo e ajusta a barra à capacidade real.
- Os modelos 3D das peças aparecem no personagem e as armaduras possuem modelos próprios quando estão no chão.
- Armaduras aparecem como loot inicial e podem surgir ocasionalmente durante a partida.
- Cerca de 39% dos NPCs surgem com uma ou mais peças aleatórias; ao serem eliminados, derrubam as armaduras que estavam usando.
- O jogador pode substituir uma peça por outra melhor; a peça retirada cai no chão para manter o loot consistente.
- A aba Inventário agora inclui uma galeria com todas as armaduras e seus bônus de escudo.

## Ajustes adicionais

- A geração de carros passou de um novo veículo a cada 5 minutos para aproximadamente 4 minutos, com limite de 3 veículos simultâneos (antes 2). Os veículos continuam desaparecendo depois de 6 minutos.
- Corrigido o sentido horizontal da câmera no toque e no mouse: arrastar para a esquerda gira a câmera para a esquerda e arrastar para a direita gira para a direita, tanto em primeira quanto em terceira pessoa.
- Cache PWA atualizado para `retardados-royale-web-v10`.

## Publicação

Publique o conteúdo desta pasta na raiz do seu site Netlify, substituindo os arquivos anteriores. Preserve `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`.

## Verificação

A sintaxe dos módulos JavaScript e a integridade do ZIP foram verificadas. O teste visual de uma partida completa não foi possível neste ambiente; confirme os modelos e controles depois de publicar.
