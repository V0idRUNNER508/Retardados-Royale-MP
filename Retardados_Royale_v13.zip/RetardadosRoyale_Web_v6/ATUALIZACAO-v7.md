# Retardados Royale — correção v7

## O que mudou
- Adicionados seis provedores de fallback para o Three.js.
- O carregamento do motor 3D tem timeout de 20 segundos e verifica se a resposta exporta a API esperada.
- A tela de falha agora verifica se `src/game.js` está publicado e diferencia diretório de publicação incorreto de erro no motor 3D/inicialização.
- Mensagens de diagnóstico mostram uma causa provável e instruções do Netlify sem expor stack trace completo na interface.
- Service worker atualizado para cache v7.

## Publicação correta no Netlify
Publique o conteúdo da pasta `RetardadosRoyale_Web_v6` (ou a pasta renomeada que contém `index.html`, `src/`, `style.css`, `icons/`, `manifest.webmanifest` e `service-worker.js`). Não publique apenas o `index.html` nem deixe uma pasta extra como diretório raiz do site.

## Limitação conhecida
O Three.js continua sendo carregado por provedores públicos externos; por isso a primeira inicialização ainda necessita de conexão com a internet e WebGL. Uma distribuição totalmente offline exigiria incluir uma cópia local licenciada da biblioteca no ZIP.
