# Retardados Royale — Atualização v4

## Correções e novidades

- Mira por gesto global no mobile, em primeira e terceira pessoa.
- Controles mobile expostos e reposicionados em paisagem, incluindo botão **ATIRAR** grande.
- Disparo no computador por clique esquerdo ou tecla **F**; câmera pelo mouse/captura de cursor, com arraste por botão direito ou meio como alternativa.
- Matrizes da cena/câmera atualizadas antes do raycasting, hitboxes invisíveis de cabeça, tronco e pernas, e tiros de NPCs processados com o mesmo sistema de colisão.
- Modelos low-poly de armas visíveis em terceira pessoa, modelo de arma/braço anexado à câmera em primeira pessoa e miniaturas renderizadas dos modelos 3D no HUD/inventário rápido, com fallback SVG, e galeria de armas no painel Inventário.
- Animação alternada das pernas ao caminhar/correr, com retorno à pose neutra quando para.
- Áudio sintetizado para tiros, passos, saltos e cliques dos menus.
- Retângulo amarelo de feedback ao disparar e traçadores 3D.
- Cache PWA alterado para v4 para forçar a atualização dos arquivos no navegador.

## Como atualizar a publicação

1. Extraia o ZIP.
2. Publique/substitua o conteúdo da pasta `RetardadosRoyale_Web` no mesmo site Netlify.
3. Preserve as pastas `src` e `icons` e o arquivo `service-worker.js`.
4. Abra o site novamente. Se o navegador mantiver arquivos antigos, feche a aba instalada e recarregue o site; pode ser necessário limpar os dados do site.

## Verificação

Sintaxe JavaScript validada com `node --check`; verificadas as referências estáticas `$()` contra os IDs do HTML (sem referências ausentes) e atualizados os arquivos PWA. O teste visual de WebGL não pôde ser completado neste ambiente por falha de inicialização de ANGLE/SwiftShader.
