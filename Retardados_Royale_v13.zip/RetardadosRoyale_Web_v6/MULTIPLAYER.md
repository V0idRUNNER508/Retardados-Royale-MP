# Retardados Royale — Multiplayer com salas públicas e privadas (v13)

Esta atualização adiciona uma primeira camada online ao jogo existente. O cliente continua em Three.js; o backend é um processo Node.js separado que usa Colyseus e WebSockets. **A Netlify hospeda apenas o frontend estático.** O servidor multiplayer precisa de uma hospedagem Node persistente.

## O que está incluído

- **Jogar sozinho** mantém o modo local contra NPCs e o modo de treino.
- **Salas multiplayer** permite criar salas públicas ou privadas. Salas públicas aparecem no navegador; salas privadas não são listadas.
- **Procurar salas públicas** exibe as salas públicas com vagas disponíveis, a contagem de jogadores e o código da sala.
- **Entrar em sala** permite usar o código de uma sala privada (ou entrar diretamente em uma sala pública listada).
- Todas as salas aceitam no máximo 8 jogadores; o modo online continua sem NPCs.
- Lista os jogadores presentes, seus nicknames e seus personagens selecionados.
- Sincroniza posição, altura de salto, orientação e estado de movimento/animação.
- Remove jogadores que saem ou desconectam.
- Os clientes enviam intenções de movimento. O servidor limita valores, calcula posições/gravidade/salto e verifica colisões contra a arena determinística compartilhada.
- A primeira fase online não sincroniza armas, tiros, dano, loot, armaduras, carros, Verity, bots ou a zona segura. Esses sistemas continuam disponíveis no modo solo; não são simulados falsamente no online.

## Arquivos adicionados

- `server/package.json`: dependências e scripts do backend.
- `server/src/index.js`: servidor HTTP + Colyseus, endpoint `/health` e API `/rooms/royale` que lista somente salas públicas desbloqueadas com vagas.
- `server/src/rooms/RoyaleRoom.js`: salas públicas ou privadas, metadados para a lista pública, validação de inputs, movimento autoritativo e snapshots.
- `server/test/arena-layout.test.js`: testes do mapa determinístico e da área de spawn.
- `server/test/multiplayer.integration.js`: teste com dois clientes Colyseus, movimento e desconexão.
- `src/multiplayer-client.js`: criação de salas públicas/privadas, listagem pública, entrada por código e saída.
- `src/multiplayer-config.js`: endereço do backend.
- `shared/arena-layout.js`: gerador sem dependências, compartilhado entre navegador e servidor para que ambos usem o mesmo mapa.
- `MULTIPLAYER.md`: este guia.

## Arquivos do jogo modificados

- `index.html`: opções de criar/entrar em sala, código, estado de conexão e lista de jogadores.
- `style.css`: aparência responsiva da interface multiplayer, incluindo mobile.
- `src/game.js`: adaptador para enviar comandos de movimento, receber snapshots, interpolar os jogadores remotos, usar o seed do mapa fornecido pela sala e lidar com desconexões. O restante do jogo solo permanece no ramo offline.
- `service-worker.js`: cache atualizado para v13 e inclui os novos módulos locais.
- `README.md`: limitações e instruções atualizadas.

## Testar localmente com dois navegadores

Requer Node.js 20.10+ e npm. A instalação de dependências precisa de internet.

1. Abra um terminal na pasta raiz do projeto, onde está o `package.json` principal.
2. Instale o servidor:

   ```bash
   npm run server:install
   ```

3. Inicie o servidor em um terminal e deixe-o aberto:

   ```bash
   npm run server:dev
   ```

   O backend escuta em `http://localhost:2567`; `http://localhost:2567/health` deve devolver JSON com `ok: true`. A porta 2567 também recebe as conexões WebSocket.

4. Em outro terminal, na raiz do projeto, inicie o frontend:

   ```bash
   python -m http.server 8000 --directory RetardadosRoyale_Web_v6
   ```

5. Abra `http://localhost:8000` em duas sessões do navegador (por exemplo, janela normal e anônima). Em localhost, `src/multiplayer-config.js` usa automaticamente `http://localhost:2567`.
6. No primeiro cliente, abra **Jogar → Salas multiplayer** e crie uma sala pública ou privada. Copie o código exibido no HUD.
7. No segundo cliente, escolha **Salas multiplayer → Procurar salas públicas** para encontrar uma sala pública, ou use **Entrar em sala** e cole o código para entrar diretamente.
8. Mova os personagens com WASD + mouse no computador ou joystick/toque no celular. Confirme que a lista mostra dois jogadores e que ambos os avatares se movem nas duas janelas. Feche uma sessão e confirme que ela desaparece da lista da outra.

O teste de mapa pode ser executado sem baixar dependências:

```bash
npm run test:arena
```

Com o servidor rodando e após `npm run server:install`, o teste de integração de protocolo com dois clientes pode ser executado em outro terminal:

```bash
npm run test:integration
```

## Hospedar o backend

Não hospede o processo Colyseus numa função serverless da Netlify. Escolha uma hospedagem que aceite um serviço web Node.js com conexões WebSocket persistentes. Por exemplo, em um novo serviço Node da Render, conectado ao repositório que contém a pasta `server/` e a pasta `RetardadosRoyale_Web_v6/`, use:

- **Build command:** `npm --prefix server install`
- **Start command:** `npm --prefix server start`
- **Health check path (se solicitado pelo provedor):** `/health`
- **Node:** 20.10+ (Node 22 LTS recomendado)

O servidor lê `PORT` e vincula-se a `0.0.0.0`, conforme o ambiente de hospedagem. Use a URL HTTPS que a plataforma atribuir ao serviço; ela será convertida pelo SDK para WebSocket seguro.

## Ligar o frontend Netlify ao backend publicado

Depois que o backend tiver um endereço HTTPS público, edite `RetardadosRoyale_Web_v6/src/multiplayer-config.js`:

```js
export const COLYSEUS_ENDPOINT = 'https://SEU-SERVIDOR-NODE.example.com';
```

Substitua o endereço de exemplo pela URL real da hospedagem Node e publique novamente **o conteúdo** de `RetardadosRoyale_Web_v6` no Netlify. O backend e o frontend são deploys separados. Sem definir essa URL em produção, a interface online mostrará uma mensagem para configurar o servidor, em vez de fingir que conectou.

## Limites da primeira versão

- As salas privadas usam o ID gerado pelo Colyseus como código de convite; não é uma senha criptográfica. Compartilhe apenas com quem deve entrar. Salas públicas aparecem para qualquer jogador conectado ao mesmo servidor.
- A movimentação é calculada pelo servidor a 20 Hz e transmitida por snapshots. Não foi incluído client-side prediction/rollback nesta primeira etapa, então pode existir pequena latência perceptível.
- A validação é básica para o protótipo: limites de velocidade, valores de input, gravidade/salto e colisão com obstáculos. Não representa anti-cheat completo de produção.
- Os dados de nickname/personagem vêm do perfil local e são validados/sanitizados pelo servidor. O perfil, as moedas e desbloqueios continuam locais e não são sincronizados entre aparelhos.
- O jogo visual exige um navegador com WebGL e acesso aos CDNs usados para Three.js e ao CDN do SDK Colyseus. O servidor Node não hospeda o Three.js.
- A mudança de personagem é feita antes de entrar na sala. Alterações no personagem durante uma partida ainda não são sincronizadas.
- Esta fase permite ver os jogadores e movimentá-los no mesmo mapa; combate multiplayer, armas, vida/escudo, itens, veículos e condições de vitória ainda não são online.

## Diagnóstico rápido

- **“Servidor ainda não foi configurado”**: ajuste `COLYSEUS_ENDPOINT` e publique o frontend novamente.
- **Não consegue criar/entrar**: confira `/health`, os logs do servidor, a URL usada e se o serviço suporta WebSockets.
- **O jogador remoto não aparece**: confirme que ambos entraram no mesmo código e que ambos os clientes estão recebendo `snapshot`.
- **Mapa diferente entre clientes**: confirme que a versão publicada inclui `shared/arena-layout.js`, `src/multiplayer-client.js` e `src/multiplayer-config.js`, e que o cache PWA v13 foi ativado.
- **Site continua antigo**: atualize os dados do site/PWA e confira se o Netlify publicou o conteúdo de `RetardadosRoyale_Web_v6`, não a pasta pai.
