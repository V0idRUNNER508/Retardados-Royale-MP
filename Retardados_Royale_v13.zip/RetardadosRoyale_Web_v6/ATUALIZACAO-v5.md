# Retardados Royale — atualização v5: veículos

## Veículos
- Carros 3D low-poly com rodas giratórias, faróis, lanternas e cores sortidas.
- Um carro aparece em local aleatório no começo da partida.
- Um carro novo tenta aparecer a cada 300 segundos de tempo de partida; cada carro some depois de 360 segundos.
- Limite de dois veículos ao mesmo tempo e minimapa com marcador laranja.
- Colisões com estruturas e barreiras da arena.

## Direção e controles
- PC: `E` entra/sai, `W/S` acelera/recuar e `A/D` vira.
- Mobile: botão contextual `DIRIGIR`/`SAIR DO CARRO`; joystick controla direção e acelerador.
- A câmera acompanha o carro em terceira pessoa; em primeira pessoa, a vista fica perto do para-brisa.
- Enquanto dirige, o HUD mostra a velocidade aproximada em km/h.

## Atropelamentos
- Quando o jogador está dirigindo a mais de 5 unidades/s e acerta um NPC, o NPC recebe dano variável (35–80 pontos), efeitos sonoros e impulso de alta velocidade que o arremessa vários metros.
- Um intervalo de proteção curto evita que um único contato aplique dano repetido a cada quadro.

## Frequência e desaparecimento
- Os tempos são contados dentro da partida, não em tempo real de relógio.
- Um carro inicial evita que o veículo fique indisponível nas partidas curtas; após isso, novos carros chegam a cada cinco minutos.
- Cada veículo permanece cerca de seis minutos e o mapa mantém no máximo dois veículos.

## Publicação
Substitua o conteúdo do site Netlify pelo conteúdo desta pasta, mantendo `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`. O cache PWA foi alterado para v5.

## Validação
A validação é estática. A execução gráfica completa depende de WebGL e do acesso à CDN Three.js, portanto os controles de direção devem ser testados após publicar em HTTPS.
