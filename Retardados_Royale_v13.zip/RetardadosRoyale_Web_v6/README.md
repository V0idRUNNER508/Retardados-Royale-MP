# RETARDADOS ROYALE — versão para navegador

Esta pasta contém a edição **Web/PWA** do protótipo 3D. Não precisa do Android Studio nem de compilar um APK. Você pode abrir no computador usando um servidor local ou publicar a pasta em uma hospedagem estática para jogar pelo navegador do celular.

## O que vem nesta versão

- Arena 3D quadriculada, cenário low-poly, obstáculos e zona segura.
- Personagens Enzo, Luan, Eduardo e Personalizável.
- Combate com pistola, marreta, submetralhadora, rifle, escopeta, rifle de precisão e lançador.
- Vida, escudo, coleta de itens, munição, bots com três níveis de dificuldade e treinamento.
- Menu, seleção de personagem, nickname, loja local, inventário, missões, estatísticas e configurações.
- Seleção explícita entre layout COMPUTADOR e MOBILE no menu; o layout Mobile permanece visível em telas horizontais mesmo quando a largura ultrapassa 700 px.
- Alternância de câmera entre primeira e terceira pessoa no menu e durante a partida.
- Modelos low-poly tridimensionais originais para pistola, submetralhadora, rifle, escopeta, rifle de precisão, lançador e marreta, visíveis nas mãos dos personagens e na perspectiva de primeira pessoa.
- HUD de combate sem marca/título no canto superior e sem guia de teclas durante a partida; dicas pequenas aparecem no menu.
- Perfil salvo no armazenamento local do navegador.
- **Códigos de recompensa em Configurações:** a caixa converte texto automaticamente para MAIÚSCULAS. O código `VINCENT069` desbloqueia Vincent; códigos inválidos mostram um aviso e o personagem resgatado passa a aparecer na seleção. O progresso é salvo localmente no navegador.
- **Veículos dirigíveis:** carros low-poly surgem em posições aleatórias; um carro inicial fica disponível por partida, e um novo tenta surgir a cada cinco minutos de tempo de partida. Cada veículo dura cerca de seis minutos, com no máximo dois no mapa ao mesmo tempo.
- **Atropelamento de NPCs:** ao dirigir a velocidade suficiente, o carro causa dano e empurra os bots vários metros na direção do impacto. Os veículos colidem com obstáculos e aparecem como marcadores no minimapa.
- Manifesto PWA e service worker para permitir instalação pelo navegador e guardar os arquivos do site em cache.
- Se a biblioteca 3D não carregar, a página mostra uma mensagem explicando o que verificar, em vez de ficar presa no carregamento.

## Jogar no computador

1. Extraia o ZIP inteiro para uma pasta.
2. Tenha o Python 3 instalado.
3. No Windows, dê dois cliques em `iniciar-windows.bat`.
4. No macOS ou Linux, abra um terminal nesta pasta e execute `./iniciar-linux-macos.sh`.
5. Acesse `http://localhost:8000` se o navegador não abrir sozinho.
6. Clique em **JOGAR** → escolha **SOLO CONTRA BOTS** ou **TREINAMENTO** → **ENTRAR NA ARENA**.

Não abra `index.html` por duplo clique (`file://`): navegadores podem bloquear módulos ES nessa origem. Abra pelo endereço local acima.

## Jogar no celular pelo navegador

Para jogar no celular, o site precisa de um endereço web HTTPS. O jeito mais simples é publicar a pasta em uma hospedagem estática (por exemplo, Netlify Drop ou GitHub Pages):

1. Extraia o ZIP.
2. Envie **o conteúdo desta pasta** para uma hospedagem estática, mantendo a estrutura das subpastas `src/` e `icons/`.
3. Abra o endereço HTTPS gerado no Chrome do celular.
4. Abra o menu do navegador e escolha **Instalar app** ou **Adicionar à tela inicial**, quando a opção aparecer.
5. No menu principal, escolha **MOBILE** em Preferências Rápidas. Entre em modo paisagem para ter mais espaço. Durante a partida, use o joystick no lado esquerdo; arraste uma área vazia do lado direito para girar a câmera; os botões à direita servem para pular, recarregar, disparar e pegar itens.

O arquivo `manifest.webmanifest` e o `service-worker.js` preparam a instalação como PWA. O suporte de instalação varia conforme navegador e forma de hospedagem.

## Controles

### Computador

- `W A S D`: mover.
- `Shift`: correr.
- `Espaço`: pular.
- Mouse: mirar; clique esquerdo: disparar.
- Clique na arena para capturar o cursor; `Esc`: pausar e liberar o cursor.
- `R`: recarregar; `E`: coletar item ou entrar/sair de um carro; `1` a `5`: trocar arma.
- **Dirigindo:** `W` acelerar, `S` frear/recuar, `A/D` virar; `E` sair. O carro é muito mais rápido que correr.
- Botão direito + arrastar: girar a câmera quando o cursor não está capturado.
- Menu principal ou botão no topo durante a partida: alternar entre **1ª pessoa** e **3ª pessoa**.

### Celular

- Joystick virtual à esquerda: movimentar.
- Arrastar na área livre do jogo: girar câmera.
- Botões de toque: disparar, pular, recarregar, pegar item e entrar/sair do carro. Ao dirigir, o joystick controla acelerador/reverso e direção.
- Se o jogo abrir em pé, a dica na tela recomenda girar o dispositivo para paisagem.

## Requisitos e limitações reais

- É preciso ter um navegador moderno com WebGL e **conexão com a internet para carregar o motor 3D**. O jogo tenta carregar Three.js de vários provedores públicos independentes (esm.sh, esm.run, jsDelivr, unpkg, JSPM e um espelho do GitHub), usando uma versão fixada. Os arquivos do jogo são locais, mas Three.js não está embutido neste pacote.
- O service worker armazena a estrutura e os arquivos locais do site. Isso **não garante jogo offline**, porque a biblioteca Three.js ainda vem de um CDN externo.
- **Multiplayer online v13:** criar salas públicas e privadas, procurar salas públicas com vagas, entrar por código, ver a lista de jogadores e sincronizar movimentos, rotação e animação. Requer que o backend Node/Colyseus seja implantado separadamente e que `src/multiplayer-config.js` seja configurado com a URL real. No online desta fase, combate, loot, armaduras, carros, Verity, bots e zona segura ainda não são sincronizados. Veja `MULTIPLAYER.md`.
- Modelos, armas e animações são um protótipo low-poly feito com primitivas; não é um jogo completo do nível de Fortnite.
- Perfil, moedas, compras e estatísticas ficam no armazenamento local do navegador. Não são sincronizados entre aparelhos e podem ser apagados ao limpar dados do site.
- Este projeto não foi testado em todos os modelos de celular. Se travar, reduza a qualidade gráfica nas configurações e feche outras abas.

## Arquivos principais

- `index.html`: interface, HUD, mensagens de erro e inicialização.
- `style.css`: estilo e responsividade.
- `src/game.js`: cena 3D, modo solo, adaptador multiplayer, NPCs, loot, menus e perfil.
- `src/multiplayer-client.js` e `src/multiplayer-config.js`: cliente Colyseus e endereço do backend.
- `shared/arena-layout.js`: geração determinística do mapa compartilhada pelo frontend e servidor.
- `MULTIPLAYER.md`: arquitetura, arquivos, instalação, testes e deploy do backend.
- `manifest.webmanifest`: metadados para instalação PWA.
- `service-worker.js`: cache dos recursos locais.
- `icons/`: ícones do jogo.

## Solução de problemas

- **Fica em “CARREGANDO A ARENA” ou aparece erro de motor 3D:** confira a conexão, abra por `http://localhost:8000` ou HTTPS e tente novamente. O navegador precisa alcançar ao menos um dos provedores de Three.js. A tela de erro agora diferencia arquivo de jogo ausente de falha no motor 3D e mostra uma mensagem técnica mais útil.
- **Tela preta:** confira se o navegador permite WebGL e atualize Chrome/Edge/Firefox.
- **A porta 8000 está em uso:** abra um terminal na pasta e execute `python -m http.server 8001`, depois visite `http://localhost:8001`.
- **O menu não mostra os itens:** atualize a página; a versão Web corrige a inicialização dos painéis de Loja, Inventário, Missões e Estatísticas.
- **O progresso sumiu:** ele é local ao navegador/origem; não é uma conta na nuvem.

## Licença

O código deste protótipo é fornecido como está. Veja `LICENSE.txt`. Three.js é carregado da distribuição pública externa e mantém a licença do seu projeto original.

## Atualização publicada no Netlify

Para atualizar uma versão que já está publicada, extraia este novo ZIP e envie novamente **o conteúdo da pasta `RetardadosRoyale_Web`** para o mesmo site no Netlify. Preserve a estrutura `src/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`. O service worker foi atualizado para a versão de cache v7 para remover arquivos em cache da versão que falhou e carregar os novos diagnósticos. Se o visual antigo persistir, feche e reabra a página ou limpe os dados do site no navegador.

Esta atualização muda o código local do projeto; ela não publica sozinha na sua conta Netlify.


## Atualização v4 — câmera, combate, armas e áudio

Esta versão adiciona os seguintes ajustes ao protótipo web:

- **Câmera mobile:** arrastar o dedo em qualquer região livre do jogo gira a câmera tanto em primeira quanto em terceira pessoa. O joystick e os botões de ação ficam excluídos do gesto de mira.
- **Câmera no computador:** o mouse controla a câmera após capturar o cursor; arrastar com o botão direito ou o botão do meio também ajusta a câmera.
- **Disparo:** clique esquerdo e a tecla **F** disparam no computador; o botão grande **ATIRAR** dispara no mobile. Armas automáticas continuam disparando enquanto o comando fica pressionado.
- **Hitboxes:** cabeça, tronco e pernas têm hitboxes de combate separadas. Os disparos de jogador e bots usam raycasting com matrizes 3D atualizadas. Acertos na cabeça recebem multiplicador de dano.
- **Armas:** os modelos low-poly ficam maiores e deslocados para o lado da mão; a arma em primeira pessoa usa um conjunto de braço/arma anexado à câmera. O HUD mostra miniaturas renderizadas dos modelos 3D no cartão e nos espaços rápidos (com silhuetas vetoriais como fallback). O painel Inventário também ganhou uma galeria de prévias de todas as armas.
- **Animação:** as pernas oscilam em sentidos opostos ao andar/correr e voltam suavemente à posição neutra quando o personagem para. NPCs também usam esta animação e viram para o adversário-alvo.
- **Áudio sintetizado:** foram adicionados sons procedurais de disparos, passos, pulo e cliques da interface, além dos sinais de recarga, coleta e dano já existentes.
- **Feedback de tiro:** um pequeno retângulo amarelo aparece no centro da mira ao disparar, junto com os traçadores 3D.
- **Mobile horizontal:** controles têm posicionamento e dimensões especiais para telas baixas em orientação paisagem.

### Controles atualizados

**Computador:** WASD movimenta; mouse mira; clique esquerdo ou segurar **F** dispara; botão direito/meio arrastado também gira a câmera; Espaço pula; Shift corre; R recarrega; E coleta; teclas 1–5 trocam de arma; Esc pausa.

**Celular:** joystick esquerdo movimenta; arraste uma área livre da tela para mirar; botão **ATIRAR** dispara; os botões de pulo, recarga e coleta aparecem no lado direito. O botão no topo alterna entre primeira e terceira pessoa.

### Limite de validação

Foi feita validação estática da sintaxe JavaScript, IDs HTML, referências estáticas de elementos e arquivos do pacote. Não foi possível executar um teste visual completo neste ambiente porque o Chromium não conseguiu inicializar o WebGL. Recomenda-se verificar a câmera, o tiro e o layout móvel após publicar a pasta no HTTPS. O motor Three.js continua sendo carregado por CDN, por isso o primeiro carregamento requer internet.


## Atualização v5 — carros e direção

- O mapa começa com um carro em uma posição aleatória, afastada do jogador e de obstáculos.
- Um carro adicional tenta surgir aproximadamente a cada **5 minutos de tempo de partida**. Cada carro dura cerca de **6 minutos**, e a arena mantém no máximo **2 veículos simultâneos**; as posições são sorteadas para evitar que os carros apareçam repetidamente no mesmo local.
- A disponibilidade de veículos conta o tempo da partida, não o relógio real. No modo de batalha, se a rodada terminar antes dos cinco minutos, o carro inicial continuará disponível; no treinamento, a rotação de veículos pode continuar por mais tempo.
- **Computador:** aproxime-se e pressione `E` para entrar ou sair. Dirija com `W/S` (acelerar/recuar) e `A/D` (virar). O carro chega a aproximadamente 83 km/h, bem mais rápido que correr.
- **Mobile:** aproxime-se e use o botão **DIRIGIR**; o mesmo botão vira **SAIR DO CARRO** enquanto estiver dirigindo. O joystick controla acelerador/reverso e direção.
- Quando o carro conduzido pelo jogador colide com um NPC a velocidade suficiente, causa dano variável e aplica um impulso que pode arremessar o NPC muitos metros. O carro também bate em obstáculos sólidos e tem rodas visíveis que giram.
- Os carros aparecem no minimapa com um marcador laranja. O painel mostra a velocidade enquanto o jogador dirige.

### Limite de validação da v5

A sintaxe JavaScript, os IDs usados pelo código e a integridade do pacote são verificados antes da entrega. Não foi possível executar uma partida gráfica completa neste ambiente, então recomendo testar a direção, colisões e o controle touch na publicação HTTPS. Three.js continua sendo carregado via CDN, exigindo conexão à internet na inicialização.


## Correção v7 — carregamento e diagnóstico

- O Three.js agora tem seis fontes alternativas de carregamento, incluindo dois provedores que entregam bundles ESM, para reduzir a chance de um único CDN bloqueado impedir o início do jogo.
- O carregamento aguarda no máximo 20 segundos e registra quais fontes falharam.
- A tela de erro testa se `src/game.js` realmente está publicado. Se a pasta estiver errada, explica exatamente que o conteúdo de `RetardadosRoyale_Web_v6` deve ser enviado e que `src/` precisa ficar ao lado de `index.html`.
- O cache do PWA foi atualizado para v7.
- O motor 3D não foi copiado para o pacote porque o ambiente de edição não conseguiu obter arquivos externos; portanto, esta melhoria ainda precisa de acesso a pelo menos um CDN na primeira inicialização.


## Correção v8 — SaveSettings

A versão v8 restaura funções de configurações, menus e renderização que estavam ausentes na v7, além de renovar o cache do service worker. Consulte `ATUALIZACAO-v8.md`.

## Atualização v9 — controles do celular

A v9 corrige PULAR por toque, restringe o disparo mobile ao botão ATIRAR e deixa o botão E oculto até existir um item coletável por perto. Consulte `ATUALIZACAO-v9.md` para detalhes e instruções de publicação.


## Atualização v10 — armaduras e câmera

Esta versão adiciona armaduras coletáveis com bônus de escudo, NPCs com armadura aleatória que derrubam suas peças quando eliminados, mais aparições de carros (intervalo de quatro minutos) e corrige o sentido horizontal do controle de câmera em touch e mouse. Consulte `ATUALIZACAO-v10.md`.


## Atualização v11 — Verity
A versão v11 adiciona o item especial Verity. Ele aparece raramente em locais aleatórios durante a partida; uma unidade coletada permite um arremesso. Use **G** no computador ou o botão Verity no Mobile. Ao tocar o chão, a granada gera faíscas amarelas e uma onda de choque que arremessa NPCs e jogadores próximos. Uma Verity não coletada desaparece após um tempo, e só pode haver uma unidade no chão por vez.
