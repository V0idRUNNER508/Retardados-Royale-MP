@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  start "Retardados Royale Web" cmd /k "py -m http.server 8000"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3 nao foi encontrado. Instale em https://www.python.org/downloads/ e tente novamente.
    pause
    exit /b 1
  )
  start "Retardados Royale Web" cmd /k "python -m http.server 8000"
)
timeout /t 2 /nobreak >nul
start "" "http://localhost:8000"
