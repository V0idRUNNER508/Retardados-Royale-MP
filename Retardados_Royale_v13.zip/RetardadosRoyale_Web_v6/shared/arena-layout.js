// Deterministic arena layout shared by the browser and authoritative server.
// Keep this module dependency-free so both Node.js and native browser modules can use it.
export function generateArenaLayout(seed = 1) {
  let state = (Number(seed) >>> 0) || 1;
  const random = () => {
    // Mulberry32: same output for the same 32-bit seed in browser and Node.js.
    state = (state + 0x6D2B79F5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const range = (a, b) => a + random() * (b - a);
  const colors = ['#646a71', '#8a7968', '#5b626b', '#767b70', '#a08064'];
  const walls = [
    { x: 0, z: -258, ry: 0 },
    { x: 0, z: 258, ry: 0 },
    { x: -258, z: 0, ry: Math.PI / 2 },
    { x: 258, z: 0, ry: Math.PI / 2 }
  ];
  const obstacles = [];
  for (let i = 0; i < 88; i++) {
    const x = range(-220, 220), z = range(-220, 220);
    if (Math.hypot(x, z) < 17) continue;
    const typeRoll = random();
    let shape, sx, sy, sz;
    if (typeRoll < 0.68) {
      shape = 'box'; sx = range(2.5, 6); sy = range(1.4, 4.3); sz = range(2.5, 6);
    } else if (typeRoll < 0.86) {
      shape = 'box'; sx = range(3, 6); sy = range(1.4, 2); sz = range(1.2, 2);
    } else {
      shape = 'cylinder'; sx = range(2.5, 4.5); sy = range(3, 6); sz = range(2.5, 4.5);
    }
    obstacles.push({
      id: i, shape, x, z, sx, sy, sz,
      rotationY: range(0, Math.PI),
      color: colors[Math.floor(random() * colors.length)]
    });
  }
  const setPieces = [];
  for (let i = 0; i < 8; i++) {
    const x = range(-205, 205), z = range(-205, 205);
    if (Math.hypot(x, z) < 24) continue;
    setPieces.push({ x, z, color: ['#ff7438', '#55d9c7', '#bd8aff'][i % 3] });
  }
  return { seed: (Number(seed) >>> 0) || 1, walls, obstacles, setPieces };
}

export function isBlocked(layout, x, z, radius = 0.48) {
  if (!Number.isFinite(x) || !Number.isFinite(z) || Math.abs(x) > 253 || Math.abs(z) > 253) return true;
  for (const o of layout.obstacles) {
    const dx = x - o.x, dz = z - o.z;
    if (o.shape === 'cylinder') {
      const obstacleRadius = Math.max(o.sx * 0.7, o.sx * 0.58);
      if ((dx * dx) + (dz * dz) < (obstacleRadius + radius) ** 2) return true;
      continue;
    }
    const cs = Math.cos(-(o.rotationY || 0)), sn = Math.sin(-(o.rotationY || 0));
    const lx = dx * cs - dz * sn, lz = dx * sn + dz * cs;
    if (Math.abs(lx) < o.sx / 2 + radius && Math.abs(lz) < o.sz / 2 + radius) return true;
  }
  return false;
}
