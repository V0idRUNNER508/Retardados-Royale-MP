# Registro de animações e licenças — Importador 3D (V14)

## Pipeline efetivamente incluído

- **Three.js 0.180.0**: o jogo já utilizava Three.js. O carregador GLB/glTF e o utilitário de clonagem de esqueletos são carregados sob demanda a partir dos módulos do Three.js 0.180.0 publicados no esm.sh. O importador não baixa animações nem modelos de personagem de terceiros em tempo de execução.
- **Animações fornecidas pelo jogador**: clipes incorporados ao GLB/glTF selecionado são lidos localmente. O controlador reconhece nomes comuns para `idle`, `walk`, `run`, `jump`, `fall`, `land` e `hold/carry/ready`, cria `AnimationMixer`/`AnimationAction` e faz crossfade. Este build não inclui um banco próprio de clipes separados nem retargeting completo entre esqueletos arbitrários. Clipes incorporados só funcionarão quando seus tracks puderem ser ligados aos nós do modelo; as pernas/braços de rigs humanoides reconhecíveis têm fallback procedural quando não há walk/run compatível. Clipes incompatíveis são ignorados.
- **Rigging automático integrado**: não existe um motor de auto-rigging integrado a este build. O importador não cria ossos falsos e não transmite arquivos. A interface oferece um link manual para o Auto-Rig Studio do Grab3D; segundo a página da ferramenta, o processamento ocorre no navegador e o modelo não é enviado ao servidor. Ela é externa e não é chamada automaticamente pelo jogo. Se o jogador optar por usá-la, deve importar o GLB exportado de volta ao jogo. A ferramenta afirma ser para humanoides bípedes e recomenda revisar os marcadores/juntas; o resultado não é garantido.

## Fonte pública analisada (não redistribuída neste ZIP)

**8 Free Blocky Characters — Vuena**  
Origem: https://vuena.itch.io/blocky-characters-free-sample  
Licença informada na página: **CC0 / domínio público**. A página descreve modelos GLB/FBX rigados, esqueleto humanoide de 22 ossos e seis clipes por modelo: idle, walk, run, jump, fall e wave. O pack não anuncia clipe específico `land` ou `hold`.

**Importante:** a página e a licença foram verificadas, mas os arquivos binários do pacote não foram incorporados a esta entrega. O ambiente de edição não conseguiu resolver o host itch.io para baixar o ZIP. Portanto, o jogo desta entrega não depende desse pacote e não declara que seus clipes foram integrados. A página consultada identifica a licença como CC0 e lista idle, walk, run, jump, fall e wave; a licença CC0 permite uso e modificação, mas o pacote binário não foi incluído nesta entrega. O controlador usa somente as animações presentes no arquivo importado pelo jogador. O clipe `wave` não é tratado incorretamente como pose neutra de segurar um objeto.

## Condições técnicas e privacidade

- Os arquivos GLB/glTF e suas dependências permanecem no IndexedDB do navegador.
- Para `.gltf`, o jogador deve selecionar o `.gltf` e seus arquivos `.bin`/texturas na mesma seleção. Referências HTTP(S) embutidas são bloqueadas.
- FBX não está habilitado: não foi acrescentado um carregador FBX sem testes de compatibilidade.
- Modelos acima de 2 milhões de vértices, arquivos acima dos limites definidos e dependências ausentes são rejeitados com mensagem de erro.

## Ferramenta alternativa de auto-rig (opcional)

Grab3D Auto-Rig Studio: https://grab3d.com/tools/auto-rig/ — a página consultada declara que a seleção, o rigging, os pesos e a exportação são processados no navegador e que nada é enviado ao servidor; a ferramenta informa limite de humanoides bípedes e recomenda poses T/A e revisão dos marcadores. O Retardados Royale não abre nem transmite o modelo automaticamente. Esta ligação externa é uma alternativa manual, não uma dependência do jogo.
