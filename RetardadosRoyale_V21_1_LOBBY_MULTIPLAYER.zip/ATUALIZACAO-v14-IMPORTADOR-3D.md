# Atualização V14 — Importador de personagens 3D

Esta atualização foi aplicada sobre o V13 existente, sem recriar o jogo. A cópia do servidor, salas públicas/privadas e estrutura original foram mantidas.

## Implementado

- Novo painel “Importar personagem 3D” dentro da seleção existente.
- Leitura de GLB/glTF local com prévia 3D arrastável e rotação automática, nome editável e feedback de erro.
- Verificação de arquivos, limites de tamanho/complexidade, detecção de malha com skinning, esqueleto, pesos e animações. Modelos sem vértices ou com limites espaciais inválidos são rejeitados/impedidos de entrar na cena.
- Diálogo antes de tratar modelos sem rig. Não são adicionados ossos fictícios: o rigging integrado é declarado indisponível; o usuário pode importar como estático ou abrir manualmente uma ferramenta externa.
- Clipes embutidos com nomes reconhecidos usam AnimationMixer/AnimationAction, crossfade e atualização por delta. Movimento horizontal de root/hips é achatado quando identificável para não duplicar o deslocamento do jogo.
- Escala/posicionamento inicial aproximados e hitboxes compatíveis com a escala de jogo.
- Armazenamento binário e metadados no IndexedDB, restauração após recarregar, seleção e remoção confirmada.
- Fallback procedural simples de pernas/braços para rigs humanoides reconhecíveis sem walk/run compatíveis. Personagens originais preservam sua lógica.
- Cache do service worker atualizado para v14 e inclui o novo módulo do importador.

## Limitações importantes

- Formatos aceitos: GLB e glTF. FBX não está habilitado. Para glTF, selecione o arquivo principal e suas dependências locais na mesma seleção. Referências remotas são bloqueadas.
- O importador não faz auto-rigging. Ele não envia arquivos a serviços. Existe um link opcional para uma ferramenta externa de auto-rig que declara funcionar no navegador; usar essa ferramenta é uma ação separada, manual e de responsabilidade do usuário.
- Não há retargeting completo para qualquer par de esqueletos, nem um pacote de animações separado incluído. Os clipes no GLB/glTF são os preferidos; os nomes reconhecidos são idle, walk, run, jump, fall, land e hold/carry/ready. A página Vuena indicada informa licença CC0 e seis clipes (idle/walk/run/jump/fall/wave), mas não foi possível baixar o ZIP por falha de resolução de rede no ambiente de edição; esses recursos não são redistribuídos neste build. Wave não é tratado como hold.
- A escala base é normalizada para aproximadamente 2,55 unidades de altura. Isso é uma heurística, não reconhecimento anatômico perfeito. Hitboxes são aproximadas e não acompanham deformações do esqueleto.
- Dados são locais ao perfil/origem do navegador: IndexedDB do dispositivo não é sincronizado automaticamente com outros jogadores nem entre domínios. No multiplayer, o arquivo personalizado permanece apenas no seu dispositivo; a identidade enviada à sala usa o personagem original ENZO como fallback para que nenhum identificador local sem significado seja enviado como se o modelo fosse compartilhado. Outros jogadores não veem o modelo importado sem um sistema de distribuição sincronizado e consentimento explícito.

## Arquivos alterados/criados

- `index.html`: painel do importador e instruções.
- `style.css`: estilos responsivos para computador e mobile.
- `src/game.js`: integração com a seleção, partida, animações, prévia e limpeza de recursos.
- `src/character-importer.js`: validação, carregamento GLB/glTF, análise de rig, IndexedDB e liberação de recursos.
- `service-worker.js`: invalidação de cache v13 e precache do módulo novo.
- `ANIMATIONS-LICENSES-v14.md`: fontes e limites de licença/integração.
- `test/character-importer.test.js` e `package.json`: testes de validação e classificação de animações.

## Verificação executada

**Passou neste ambiente:**

- `node --check` em `src/game.js`, `src/character-importer.js`, `src/multiplayer-client.js`, `shared/arena-layout.js` e no teste do importador.
- `npm run test:characters`: 6/6 testes passaram (extensões, limites, seleção de dependências, nomes de animações, detecção de rig/pesos, glTF malformado/versão antiga/recurso remoto).
- `npm run test:arena`: 2/2 testes passaram.
- Validação estrutural do HTML: 166 IDs, nenhum duplicado, todos os 17 IDs de UI do importador presentes.
- Os arquivos locais listados pelo precache do service worker existem; o ZIP final foi testado com `unzip -t`.

**Não foi possível certificar neste ambiente:**

- Não foi executado o fluxo completo de parsing/renderização com um GLB real rigado e outro não rigado; os módulos `GLTFLoader`/`SkeletonUtils` são carregados sob demanda de CDN e a rede de edição não permitiu obter o pacote de animações de referência.
- Não foi possível verificar a interface num navegador Android físico nem num computador de usuário. O teste headless não concluiu o carregamento do motor Three.js/CDN.
- O ciclo completo idle/walk/run/jump/fall/land, persistência real em IndexedDB após recarregar, desempenho e consumo de memória precisam de validação no navegador de destino. Os testes automatizados cobrem os validadores e classificadores, não substituem esses testes de ponta a ponta.

Consequentemente, esta entrega é uma integração de código com testes de unidade aprovados, mas ainda precisa do teste manual com modelos reais e navegador antes de ser considerada plenamente validada.
