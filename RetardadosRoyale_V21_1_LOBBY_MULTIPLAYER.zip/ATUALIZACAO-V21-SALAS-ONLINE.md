# Atualização V21 — Salas online por código

## Alterações
- Removida a dependência do endpoint Colyseus hospedado na rede local.
- Removido o bloqueio dos botões de criar/entrar quando o jogo é aberto pelo HTTPS.
- Implementadas salas P2P via PeerJS/WebRTC, com código de sala, entrada por código e limite de oito jogadores.
- Sincronizados presença, personagem, posição, direção, movimentação e salto.
- Atualizado o cache do service worker para carregar os arquivos novos.
- Substituídas as instruções antigas de multiplayer local por instruções das salas online.

## Limitações conhecidas
- O anfitrião deve manter a página aberta enquanto a sala estiver em uso.
- A lista global automática de salas públicas não está disponível sem um serviço adicional de catálogo; salas públicas são acessadas por código.
- A conexão depende do serviço de sinalização PeerJS Cloud, dos CDNs e de redes que permitam WebRTC. Algumas redes podem bloquear conexões diretas.
- Esta atualização sincroniza jogadores e movimentação, mas não faz todos os sistemas de combate, NPCs, loot, veículos e zona segura funcionarem online.

## Validação
- Verificadas a sintaxe dos módulos JavaScript, a existência dos arquivos do service worker, a ausência de IDs HTML duplicados e as referências estáticas entre o JavaScript e o HTML.
- Ainda é necessário testar a conexão real entre dois dispositivos em redes externas.
