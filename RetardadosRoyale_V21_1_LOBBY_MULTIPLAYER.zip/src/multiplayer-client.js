// Multiplayer P2P para o Retardados Royale.
// PeerJS Cloud é usado apenas para sinalização; após a conexão, os dados passam
// diretamente entre os navegadores por WebRTC. Nenhum servidor precisa rodar
// no computador do jogador. A sala continua viva enquanto o navegador anfitrião
// permanecer aberto.

const PEER_CDNS = [
  'https://esm.sh/peerjs@1.5.5?bundle',
  'https://cdn.jsdelivr.net/npm/peerjs@1.5.5/+esm'
];
const MAX_PLAYERS = 8;
const SNAPSHOT_INTERVAL_MS = 50;
const PEER_OPTIONS = {
  host: '0.peerjs.com',
  port: 443,
  path: '/',
  secure: true,
  debug: 1,
  config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] }
};

let sdkPromise;

async function loadPeerSdk() {
  if (!sdkPromise) {
    sdkPromise = Promise.any(PEER_CDNS.map(async (url) => {
      const mod = await import(url);
      const Peer = mod.Peer || mod.default?.Peer || mod.default;
      if (typeof Peer !== 'function') throw new Error(`A biblioteca PeerJS não foi carregada por ${url}.`);
      return Peer;
    })).catch((error) => {
      sdkPromise = null;
      throw new Error(`Não foi possível carregar o sistema de salas online. Confira sua internet e tente novamente. ${error?.message || ''}`);
    });
  }
  return sdkPromise;
}

function randomToken(length = 8) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(length);
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
  else for (let i = 0; i < length; i++) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join('');
}

function createRoomCode() {
  // IDs PeerJS devem começar e terminar com letra ou número. O código é o ID
  // de sinalização do anfitrião; evite alterar letras maiúsculas/minúsculas.
  return `RR${randomToken(6)}`;
}

function friendlyPeerError(error, context = 'conexão') {
  const type = String(error?.type || '').toLowerCase();
  const message = String(error?.message || '');
  if (type === 'unavailable-id') return new Error('Esse código já está sendo usado. Tente criar a sala novamente.');
  if (type === 'peer-unavailable') return new Error('Não encontrei uma sala ativa com esse código. Confira o código e peça ao anfitrião para manter o jogo aberto.');
  if (type === 'network' || type === 'socket-error' || type === 'server-error') return new Error('Não foi possível alcançar o serviço de conexão online. Verifique a internet ou tente novamente em outra rede.');
  if (type === 'webrtc' || type === 'disconnected') return new Error('A conexão direta entre os jogadores falhou. Algumas redes bloqueiam conexões P2P; tente outra rede ou desative o isolamento de clientes do Wi-Fi.');
  if (/peer.?unavailable/i.test(message)) return new Error('Não encontrei uma sala ativa com esse código. Confira o código e peça ao anfitrião para manter o jogo aberto.');
  return new Error(message || `Falha na ${context}. Verifique a conexão com a internet e tente novamente.`);
}

function waitForPeerOpen(peer, timeoutMs = 16000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => finish(reject, new Error('A conexão inicial demorou demais. Verifique sua internet e tente novamente.')), timeoutMs);
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      callback(value);
    };
    peer.on('open', (id) => finish(resolve, id));
    peer.on('error', (error) => finish(reject, friendlyPeerError(error, 'conexão inicial')));
  });
}

function waitForConnectionOpen(connection, timeoutMs = 16000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => finish(reject, new Error('A sala não respondeu a tempo. Confira o código e tente novamente.')), timeoutMs);
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      callback(value);
    };
    connection.on('open', () => finish(resolve, connection));
    connection.on('error', (error) => finish(reject, friendlyPeerError(error, 'conexão com a sala')));
    connection.on('close', () => finish(reject, new Error('A conexão foi encerrada antes de entrar na sala.')));
  });
}

function cleanIdentity(identity = {}) {
  const nickname = String(identity.nickname || 'JOGADOR').replace(/[<>]/g, '').slice(0, 16) || 'JOGADOR';
  const characterId = String(identity.characterId || 'enzo').slice(0, 40);
  const allowedAvatars = ['🎮', '⚔️', '👾', '🐸', '💀', '🌟', '🚀', '😎'];
  const avatarValue = String(identity.avatar || '🎮');
  // Profile pictures are small data URLs created by this game's avatar picker.
  // Cap the length so a peer cannot make room-state messages unnecessarily large.
  const uploadedAvatar = avatarValue.length <= 24000 && /^data:image\/(?:jpeg|png|webp);base64,[a-z0-9+/=]+$/i.test(avatarValue);
  return {
    nickname,
    userId: String(identity.userId || 'RR-ANONIMO').slice(0, 32),
    avatar: allowedAvatars.includes(avatarValue) || uploadedAvatar ? avatarValue : '🎮',
    characterId,
    mapSeed: (Number(identity.mapSeed) >>> 0) || 1
  };
}

function makeSessionId(prefix = 'p') {
  return `${prefix}_${randomToken(10)}`;
}

function normalizeInput(value = {}) {
  const n = (v) => Number.isFinite(Number(v)) ? Math.max(-1, Math.min(1, Number(v))) : 0;
  return {
    forward: n(value.forward),
    right: n(value.right),
    yaw: Number.isFinite(Number(value.yaw)) ? Number(value.yaw) : 0,
    run: !!value.run,
    jump: !!value.jump
  };
}

function createRoomHandle({ roomId, sessionId, peer, role, connection = null }) {
  const listeners = new Map();
  const leaveListeners = new Set();
  const errorListeners = new Set();
  let closed = false;
  let latestSnapshot = null;
  let latestLobby = null;
  const room = {
    roomId,
    sessionId,
    role,
    visibility: 'private',
    onMessage(type, callback) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type).add(callback);
      if (type === 'snapshot' && latestSnapshot) callback(latestSnapshot);
      if (type === 'lobby' && latestLobby) callback(latestLobby);
      return () => listeners.get(type)?.delete(callback);
    },
    onLeave(callback) { leaveListeners.add(callback); return () => leaveListeners.delete(callback); },
    onError(callback) { errorListeners.add(callback); return () => errorListeners.delete(callback); },
    send(type, data) {
      if (closed) return;
      if (role === 'host') {
        if (type === 'input') updateHostInput(sessionId, data);
        else if (type === 'lobby:action') handleLobbyAction(room, sessionId, data || {});
      } else if (connection?.open) {
        connection.send({ kind: 'message', type, data });
      }
    },
    getLobbyState() { return latestLobby; },
    _setLobbyState(state) { latestLobby = state; },
    async exitLobby() {
      if (closed) return;
      if (role === 'host') {
        parkHostPlayer(room);
        // Keep the technical PeerJS host alive as a quiet relay while other
        // players remain; the visible host role is transferred in room state.
        listeners.clear(); leaveListeners.clear(); errorListeners.clear();
        return;
      }
      try {
        if (connection?.open) {
          connection.send({ kind: 'message', type: 'lobby:action', data: { action: 'leave' } });
          await new Promise(resolve => setTimeout(resolve, 130));
        }
      } catch {}
      closed = true;
      try { connection?.close(); } catch {}
      try { peer?.destroy(); } catch {}
      listeners.clear(); leaveListeners.clear(); errorListeners.clear();
    },
    async leave() {
      if (closed) return;
      closed = true;
      if (role === 'host') {
        clearInterval(room._ticker);
        activeHostRooms.delete(sessionId);
        for (const conn of room._connections?.values() || []) { try { conn.close(); } catch {} }
      } else {
        try { connection?.close(); } catch {}
      }
      try { peer?.destroy(); } catch {}
      listeners.clear(); leaveListeners.clear(); errorListeners.clear();
    },
    _emit(type, data) {
      if (type === 'snapshot') latestSnapshot = data;
      if (type === 'lobby') latestLobby = data;
      for (const callback of listeners.get(type) || []) {
        try { callback(data); } catch (error) { console.error('Erro ao receber mensagem multiplayer:', error); }
      }
    },
    _emitLeave(code = 0) {
      if (closed) return;
      for (const callback of leaveListeners) { try { callback(code); } catch {} }
    },
    _emitError(error) {
      const normalized = friendlyPeerError(error, 'sala');
      for (const callback of errorListeners) { try { callback(error?.type || 'network', normalized.message); } catch {} }
    },
    _isClosed: () => closed,
    _markClosed() { closed = true; },
    _setSessionId(id) { room.sessionId = id; },
    _setLatestSnapshot(snapshot) { latestSnapshot = snapshot; },
    _connections: new Map(),
    _peer: peer,
    _players: new Map(),
    _logicalHostSessionId: sessionId,
    _phase: 'lobby',
    _hostParked: false,
    _joinCounter: 0,
    _input: null,
    _mapSeed: 1,
    _ticker: null
  };
  return room;
}

function updateHostInput(sessionId, input) {
  const room = activeHostRooms.get(sessionId);
  if (!room) return;
  const player = room._players.get(sessionId);
  if (player) player.input = normalizeInput(input);
}

// Host rooms are indexed by the host's local sessionId so the game can call
// room.send('input', ...) using the same small API that it already expects.
const activeHostRooms = new Map();

function spawnPlayerState(identity, sessionId, index) {
  const radius = index === 0 ? 0 : 3 + Math.floor(index / 4) * 1.5;
  const angle = index * 2.399963229728653;
  return {
    sessionId,
    name: identity.nickname,
    userId: identity.userId,
    avatar: identity.avatar,
    characterId: identity.characterId,
    joinedOrder: index,
    x: Math.sin(angle) * radius,
    y: 0,
    z: Math.cos(angle) * radius,
    yaw: 0,
    speed: 0,
    moving: false,
    running: false,
    jumping: false,
    vy: 0,
    grounded: true,
    previousJump: false,
    input: { forward: 0, right: 0, yaw: 0, run: false, jump: false }
  };
}

function simulatePlayer(player, dt) {
  const input = player.input || normalizeInput();
  const forward = input.forward;
  const right = input.right;
  let dx = Math.sin(input.yaw) * forward + Math.cos(input.yaw) * right;
  let dz = -Math.cos(input.yaw) * forward + Math.sin(input.yaw) * right;
  const length = Math.hypot(dx, dz);
  if (length > 1) { dx /= length; dz /= length; }
  const isMoving = length > 0.01;
  const speed = input.run ? 10 : 6.4;
  if (isMoving) {
    player.x = Math.max(-253, Math.min(253, player.x + dx * speed * dt));
    player.z = Math.max(-253, Math.min(253, player.z + dz * speed * dt));
    player.yaw = Math.atan2(dx, -dz);
  } else {
    player.yaw = input.yaw;
  }
  player.speed = isMoving ? speed * Math.min(1, length) : 0;
  player.moving = isMoving;
  player.running = !!(isMoving && input.run);

  if (input.jump && !player.previousJump && player.grounded) {
    player.vy = 7.4;
    player.grounded = false;
  }
  if (!player.grounded) {
    player.vy -= 20 * dt;
    player.y += player.vy * dt;
    if (player.y <= 0) { player.y = 0; player.vy = 0; player.grounded = true; }
  }
  player.jumping = !player.grounded;
  player.previousJump = input.jump;
}

function publicPlayerState(player) {
  return {
    sessionId: player.sessionId,
    name: player.name,
    userId: player.userId,
    avatar: player.avatar,
    characterId: player.characterId,
    joinedOrder: player.joinedOrder,
    x: player.x, y: player.y, z: player.z, yaw: player.yaw,
    speed: player.speed, moving: player.moving, running: player.running, jumping: player.jumping
  };
}

function makeLobbyState(room) {
  return {
    roomId: room.roomId,
    title: 'RETARDADOS ROYALE',
    visibility: room.visibility === 'public' ? 'public' : 'private',
    phase: room._phase || 'lobby',
    hostSessionId: room._logicalHostSessionId,
    maxPlayers: MAX_PLAYERS,
    players: [...room._players.values()].map(player => ({
      sessionId: player.sessionId,
      name: player.name,
      userId: player.userId,
      avatar: player.avatar,
      characterId: player.characterId,
      joinedOrder: Number(player.joinedOrder) || 0
    })).sort((a, b) => a.joinedOrder - b.joinedOrder)
  };
}

function broadcastLobby(room, announcement = '') {
  if (!room || room._isClosed()) return;
  const state = { ...makeLobbyState(room), announcement };
  room._setLobbyState(state);
  room._emit('lobby', state);
  for (const connection of room._connections.values()) {
    if (!connection.open) continue;
    try { connection.send({ kind: 'event', type: 'lobby', data: state }); } catch {}
  }
}

function promoteLogicalHost(room, leavingSessionId = '') {
  if (room._logicalHostSessionId && room._logicalHostSessionId !== leavingSessionId && room._players.has(room._logicalHostSessionId)) return;
  const next = [...room._players.values()]
    .filter(player => player.sessionId !== leavingSessionId)
    .sort((a, b) => a.joinedOrder - b.joinedOrder)[0];
  room._logicalHostSessionId = next?.sessionId || '';
}

function shutdownHostRoom(room) {
  if (!room || room._isClosed()) return;
  room._markClosed?.();
  clearInterval(room._ticker);
  activeHostRooms.delete(room.sessionId);
  for (const connection of room._connections.values()) { try { connection.close(); } catch {} }
  room._connections.clear();
  try { room._peer?.destroy?.(); } catch {}
}

function parkHostPlayer(room) {
  if (!room || room.role !== 'host' || room._hostParked || room._isClosed()) return;
  const leavingId = room.sessionId;
  room._players.delete(leavingId);
  room._hostParked = true;
  promoteLogicalHost(room, leavingId);
  broadcastLobby(room, 'host-left');
  if (room._players.size === 0) shutdownHostRoom(room);
}

function removeGuestPlayer(room, sessionId, { announcement = 'player-left' } = {}) {
  const connection = room._connections.get(sessionId);
  if (connection) {
    room._connections.delete(sessionId);
    connection.__rrSessionId = null;
  }
  room._players.delete(sessionId);
  if (room._logicalHostSessionId === sessionId) promoteLogicalHost(room, sessionId);
  broadcastLobby(room, announcement);
  if (room._hostParked && room._players.size === 0) shutdownHostRoom(room);
}

function handleLobbyAction(room, actorSessionId, payload = {}) {
  if (!room || room._isClosed()) return false;
  const action = String(payload.action || '');
  // Every room-management action is checked against the server-side logical
  // host ID; a guest cannot grant itself host privileges by changing UI state.
  if (action !== 'leave' && actorSessionId !== room._logicalHostSessionId) return false;
  if (action === 'start') {
    if (room._phase !== 'lobby' || room._players.size < 1) return false;
    room._phase = 'match';
    broadcastLobby(room, 'match-started');
    return true;
  }
  if (action === 'kick') {
    if (room._phase !== 'lobby') return false;
    const targetId = String(payload.targetSessionId || '');
    if (!targetId || targetId === room._logicalHostSessionId || !room._players.has(targetId)) return false;
    const connection = room._connections.get(targetId);
    if (!connection?.open) return false;
    try { connection.send({ kind: 'event', type: 'lobby:kicked', data: { reason: 'Você foi removido da sala pelo anfitrião.' } }); } catch {}
    setTimeout(() => { try { connection.close(); } catch {} }, 120);
    return true;
  }
  if (action === 'transfer') {
    if (room._phase !== 'lobby') return false;
    const targetId = String(payload.targetSessionId || '');
    if (!targetId || targetId === actorSessionId || !room._players.has(targetId)) return false;
    room._logicalHostSessionId = targetId;
    broadcastLobby(room, 'host-transferred');
    return true;
  }
  if (action === 'leave') {
    // The leaving guest can only remove itself. If it was host, the oldest
    // remaining participant is promoted before the departing connection closes.
    if (!room._players.has(actorSessionId)) return false;
    if (actorSessionId === room.sessionId && room.role === 'host') {
      parkHostPlayer(room);
      return true;
    }
    removeGuestPlayer(room, actorSessionId, { announcement: 'player-left' });
    const connection = room._connections.get(actorSessionId);
    if (connection) setTimeout(() => { try { connection.close(); } catch {} }, 100);
    return true;
  }
  return false;
}

async function createHostRoom(options = {}, visibility = 'private') {
  const Peer = await loadPeerSdk();
  let peer, room, roomCode;
  let lastError;
  for (let attempt = 0; attempt < 3; attempt++) {
    roomCode = createRoomCode();
    peer = new Peer(roomCode, PEER_OPTIONS);
    try {
      await waitForPeerOpen(peer);
      lastError = null;
      break;
    } catch (error) {
      lastError = error;
      try { peer.destroy(); } catch {}
      if (error?.type !== 'unavailable-id' && !/já está sendo usado/i.test(error?.message || '')) throw error;
    }
  }
  if (lastError) throw friendlyPeerError(lastError, 'criação da sala');

  const identity = cleanIdentity(options);
  const sessionId = makeSessionId('host');
  const mapSeed = identity.mapSeed;
  room = createRoomHandle({ roomId: roomCode, sessionId, peer, role: 'host' });
  room.visibility = visibility;
  room._mapSeed = mapSeed;
  room._players.set(sessionId, spawnPlayerState(identity, sessionId, 0));
  room._joinCounter = 1;
  activeHostRooms.set(sessionId, room);

  function snapshot() {
    return { mapSeed: room._mapSeed, players: [...room._players.values()].map(publicPlayerState) };
  }
  function broadcast() {
    if (room._isClosed()) return;
    const state = snapshot();
    room._setLatestSnapshot(state);
    room._emit('snapshot', state);
    for (const connection of room._connections.values()) {
      if (!connection.open) continue;
      try { connection.send({ kind: 'event', type: 'snapshot', data: state }); } catch {}
    }
  }
  function removeConnection(connection) {
    const sessionIdForConnection = connection.__rrSessionId;
    if (!sessionIdForConnection) return;
    room._connections.delete(sessionIdForConnection);
    room._players.delete(sessionIdForConnection);
    connection.__rrSessionId = null;
    if (room._logicalHostSessionId === sessionIdForConnection) promoteLogicalHost(room, sessionIdForConnection);
    broadcast();
    broadcastLobby(room, 'player-left');
    if (room._hostParked && room._players.size === 0) shutdownHostRoom(room);
  }

  peer.on('connection', (connection) => {
    let joined = false;
    const joinTimer = setTimeout(() => {
      if (!joined) { try { connection.close(); } catch {} }
    }, 12000);
    connection.on('data', (message) => {
      if (!message || typeof message !== 'object') return;
      if (message.kind === 'join' && !joined) {
        if (room._phase !== 'lobby') {
          try { connection.send({ kind: 'reject', reason: 'A partida já começou. Peça ao anfitrião um novo código de sala.' }); } catch {}
          try { connection.close(); } catch {}
          return;
        }
        if (room._players.size >= MAX_PLAYERS) {
          try { connection.send({ kind: 'reject', reason: 'A sala está cheia (máximo de 8 jogadores).' }); } catch {}
          try { connection.close(); } catch {}
          return;
        }
        joined = true;
        clearTimeout(joinTimer);
        const guestIdentity = cleanIdentity(message.identity || {});
        const guestSessionId = makeSessionId('player');
        connection.__rrSessionId = guestSessionId;
        room._connections.set(guestSessionId, connection);
        room._players.set(guestSessionId, spawnPlayerState(guestIdentity, guestSessionId, room._joinCounter++));
        try { connection.send({ kind: 'welcome', roomId: room.roomId, sessionId: guestSessionId, visibility: room.visibility }); } catch {}
        broadcast();
        broadcastLobby(room, 'player-joined');
        return;
      }
      const guestSessionId = connection.__rrSessionId;
      if (!guestSessionId || !joined || message.kind !== 'message') return;
      if (message.type === 'input') {
        const playerState = room._players.get(guestSessionId);
        if (playerState) playerState.input = normalizeInput(message.data);
      } else if (message.type === 'lobby:action') {
        handleLobbyAction(room, guestSessionId, message.data || {});
      }
    });
    connection.on('close', () => { clearTimeout(joinTimer); removeConnection(connection); });
    connection.on('error', () => { clearTimeout(joinTimer); removeConnection(connection); });
  });
  peer.on('error', (error) => room?._emitError(error));
  room._ticker = setInterval(() => {
    const dt = SNAPSHOT_INTERVAL_MS / 1000;
    for (const playerState of room._players.values()) simulatePlayer(playerState, dt);
    broadcast();
  }, SNAPSHOT_INTERVAL_MS);
  broadcast();
  broadcastLobby(room, 'room-created');
  return room;
}

async function joinHostRoom(roomId, options = {}) {
  const code = String(roomId || '').trim().toUpperCase();
  if (!/^RR[A-HJ-NP-Z2-9]{6}$/.test(code)) {
    throw new Error('Código inválido. O código de sala deve ter 8 caracteres e começar com RR.');
  }
  const Peer = await loadPeerSdk();
  const peer = new Peer(undefined, PEER_OPTIONS);
  try {
    await waitForPeerOpen(peer);
  } catch (error) {
    try { peer.destroy(); } catch {}
    throw friendlyPeerError(error, 'conexão inicial');
  }

  const identity = cleanIdentity(options);
  const connection = peer.connect(code, { reliable: true, serialization: 'json', metadata: { game: 'retardados-royale' } });
  const room = createRoomHandle({ roomId: code, sessionId: '', peer, role: 'guest', connection });

  try {
    await new Promise((resolve, reject) => {
      let settled = false;
      let opened = false;
      const timer = setTimeout(() => finish(reject, new Error('A sala não respondeu. Confira o código e peça ao anfitrião para manter o jogo aberto.')), 20000);
      function finish(callback, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        callback(value);
      }
      connection.on('open', () => {
        opened = true;
        try { connection.send({ kind: 'join', identity }); }
        catch (error) { finish(reject, friendlyPeerError(error, 'entrada na sala')); }
      });
      connection.on('data', (message) => {
        if (!message || typeof message !== 'object') return;
        if (message.kind === 'reject') {
          finish(reject, new Error(String(message.reason || 'O anfitrião recusou a entrada na sala.')));
          return;
        }
        if (message.kind === 'welcome') {
          room._setSessionId(String(message.sessionId || ''));
          room.roomId = String(message.roomId || code);
          room.visibility = message.visibility === 'public' ? 'public' : 'private';
          finish(resolve, room);
          return;
        }
        if (message.kind === 'event' && typeof message.type === 'string') room._emit(message.type, message.data);
      });
      connection.on('close', () => {
        finish(reject, new Error(opened ? 'O anfitrião encerrou a sala antes de concluir a entrada.' : 'Não consegui conectar à sala. Confira o código e tente novamente.'));
        room._emitLeave(0);
      });
      connection.on('error', (error) => finish(reject, friendlyPeerError(error, 'entrada na sala')));
      peer.on('error', (error) => {
        if (!settled) finish(reject, friendlyPeerError(error, 'entrada na sala'));
        else room._emitError(error);
      });
    });
    return room;
  } catch (error) {
    try { connection.close(); } catch {}
    try { peer.destroy(); } catch {}
    throw friendlyPeerError(error, 'entrada na sala');
  }
}

export async function createPrivateRoom(options = {}) {
  return createHostRoom(options, 'private');
}

export async function createPublicRoom(options = {}) {
  return createHostRoom(options, 'public');
}

// PeerJS Cloud provides signaling, not a global room directory. Keep the UI
// API stable, but return no discoverable rooms instead of showing a fake list.
export async function listPublicRooms() {
  return [];
}

export async function joinRoomByCode(roomId, options = {}) {
  return joinHostRoom(roomId, options);
}

export async function joinPrivateRoom(roomId, options = {}) {
  return joinRoomByCode(roomId, options);
}

export function leaveRoom(room) {
  if (!room) return Promise.resolve();
  try { return Promise.resolve(room.leave()); }
  catch (error) { return Promise.reject(error); }
}
