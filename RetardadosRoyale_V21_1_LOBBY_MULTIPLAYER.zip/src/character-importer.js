/* Retardados Royale - importação local de personagens GLB/glTF.
 * Arquivos do usuário permanecem no navegador (IndexedDB); não há upload remoto.
 */
export const IMPORT_MAX_FILE_BYTES = 80 * 1024 * 1024;
export const IMPORT_MAX_TOTAL_BYTES = 100 * 1024 * 1024;
export const IMPORT_MAX_FILES = 32;
const DB_NAME = 'retardados-royale-character-imports';
const DB_VERSION = 1;
const META_STORE = 'characters';
const FILE_STORE = 'bundles';

let gltfLoaderConstructorPromise;
let skeletonCloneFunctionPromise;

export function getExtension(filename = '') {
  const clean = String(filename).split(/[?#]/, 1)[0];
  const index = clean.lastIndexOf('.');
  return index >= 0 ? clean.slice(index).toLowerCase() : '';
}

export function validateFileSelection(files, mainName) {
  if (!Array.isArray(files) || files.length === 0) throw new Error('Selecione um arquivo .glb ou .gltf.');
  if (files.length > IMPORT_MAX_FILES) throw new Error(`Selecione no máximo ${IMPORT_MAX_FILES} arquivos, incluindo as dependências.`);
  const main = files.find(file => file.name === mainName);
  if (!main) throw new Error('O arquivo principal não foi encontrado na seleção.');
  const extension = getExtension(main.name);
  if (!['.glb', '.gltf'].includes(extension)) {
    if (extension === '.fbx') throw new Error('FBX não está habilitado nesta versão, pois o carregador ainda não foi integrado e testado de forma confiável. Exporte o modelo como GLB.');
    throw new Error('Formato não suportado. Use GLB ou glTF.');
  }
  let total = 0;
  for (const file of files) {
    if (!file || typeof file.size !== 'number' || !file.name) throw new Error('A seleção contém um arquivo inválido.');
    if (file.size > IMPORT_MAX_FILE_BYTES) throw new Error(`O arquivo “${file.name}” excede o limite de 80 MB.`);
    total += file.size;
  }
  if (total > IMPORT_MAX_TOTAL_BYTES) throw new Error('O conjunto selecionado excede 100 MB. Reduza o tamanho do modelo e das texturas.');
  const names = new Set();
  for (const file of files) {
    const key = String(file.name).toLocaleLowerCase();
    if (names.has(key)) throw new Error(`Há arquivos com nomes repetidos (“${file.name}”). Selecione as dependências sem duplicatas.`);
    names.add(key);
  }
  return { main, extension, totalBytes: total };
}

export function classifyAnimationName(name = '') {
  const n = String(name).toLowerCase().replace(/[^a-z0-9]+/g, ' ');
  if (/\b(idle|stand|standing|rest|breath|neutral)\b/.test(n)) return 'idle';
  if (/\b(walk|walking|walkcycle)\b/.test(n)) return 'walk';
  if (/\b(run|running|sprint|jog)\b/.test(n)) return 'run';
  if (/\b(jump|jumping|takeoff)\b/.test(n)) return 'jump';
  if (/\b(fall|falling|inair|airborne)\b/.test(n)) return 'fall';
  if (/\b(land|landing|touchdown)\b/.test(n)) return 'land';
  if (/\b(hold|holding|carry|carrying|ready|neutral pose|generic pose)\b/.test(n)) return 'hold';
  return null;
}

function openDatabase() {
  if (!globalThis.indexedDB) return Promise.reject(new Error('Este navegador não disponibiliza IndexedDB. A importação persistente exige um navegador moderno e uma origem HTTPS/localhost.'));
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(FILE_STORE)) db.createObjectStore(FILE_STORE, { keyPath: 'characterId' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Não foi possível abrir o banco local de personagens.'));
    request.onblocked = () => reject(new Error('O armazenamento de personagens está bloqueado por outra aba. Feche outras abas do jogo e tente novamente.'));
  });
}

function requestAsPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Falha no banco local de personagens.'));
  });
}

export async function listImportedCharacterMetadata() {
  const db = await openDatabase();
  try {
    const tx = db.transaction(META_STORE, 'readonly');
    const values = await requestAsPromise(tx.objectStore(META_STORE).getAll());
    return values.sort((a, b) => (a.createdAt || '').localeCompare(b.createdAt || ''));
  } finally { db.close(); }
}

export async function updateImportedCharacterMetadata(meta) {
  if (!meta?.id) throw new Error('Metadados do personagem inválidos.');
  const db = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(META_STORE, 'readwrite');
      tx.objectStore(META_STORE).put(meta);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('Não foi possível atualizar as configurações do personagem.'));
      tx.onabort = () => reject(tx.error || new Error('A atualização das configurações foi cancelada.'));
    });
  } finally { db.close(); }
}

export async function saveImportedCharacter(meta, files) {
  const db = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction([META_STORE, FILE_STORE], 'readwrite');
      tx.objectStore(META_STORE).put(meta);
      tx.objectStore(FILE_STORE).put({
        characterId: meta.id,
        mainName: meta.mainName,
        files: files.map(file => ({ name: file.name, type: file.type || 'application/octet-stream', blob: file.blob || file }))
      });
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('Não foi possível salvar o personagem no armazenamento local.'));
      tx.onabort = () => reject(tx.error || new Error('O salvamento do personagem foi cancelado pelo navegador.'));
    });
  } finally { db.close(); }
}

export async function getImportedCharacterFiles(id) {
  const db = await openDatabase();
  try {
    const tx = db.transaction(FILE_STORE, 'readonly');
    const item = await requestAsPromise(tx.objectStore(FILE_STORE).get(id));
    if (!item?.files?.length) throw new Error('Os arquivos deste personagem não foram encontrados no armazenamento local. Talvez tenham sido removidos pelo navegador.');
    return { mainName: item.mainName, files: item.files.map(f => new File([f.blob], f.name, { type: f.type || 'application/octet-stream' })) };
  } finally { db.close(); }
}

export async function removeImportedCharacter(id) {
  const db = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction([META_STORE, FILE_STORE], 'readwrite');
      tx.objectStore(META_STORE).delete(id);
      tx.objectStore(FILE_STORE).delete(id);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('Não foi possível remover o personagem.'));
      tx.onabort = () => reject(tx.error || new Error('A remoção foi cancelada pelo navegador.'));
    });
  } finally { db.close(); }
}

async function getGLTFLoader() {
  if (!gltfLoaderConstructorPromise) {
    gltfLoaderConstructorPromise = import('https://esm.sh/three@0.180.0/examples/jsm/loaders/GLTFLoader.js?bundle')
      .then(module => {
        if (typeof module.GLTFLoader !== 'function') throw new Error('O módulo GLTFLoader não foi carregado corretamente.');
        return module.GLTFLoader;
      }).catch(error => {
        gltfLoaderConstructorPromise = null;
        throw new Error(`Não foi possível carregar o leitor GLB/glTF. Confira a conexão com o CDN do Three.js. Detalhes: ${error?.message || error}`);
      });
  }
  return gltfLoaderConstructorPromise;
}

async function getSkeletonClone() {
  if (!skeletonCloneFunctionPromise) {
    skeletonCloneFunctionPromise = import('https://esm.sh/three@0.180.0/examples/jsm/utils/SkeletonUtils.js?bundle')
      .then(module => {
        const clone = module.clone || module.SkeletonUtils?.clone;
        if (typeof clone !== 'function') throw new Error('A função de cópia de esqueletos não está disponível.');
        return clone;
      }).catch(error => {
        skeletonCloneFunctionPromise = null;
        throw new Error(`Não foi possível preparar a cópia segura de personagens com esqueleto. Detalhes: ${error?.message || error}`);
      });
  }
  return skeletonCloneFunctionPromise;
}

export function validateGltfJson(fileBuffer, extension) {
  if (extension !== '.gltf') return;
  let json;
  try { json = JSON.parse(new TextDecoder().decode(fileBuffer)); }
  catch { throw new Error('O arquivo .gltf não contém JSON válido ou está corrompido.'); }
  if (!json?.asset?.version?.startsWith('2')) throw new Error('O arquivo precisa estar no formato glTF 2.x.');
  const resources = [...(json.buffers || []), ...(json.images || [])];
  const remote = resources.find(item => typeof item.uri === 'string' && /^(https?:)?\/\//i.test(item.uri));
  if (remote) throw new Error('Este .gltf referencia recursos remotos. Por segurança, o importador não os busca na internet; baixe os arquivos dependentes e use referências locais.');
}

export function inspectRig(root, animations = [], THREE = null) {
  let meshes = 0, weightedMeshes = 0, vertexCount = 0, weightedVertexCount = 0;
  const boneMap = new Map();
  const meshCountLimit = 2_000_000;
  root?.traverse?.(object => {
    if (object.isBone) boneMap.set(object.uuid, object);
    if (!object.isMesh && !object.isSkinnedMesh) return;
    meshes++;
    const geometry = object.geometry;
    const positions = geometry?.attributes?.position;
    vertexCount += positions?.count || 0;
    if (object.isSkinnedMesh && object.skeleton?.bones?.length) {
      const indices = geometry?.attributes?.skinIndex;
      const weights = geometry?.attributes?.skinWeight;
      if (indices && weights && positions && indices.count === positions.count && weights.count === positions.count) {
        const count = Math.min(weights.count, 5000);
        let weighted = false;
        for (let i = 0; i < count && !weighted; i++) {
          const values = [weights.getX(i), weights.getY(i), weights.getZ(i), weights.getW(i)];
          if (values.some(value => Number.isFinite(value) && value > 0.0001)) weighted = true;
        }
        if (weighted) { weightedMeshes++; weightedVertexCount += positions.count; }
      }
    }
  });
  const bones = [...boneMap.values()];
  const hasRig = weightedMeshes > 0 && bones.length > 0;
  const normalized = bones.map(b => String(b.name || '').toLowerCase().replace(/[^a-z0-9]/g, ''));
  const hasHead = normalized.some(n => /head|skull/.test(n));
  const hasSpine = normalized.some(n => /spine|chest|upperbody|torso/.test(n));
  const hasLeftArm = normalized.some(n => /(left|^l)(upperarm|arm|shoulder|clavicle)/.test(n) || /leftarm|leftshoulder|leftclavicle/.test(n));
  const hasRightArm = normalized.some(n => /(right|^r)(upperarm|arm|shoulder|clavicle)/.test(n) || /rightarm|rightshoulder|rightclavicle/.test(n));
  const hasLeftLeg = normalized.some(n => /(left|^l)(upleg|upperleg|thigh|leg)/.test(n) || /leftupleg|leftupperleg|leftthigh/.test(n));
  const hasRightLeg = normalized.some(n => /(right|^r)(upleg|upperleg|thigh|leg)/.test(n) || /rightupleg|rightupperleg|rightthigh/.test(n));
  const recognizableHumanoid = hasHead && (hasSpine || bones.length >= 8) && hasLeftArm && hasRightArm && hasLeftLeg && hasRightLeg;
  // Estimate silhouette only to decide whether to offer a rigging explanation; this is not proof of a human model.
  let size = { x: 0, y: 0, z: 0 };
  try { if (THREE && root) { root.updateMatrixWorld?.(true); const bounds = new THREE.Box3().setFromObject(root); size = bounds.getSize(new THREE.Vector3()); } } catch {}
  const heightToWidth = size.y / Math.max(size.x, size.z, 0.0001);
  const appearsHumanoid = !hasRig && !!root && vertexCount >= 30 && size.y >= 0.5 && heightToWidth >= 1.15;
  const animationRoles = {};
  for (const clip of animations || []) {
    const role = classifyAnimationName(clip?.name || '');
    if (role && !animationRoles[role]) animationRoles[role] = String(clip.name || role);
  }
  const report = {
    hasRig, hasSkinWeights: weightedMeshes > 0, skinnedMeshCount: weightedMeshes,
    boneCount: bones.length, vertexCount, animationCount: animations?.length || 0,
    animationNames: (animations || []).map(clip => String(clip?.name || 'Animação sem nome')).slice(0, 60),
    animationRoles, recognizableHumanoid, appearsHumanoid,
    humanoid: hasRig && recognizableHumanoid,
    classification: !hasRig ? 'static' : recognizableHumanoid ? 'humanoid-rig' : 'rig-not-confirmed-humanoid'
  };
  return report;
}

function createURLResolver(files, mainName) {
  const map = new Map();
  const urls = [];
  for (const file of files) {
    if (file.name === mainName) continue;
    const url = URL.createObjectURL(file);
    urls.push(url);
    map.set(String(file.name).toLocaleLowerCase(), url);
  }
  const modifier = (url) => {
    if (/^(data:|blob:)/i.test(url)) return url;
    if (/^(https?:)?\/\//i.test(url)) throw new Error('O arquivo tenta carregar um recurso da internet. O importador aceita apenas arquivos locais selecionados por você.');
    const clean = decodeURIComponent(String(url).split(/[?#]/, 1)[0]).replace(/\\/g, '/');
    const basename = clean.split('/').filter(Boolean).pop()?.toLocaleLowerCase();
    const found = map.get(basename);
    if (!found) throw new Error(`Falta selecionar a dependência “${basename || clean}” usada pelo .gltf. Selecione o .gltf e todos os arquivos .bin/texturas na mesma seleção.`);
    return found;
  };
  return { modifier, urls };
}

function validateModelComplexity(scene) {
  let vertices = 0, meshes = 0;
  scene?.traverse?.(object => {
    if (!object.isMesh && !object.isSkinnedMesh) return;
    meshes++;
    vertices += object.geometry?.attributes?.position?.count || 0;
  });
  if (!meshes || !vertices) throw new Error('O arquivo não contém nenhuma malha 3D com vértices utilizáveis.');
  if (vertices > 2_000_000) throw new Error('Este modelo tem mais de 2 milhões de vértices e foi bloqueado para reduzir o risco de travar o navegador. Otimize o modelo e tente novamente.');
  return { meshes, vertices };
}

export async function parseCharacterFiles(files, mainName, THREE) {
  if (!Array.isArray(files)) files = Array.from(files || []);
  const checked = validateFileSelection(files, mainName);
  const mainBuffer = await checked.main.arrayBuffer();
  validateGltfJson(mainBuffer, checked.extension);
  const GLTFLoader = await getGLTFLoader();
  const cloneScene = await getSkeletonClone();
  const manager = new THREE.LoadingManager();
  const resolver = createURLResolver(files, mainName);
  manager.setURLModifier(resolver.modifier);
  try {
    const loader = new GLTFLoader(manager);
    let gltf;
    try { gltf = await loader.parseAsync(mainBuffer, ''); }
    catch (error) {
      const message = String(error?.message || error);
      throw new Error(/404|not found|failed to fetch|network|uri|loading/i.test(message)
        ? `Não foi possível carregar uma dependência do modelo. Em arquivos .gltf, selecione junto o arquivo .bin e todas as texturas referenciadas. Detalhes: ${message}`
        : `O modelo não pôde ser interpretado como GLB/glTF válido. Detalhes: ${message}`);
    }
    const scene = gltf?.scene || gltf?.scenes?.[0];
    if (!scene) throw new Error('O arquivo não contém uma cena 3D principal.');
    const complexity = validateModelComplexity(scene);
    const rig = inspectRig(scene, gltf.animations || [], THREE);
    // Don't auto-create a skeleton here. The UI must ask first, and no trustworthy local auto-rigger is bundled.
    return { scene, scenes: gltf.scenes || [scene], animations: gltf.animations || [], rig, complexity, cloneScene, format: checked.extension.slice(1).toUpperCase(), fileNames: files.map(file => file.name), mainName };
  } finally {
    for (const url of resolver.urls) URL.revokeObjectURL(url);
  }
}

export async function parseStoredCharacter(id, THREE) {
  const bundle = await getImportedCharacterFiles(id);
  const parsed = await parseCharacterFiles(bundle.files, bundle.mainName, THREE);
  return { ...parsed, fileNames: bundle.files.map(file => file.name) };
}

export function cloneImportedScene(asset) {
  if (!asset?.scene || typeof asset.cloneScene !== 'function') throw new Error('O modelo importado não está pronto para ser duplicado.');
  return asset.cloneScene(asset.scene);
}

export function disposeThreeObject(root) {
  const geometries = new Set(), materials = new Set(), textures = new Set();
  root?.traverse?.(object => {
    if (object.geometry) geometries.add(object.geometry);
    const list = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
    for (const material of list) {
      materials.add(material);
      for (const value of Object.values(material)) if (value?.isTexture) textures.add(value);
    }
  });
  for (const texture of textures) texture.dispose?.();
  for (const geometry of geometries) geometry.dispose?.();
  for (const material of materials) material.dispose?.();
}
