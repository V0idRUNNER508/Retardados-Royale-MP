// Pure daily-mission rules. Kept separate so expiration and progress can be tested without WebGL.
export const DAILY_MISSION_LIFETIME_MS = 24 * 60 * 60 * 1000;
export const DAILY_MISSION_TEMPLATES = Object.freeze([
  Object.freeze({ type: 'kills', name: 'Caçada expressa', desc: 'Elimine 3 adversários dentro de partidas.', goal: 3, reward: 85 }),
  Object.freeze({ type: 'damage', name: 'Mira aquecida', desc: 'Cause 250 pontos de dano aos adversários.', goal: 250, reward: 80 }),
  Object.freeze({ type: 'survive', name: 'Fique na arena', desc: 'Acumule 5 minutos vivo durante partidas.', goal: 300, reward: 90 })
]);

export function ensureDailyMissionRecord(current, now = Date.now(), random = Math.random) {
  const valid = current
    && DAILY_MISSION_TEMPLATES.some((mission) => mission.type === current.type)
    && Number.isFinite(Number(current.expiresAt))
    && Number(current.expiresAt) > now
    && Number.isFinite(Number(current.progress));
  if (valid) return { mission: current, changed: false };

  const pool = DAILY_MISSION_TEMPLATES.filter((mission) => mission.type !== current?.type);
  const choices = pool.length ? pool : DAILY_MISSION_TEMPLATES;
  const sample = Number(random());
  const index = Math.max(0, Math.min(choices.length - 1, Math.floor((Number.isFinite(sample) ? sample : 0) * choices.length)));
  const template = choices[index];
  return {
    changed: true,
    mission: {
      id: `daily-${now}-${template.type}`,
      type: template.type,
      name: template.name,
      desc: template.desc,
      goal: template.goal,
      reward: template.reward,
      progress: 0,
      generatedAt: now,
      expiresAt: now + DAILY_MISSION_LIFETIME_MS,
      claimed: false
    }
  };
}

export function incrementDailyMission(mission, type, amount = 1) {
  const value = Number(amount);
  if (!mission || mission.type !== type || mission.claimed || mission.progress >= mission.goal || !Number.isFinite(value) || value <= 0) return false;
  const before = Number(mission.progress) || 0;
  mission.progress = Math.min(Number(mission.goal), before + value);
  return mission.progress !== before;
}

export function formatDailyMissionTime(milliseconds) {
  const total = Math.max(0, Math.ceil(Number(milliseconds) / 1000) || 0);
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return hours > 0 ? `${hours}h ${String(minutes).padStart(2, '0')}m` : `${minutes}m ${String(seconds).padStart(2, '0')}s`;
}
