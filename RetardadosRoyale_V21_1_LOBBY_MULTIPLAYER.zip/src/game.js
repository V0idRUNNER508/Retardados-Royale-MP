import { generateArenaLayout } from '../shared/arena-layout.js';
import { createPrivateRoom, createPublicRoom, listPublicRooms, joinPrivateRoom, joinRoomByCode, leaveRoom } from './multiplayer-client.js';
import { classifyAnimationName, cloneImportedScene, disposeThreeObject, listImportedCharacterMetadata, parseCharacterFiles, parseStoredCharacter, removeImportedCharacter, saveImportedCharacter, updateImportedCharacterMetadata } from './character-importer.js';
import { ensureDailyMissionRecord, incrementDailyMission, formatDailyMissionTime } from './profile-missions.js';

// Carregamento resiliente do Three.js: usa vários provedores independentes.
// O projeto mantém uma versão fixada (0.180.0) para evitar mudanças incompatíveis.
const THREE_CDNS = [
  { name: 'esm.sh', url: 'https://esm.sh/three@0.180.0?bundle' },
  { name: 'esm.run', url: 'https://esm.run/three@0.180.0' },
  { name: 'jsDelivr', url: 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js' },
  { name: 'unpkg', url: 'https://unpkg.com/three@0.180.0/build/three.module.js' },
  { name: 'JSPM', url: 'https://ga.jspm.io/npm:three@0.180.0/build/three.module.js' },
  { name: 'GitHub mirror', url: 'https://raw.githack.com/mrdoob/three.js/r180/build/three.module.js' }
];
let THREE;
const threeLoadErrors = [];
try {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error('Tempo esgotado após 20 segundos.')), 20000);
  });
  const candidates = Promise.any(THREE_CDNS.map(async ({ name, url }) => {
    try {
      const library = await import(url);
      if (!library?.WebGLRenderer || !library?.Scene || !library?.PerspectiveCamera) {
        throw new Error('O provedor não retornou uma versão válida do Three.js.');
      }
      return library;
    } catch (error) {
      threeLoadErrors.push(`${name}: ${error?.message || String(error)}`);
      throw error;
    }
  }));
  try {
    THREE = await Promise.race([candidates, timeout]);
  } finally {
    clearTimeout(timeoutId);
  }
} catch (error) {
  const details = threeLoadErrors.slice(0, 6).join(' | ');
  const message = error?.message?.includes('20 segundos')
    ? 'Tempo esgotado ao carregar o motor 3D. Confira a conexão, bloqueadores de conteúdo e filtros de DNS.'
    : 'Não foi possível carregar o Three.js por nenhum dos provedores disponíveis. Confira a conexão e tente novamente.';
  const loadError = new Error(details ? `${message} Detalhes: ${details}` : message);
  loadError.name = 'ThreeJsLoadError';
  throw loadError;
}

// Retardados Royale — protótipo original jogável; Three.js vem de vários CDNs de fallback.
const $ = (id) => document.getElementById(id);
const rnd = (a,b) => a + Math.random() * (b-a);
const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
const dist2 = (a,b) => (a.x-b.x)**2 + (a.z-b.z)**2;
const COIN = '◈';
const DEFAULT_MOBILE_CONTROL_LAYOUT = {
  'touch-stick':   { x: 13, y: 78, size: 112, opacity: 68 },
  'touch-jump':    { x: 83, y: 71, size: 50, opacity: 92 },
  'touch-reload':  { x: 83, y: 84, size: 48, opacity: 88 },
  'touch-fire':    { x: 93, y: 80, size: 64, opacity: 96 },
  'touch-pickup':  { x: 83, y: 60, size: 48, opacity: 95 },
  'touch-verity':  { x: 83, y: 47, size: 58, opacity: 95 },
  'touch-vehicle': { x: 91, y: 61, size: 84, opacity: 96 }
};
const MOBILE_CONTROL_LABELS = {
  'touch-stick': 'JOYSTICK', 'touch-jump': 'PULAR', 'touch-reload': 'RECARREGAR',
  'touch-fire': 'ATIRAR', 'touch-pickup': 'E / PEGAR', 'touch-verity': 'VERITY', 'touch-vehicle': 'DIRIGIR'
};

const CHARACTERS = [
  {id:'enzo', name:'ENZO', desc:'Cachos curtos • camiseta preta', skin:'#9a5e3c', hair:'#24201f', shirt:'#17191f', pants:'#245cb5', shoes:'#e6e6df', style:'curly'},
  {id:'luan', name:'LUAN', desc:'Cabelo volumoso • baixinho', skin:'#f0d4c7', hair:'#111216', shirt:'#efeee8', pants:'#328448', shoes:'#202126', style:'messy'},
  {id:'eduardo', name:'EDUARDO', desc:'Franja escura • rosto redondo', skin:'#e9c5ae', hair:'#282526', shirt:'#17191f', pants:'#338044', shoes:'#e4e4dc', style:'fringe'},
  {id:'custom', name:'PERSONALIZÁVEL', desc:'Seu estilo, suas regras', skin:'#c78d6f', hair:'#6334a4', shirt:'#7b42b7', pants:'#34384b', shoes:'#f1d7a7', style:'custom'},
  {id:'vincent', name:'VINCENT', desc:'Loiro • cabelo longo e volumoso', skin:'#f1d7c6', hair:'#e7c56c', shirt:'#17191f', pants:'#315c9c', shoes:'#272a31', style:'long-blond', unlockCode:'VINCENT069'}
];
const WEAPONS = {
  melee:{id:'melee',name:'MARRETA DE ESPUMA',symbol:'▰',rarity:'common',damage:26,range:3.2,rate:.65,mag:0,reserve:0,reload:0,spread:0,auto:false,kind:'melee',desc:'Sem munição'},
  pistol:{id:'pistol',name:'PISTOLA',symbol:'▰',rarity:'common',damage:22,range:85,rate:.32,mag:16,reserve:64,reload:1.15,spread:.018,auto:false,kind:'hitscan',desc:'Equilibrada'},
  smg:{id:'smg',name:'SUBMETRALHADORA',symbol:'▰',rarity:'uncommon',damage:11,range:65,rate:.095,mag:28,reserve:112,reload:1.45,spread:.05,auto:true,kind:'hitscan',desc:'Cadência alta'},
  rifle:{id:'rifle',name:'RIFLE DE ASSALTO',symbol:'╾',rarity:'rare',damage:18,range:115,rate:.17,mag:24,reserve:96,reload:1.65,spread:.026,auto:true,kind:'hitscan',desc:'Versátil'},
  shotgun:{id:'shotgun',name:'ESCOPETA',symbol:'▰',rarity:'rare',damage:9,range:30,rate:.78,mag:6,reserve:30,reload:1.8,spread:.105,pellets:8,auto:false,kind:'hitscan',desc:'8 projéteis por disparo'},
  sniper:{id:'sniper',name:'RIFLE DE PRECISÃO',symbol:'⌁',rarity:'legendary',damage:72,range:190,rate:1.2,mag:5,reserve:20,reload:2.15,spread:.003,auto:false,kind:'hitscan',head:1.6,desc:'Dano alto a longa distância'},
  launcher:{id:'launcher',name:'LANÇADOR MALUCO',symbol:'✹',rarity:'legendary',damage:55,range:70,rate:1.3,mag:3,reserve:9,reload:2.25,spread:.025,auto:false,kind:'explosive',desc:'Explosão estilizada'}
};
const ARMOR_ITEMS = {
  helmet:{id:'helmet',slot:'helmet',name:'Capacete Blindado',desc:'Protege a cabeça e aumenta o escudo máximo.',shield:20,color:'#aebed0',rarity:'common',icon:'⛑'},
  helmet_reinforced:{id:'helmet_reinforced',slot:'helmet',name:'Capacete Reforçado',desc:'Capacete de liga reforçada.',shield:32,color:'#4da9e8',rarity:'rare',icon:'⛑'},
  chestplate:{id:'chestplate',slot:'chestplate',name:'Peitoral Blindado',desc:'Placa peitoral que amplia a capacidade de escudo.',shield:35,color:'#9ba7b6',rarity:'uncommon',icon:'⬟'},
  chestplate_heavy:{id:'chestplate_heavy',slot:'chestplate',name:'Peitoral Pesado',desc:'Blindagem pesada para o tronco.',shield:48,color:'#c58b4d',rarity:'rare',icon:'⬟'},
  boots:{id:'boots',slot:'boots',name:'Botas Táticas',desc:'Proteções rígidas para as pernas.',shield:15,color:'#707f91',rarity:'common',icon:'♟'},
  boots_reinforced:{id:'boots_reinforced',slot:'boots',name:'Botas Reforçadas',desc:'Grevas metálicas mais resistentes.',shield:25,color:'#6b8fe5',rarity:'rare',icon:'♟'},
  shoes:{id:'shoes',slot:'shoes',name:'Sapatos Blindados',desc:'Calçados reforçados com biqueira de proteção.',shield:10,color:'#7f8790',rarity:'common',icon:'▰'},
  shoes_reinforced:{id:'shoes_reinforced',slot:'shoes',name:'Sapatos de Liga',desc:'Calçados com placas metálicas reforçadas.',shield:18,color:'#d8b84e',rarity:'uncommon',icon:'▰'}
};
const ARMOR_SLOT_LABELS = {helmet:'Capacete',chestplate:'Peitoral',boots:'Botas / calçados',shoes:'Sapatos blindados'};
const ARMOR_SLOTS = Object.keys(ARMOR_SLOT_LABELS);
const ARMOR_POOL = Object.keys(ARMOR_ITEMS);
function randomArmorForSlot(slot){const choices=Object.values(ARMOR_ITEMS).filter(a=>a.slot===slot);return choices[Math.floor(Math.random()*choices.length)]?.id||null}

const PROFILE_AVATAR_CHOICES = ['🎮','⚔️','👾','🐸','💀','🌟','🚀','😎'];
function createLocalUserId(){
  const bytes=new Uint8Array(6);
  try{if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(bytes);else for(let i=0;i<bytes.length;i++)bytes[i]=Math.floor(Math.random()*256)}catch{for(let i=0;i<bytes.length;i++)bytes[i]=Math.floor(Math.random()*256)}
  return 'RR-'+Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('').toUpperCase();
}
const SHOP_ITEMS = [
  {id:'neon',name:'Aura Neon',desc:'Brilho cosmético verde para sua coleção.',price:150,icon:'✦'},
  {id:'crown',name:'Coroa de Papelão',desc:'Uma coroa de respeito duvidoso.',price:225,icon:'♛'},
  {id:'trail',name:'Trilha Pixelada',desc:'Trilha de cubos coloridos ao correr.',price:300,icon:'▦'},
  {id:'emote',name:'Dancinha Robótica',desc:'Emote desbloqueável para versões futuras.',price:400,icon:'♪'},
  {id:'free-sticker',name:'Adesivo GG',desc:'Item grátis para iniciar a coleção.',price:0,icon:'GG'}
];
let storeFilter = 'featured';
let selectedStoreItemId = 'neon';
let pendingStorePurchaseId = null;
const DEFAULT_PROFILE = {userId:'', avatar:'🎮', dailyMission:null, nickname:'JOGADOR', coins:250, character:'enzo', customAppearance:{hair:'#6334a4',shirt:'#7b42b7',pants:'#34384b'}, owned:['free-sticker'], equipped:[], unlockedCharacters:[], redeemedCodes:[], stats:{matches:0,wins:0,elims:0,damage:0,survival:0,coinsEarned:0}, level:1, xp:0, missions:{kills:0,wins:0,damage:0,weapon:0}, claimed:[], settings:{quality:'medium',volume:60,sensitivity:4,invert:false,tips:true,platform:'auto',cameraMode:'third'}};
let profile = loadProfile();
if(typeof profile.userId!=='string'||!/^RR-[A-F0-9]{12}$/.test(profile.userId))profile.userId=createLocalUserId();
if(typeof profile.avatar!=='string'||(!PROFILE_AVATAR_CHOICES.includes(profile.avatar)&&!/^data:image\/(jpeg|png|webp);base64,/.test(profile.avatar)))profile.avatar='🎮';
let dailyMissionDirty=false, dailyMissionClock=0;
profile.settings.mobileControls = Object.fromEntries(Object.entries(DEFAULT_MOBILE_CONTROL_LAYOUT).map(([id, defaults]) => [
  id, { ...defaults, ...(profile.settings.mobileControls?.[id] || {}) }
]));
// Personagens importados são metadados no estado da interface e arquivos binários no IndexedDB.
const importedCharacterMetadata = new Map();
const importedModelCache = new Map();
const importedLoadPromises = new Map();
let pendingCharacterImport = null;
let importPreviewRenderer = null, importPreviewScene = null, importPreviewCamera = null;
let importPreviewObject = null, importPreviewMixer = null, importPreviewAction = null, importPreviewMixerRoot = null;
let importPreviewYaw = 0, importPreviewPointer = null;

function importedCharacterData(meta) {
  if (!meta) return null;
  return {
    id: `imported:${meta.id}`, imported: true, importedRecordId: meta.id,
    name: String(meta.name || 'PERSONAGEM IMPORTADO').slice(0, 32),
    format: meta.format || 'GLB', rig: meta.rig || {}, createdAt: meta.createdAt || null,
    facingOffset: Number.isFinite(Number(meta.facingOffset)) ? Number(meta.facingOffset) : Math.PI,
    desc: meta.rig?.hasRig ? `Rig detectado • ${meta.rig.animationCount || 0} animações` : 'Modelo 3D • sem rig',
    skin: '#c78d6f', hair: '#34313d', shirt: '#485d80', pants: '#343d50', shoes: '#252a32', style: 'imported'
  };
}
function getCharacterById(id) {
  const original = CHARACTERS.find(c => c.id === id);
  if (original) return original;
  if (typeof id === 'string' && id.startsWith('imported:')) return importedCharacterData(importedCharacterMetadata.get(id.slice('imported:'.length)));
  return null;
}
function escapeImportText(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
async function refreshImportedCharacterMetadata() {
  try {
    const records = await listImportedCharacterMetadata();
    importedCharacterMetadata.clear();
    for (const record of records) importedCharacterMetadata.set(record.id, record);
    if (typeof updateCharacterSelectionSummary === 'function') updateCharacterSelectionSummary(getCharacterById(profile.character) || CHARACTERS.find(c => c.id === profile.character) || CHARACTERS[0]);
  } catch (error) {
    console.warn('Não foi possível ler personagens importados:', error);
    setImportStatus?.('O armazenamento de personagens não está disponível neste navegador.', 'error');
  }
}
async function ensureImportedCharacterLoaded(characterId) {
  const recordId = String(characterId || '').startsWith('imported:') ? String(characterId).slice('imported:'.length) : String(characterId || '');
  if (!recordId || !importedCharacterMetadata.has(recordId)) throw new Error('Esse personagem importado não está na biblioteca local.');
  if (importedModelCache.has(recordId)) return importedModelCache.get(recordId);
  if (importedLoadPromises.has(recordId)) return importedLoadPromises.get(recordId);
  const pending = parseStoredCharacter(recordId, THREE).then(asset => { importedModelCache.set(recordId, asset); return asset; }).finally(() => importedLoadPromises.delete(recordId));
  importedLoadPromises.set(recordId, pending);
  return pending;
}
function loadProfile(){try{return {...structuredClone(DEFAULT_PROFILE),...JSON.parse(localStorage.getItem('rr-profile')||'{}'),stats:{...DEFAULT_PROFILE.stats,...(JSON.parse(localStorage.getItem('rr-profile')||'{}').stats||{})},settings:{...DEFAULT_PROFILE.settings,...(JSON.parse(localStorage.getItem('rr-profile')||'{}').settings||{})},missions:{...DEFAULT_PROFILE.missions,...(JSON.parse(localStorage.getItem('rr-profile')||'{}').missions||{})}}}catch{return structuredClone(DEFAULT_PROFILE)}}
profile.equipped = Array.isArray(profile.equipped) ? profile.equipped : [];
profile.unlockedCharacters = Array.isArray(profile.unlockedCharacters) ? profile.unlockedCharacters : [];
profile.redeemedCodes = Array.isArray(profile.redeemedCodes) ? profile.redeemedCodes : [];
if(profile.character==='vincent' && !profile.unlockedCharacters.includes('vincent')) profile.character='enzo';
profile.settings.platform = ['auto','computer','mobile'].includes(profile.settings.platform) ? profile.settings.platform : 'auto';
profile.settings.cameraMode = ['third','first'].includes(profile.settings.cameraMode) ? profile.settings.cameraMode : 'third';
function saveProfile(){try{localStorage.setItem('rr-profile',JSON.stringify(profile))}catch{} updateProfileUI()}
function ensureDailyMission({persist=true}={}){
  const outcome=ensureDailyMissionRecord(profile.dailyMission,Date.now(),Math.random);
  if(outcome.changed){profile.dailyMission=outcome.mission;dailyMissionDirty=false;if(persist)saveProfile();}
  return profile.dailyMission;
}
function addDailyMissionProgress(type,amount=1){
  const mission=ensureDailyMission();
  if(incrementDailyMission(mission,type,amount))dailyMissionDirty=true;
}
function setAvatarElement(node,value){
  if(!node)return;
  node.replaceChildren();
  if(typeof value==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(value)){
    const img=document.createElement('img');img.src=value;img.alt='Foto do perfil';img.draggable=false;node.append(img);
  }else node.textContent=PROFILE_AVATAR_CHOICES.includes(value)?value:'🎮';
}
function formatDailyTime(ms){return formatDailyMissionTime(ms);}


const canvas = $('game-canvas');
const renderer = new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, profile.settings.quality==='high'?2:1.35));
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.shadowMap.enabled = profile.settings.quality !== 'low';
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#b8d3dc');
scene.fog = new THREE.Fog('#b8d3dc',100,360);
const camera = new THREE.PerspectiveCamera(62,window.innerWidth/window.innerHeight,.1,700);
// Camera-attached arm/weapon meshes are rendered only when the camera belongs to the scene graph.
scene.add(camera);
const hemi = new THREE.HemisphereLight('#e4f4ff','#55515a',2.1); scene.add(hemi);
const sun = new THREE.DirectionalLight('#fff0d8',2.5); sun.position.set(-65,100,40); sun.castShadow = renderer.shadowMap.enabled; sun.shadow.mapSize.set(profile.settings.quality==='high'?2048:1024,profile.settings.quality==='high'?2048:1024); sun.shadow.camera.left=-100;sun.shadow.camera.right=100;sun.shadow.camera.top=100;sun.shadow.camera.bottom=-100; scene.add(sun);

const world = new THREE.Group(); scene.add(world);
const floorMat = new THREE.MeshStandardMaterial({color:'#777d84',roughness:1,metalness:0});
const floor = new THREE.Mesh(new THREE.PlaneGeometry(520,520),floorMat); floor.rotation.x=-Math.PI/2; floor.position.y=-.06; floor.receiveShadow=true; world.add(floor);
const grid = new THREE.GridHelper(520,52,'#424950','#565d65'); grid.position.y=.015; grid.material.transparent=true;grid.material.opacity=.8;world.add(grid);
const boundaryMat = new THREE.MeshStandardMaterial({color:'#393e47',roughness:.9});
const blockers=[]; const shootables=[]; const environmentObjects=[]; const loot=[]; const bots=[]; let player=null;
let activeArenaSeed=null; let multiplayerActive=false; let multiplayerRoom=null; let multiplayerRoomCode=''; let onlineLobbyState=null; let roomUiUnsubs=[]; let onlineSendClock=0; let onlineJumpQueued=false; const remotePlayers=new Map(); let preview=null; let roundActive=false; let training=false; let selectedMode='bots'; let botCount=9; let selectedCharacter=profile.character; let entities=[]; let matchElapsed=0; let roundStart=0; let zoneRadius=205; let zoneInitial=205; let zoneFinal=22; let zoneStarts=24; let zoneDuration=180; let damageClock=0; let killCount=0; let damageDealt=0; let survivedSeconds=0; let matchEnded=false; let nextLootSpawn=0; let lastHud=0; let toastTimer=0; let fireHeld=false; let reloadUntil=0; let cameraYaw=0; let cameraVehicleLastYaw=null; let cameraPitch=.15; let jumpVelocity=0; let grounded=true; let dragging=false; let lastPointer={x:0,y:0}; let mouseDown=false; let keyDown={}; let currentPickup=null; let audioCtx=null; let lastShot=0; let touchFire=false; let touchMove={x:0,y:0}; let hudVisible=false; let botDifficulty='normal'; let trailClock=0; let cameraMode=profile.settings.cameraMode||'third'; let platformMode=profile.settings.platform||'auto'; let firstPersonRig=null; let firstPersonWeapon=null;
const clock = new THREE.Clock();
const raycaster = new THREE.Raycaster(); const tempVec = new THREE.Vector3();
// Reusable camera vectors and a separate raycaster keep camera collision checks inexpensive.
const cameraCollisionRaycaster = new THREE.Raycaster();
const cameraPivot = new THREE.Vector3();
const cameraOrbitPosition = new THREE.Vector3();
const cameraRayDirection = new THREE.Vector3();
const cameraResolvedPosition = new THREE.Vector3();
const cameraLookTarget = new THREE.Vector3();
const hitboxMaterial = new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0,depthWrite:false,colorWrite:false,side:THREE.DoubleSide});
let weaponPreviewRenderer=null, weaponPreviewScene=null, weaponPreviewCamera=null, weaponPreviewFailed=false;
const weaponPreviewCache=Object.create(null);
const projectileEffects=[];
const verityProjectiles=[]; const veritySparkEffects=[]; const verityBlastRings=[]; let nextVeritySpawn=0;
const vehicles=[]; let activeVehicle=null; let nextVehicleSpawn=0; let vehicleSerial=0;
const VEHICLE_SPAWN_INTERVAL=240; // slightly more frequent: one new vehicle about every four minutes
const VEHICLE_LIFETIME=360; // vehicles remain available for six minutes
const MAX_VEHICLES=3;
const zoneRing = new THREE.Mesh(new THREE.RingGeometry(.994,1,128),new THREE.MeshBasicMaterial({color:'#6edaff',side:THREE.DoubleSide,transparent:true,opacity:.9}));zoneRing.rotation.x=-Math.PI/2;zoneRing.position.y=.035;zoneRing.visible=false;world.add(zoneRing);

function mat(color,roughness=.85,metalness=0){return new THREE.MeshStandardMaterial({color,roughness,metalness})}
function weaponPart(group, geometry, color, pos, rotation=null, metalness=.12, roughness=.55){
  const mesh=new THREE.Mesh(geometry,mat(color,roughness,metalness));
  mesh.position.set(pos[0],pos[1],pos[2]);
  if(rotation)mesh.rotation.set(rotation[0]||0,rotation[1]||0,rotation[2]||0);
  mesh.castShadow=true;mesh.receiveShadow=true;group.add(mesh);return mesh;
}
// Original low-poly weapon meshes. The same factory is used for world-held weapons and the first-person viewmodel.
function makeWeaponModel(id='pistol'){
  const g=new THREE.Group();
  const dark='#252932',metal='#8c96a5',accent=({pistol:'#d9dee7',smg:'#64d8ae',rifle:'#75aaff',shotgun:'#c59b72',sniper:'#f2c66d',launcher:'#ff865c',melee:'#f4c45e'})[id]||'#d9dee7';
  const add=(geo,c,pos,rot=null,mt=.12,r=.55)=>weaponPart(g,geo,c,pos,rot,mt,r);
  if(id==='melee'){
    add(new THREE.BoxGeometry(.075,.075,.36),'#6b727d',[0,-.06,.04]);
    add(new THREE.BoxGeometry(.31,.17,.15),accent,[0,.075,-.13],null,.05,.7);
    add(new THREE.BoxGeometry(.23,.035,.16),'#fff0c4',[0,.075,-.13]);
    add(new THREE.BoxGeometry(.09,.09,.08),'#e7e9ee',[0,-.18,.08]);
  }else if(id==='pistol'){
    add(new THREE.BoxGeometry(.14,.11,.28),dark,[0,.005,-.04],null,.42,.38);
    add(new THREE.BoxGeometry(.12,.055,.22),accent,[0,.045,-.08],null,.4,.35);
    add(new THREE.BoxGeometry(.075,.17,.10),'#343944',[0,-.105,.055],[.12,0,-.08],.12,.8);
    add(new THREE.BoxGeometry(.045,.045,.18),metal,[0,.015,-.27],null,.7,.3);
    add(new THREE.BoxGeometry(.035,.025,.035),'#15171c',[0,.04,-.365],null,.35,.35);
  }else if(id==='smg'){
    add(new THREE.BoxGeometry(.16,.13,.32),dark,[0,.005,-.01],null,.35,.4);
    add(new THREE.BoxGeometry(.12,.07,.22),accent,[0,.035,-.07],null,.35,.35);
    add(new THREE.BoxGeometry(.055,.045,.25),metal,[0,.01,-.29],null,.65,.3);
    add(new THREE.BoxGeometry(.075,.18,.09),'#3b414d',[0,-.135,-.045],[.08,0,.02]);
    add(new THREE.BoxGeometry(.095,.09,.14),'#333944',[0,.005,.19]);
    add(new THREE.BoxGeometry(.06,.05,.08),metal,[0,.105,-.035],null,.5,.3);
  }else if(id==='shotgun'){
    add(new THREE.BoxGeometry(.15,.14,.31),'#493c32',[0,.005,.055],null,.2,.7);
    add(new THREE.BoxGeometry(.13,.09,.22),accent,[0,.035,-.1],null,.25,.55);
    add(new THREE.BoxGeometry(.045,.045,.36),metal,[-.035,.01,-.37],null,.7,.3);
    add(new THREE.BoxGeometry(.045,.045,.36),metal,[.035,.01,-.37],null,.7,.3);
    add(new THREE.BoxGeometry(.13,.06,.19),'#8c6949',[0,-.065,-.19]);
    add(new THREE.BoxGeometry(.09,.13,.13),'#3b3028',[0,-.105,.19],[.08,0,-.06]);
  }else if(id==='sniper'){
    add(new THREE.BoxGeometry(.14,.13,.42),dark,[0,.015,.02],null,.45,.4);
    add(new THREE.BoxGeometry(.105,.08,.35),accent,[0,.045,-.12],null,.4,.35);
    add(new THREE.BoxGeometry(.04,.04,.57),metal,[0,.015,-.48],null,.8,.28);
    add(new THREE.BoxGeometry(.13,.08,.22),'#303541',[0,.105,-.1]);
    add(new THREE.BoxGeometry(.075,.12,.11),'#1b2028',[0,.13,-.1],null,.6,.25);
    add(new THREE.BoxGeometry(.10,.18,.12),'#3b414d',[0,-.12,-.01],[.08,0,0]);
    add(new THREE.BoxGeometry(.06,.06,.18),'#434a58',[0,-.12,-.24],[.2,0,0]);
  }else if(id==='launcher'){
    add(new THREE.CylinderGeometry(.105,.105,.58,10),accent,[0,.025,-.16],[Math.PI/2,0,0],.3,.45);
    add(new THREE.CylinderGeometry(.13,.13,.09,10),metal,[0,.025,-.46],[Math.PI/2,0,0],.75,.3);
    add(new THREE.CylinderGeometry(.08,.08,.11,10),dark,[0,.025,.17],[Math.PI/2,0,0],.3,.5);
    add(new THREE.BoxGeometry(.14,.14,.16),'#353b46',[0,-.12,.03],[.1,0,-.05]);
    add(new THREE.BoxGeometry(.08,.18,.12),'#242832',[0,-.12,-.1]);
  }else{ // rifle / assault rifle
    add(new THREE.BoxGeometry(.15,.12,.36),dark,[0,.005,.015],null,.4,.42);
    add(new THREE.BoxGeometry(.12,.07,.28),accent,[0,.04,-.1],null,.4,.35);
    add(new THREE.BoxGeometry(.045,.045,.48),metal,[0,.015,-.39],null,.75,.28);
    add(new THREE.BoxGeometry(.075,.18,.10),'#3b414d',[0,-.13,-.08],[.08,0,.02]);
    add(new THREE.BoxGeometry(.09,.09,.21),'#343a45',[0,.005,.22]);
    add(new THREE.BoxGeometry(.055,.05,.11),metal,[0,.105,-.05],null,.55,.3);
    add(new THREE.BoxGeometry(.06,.045,.07),dark,[0,.12,-.14]);
  }
  return g;
}
function disposeWeaponModel(entity){
  if(entity?.weaponMount){entity.weaponMount.parent?.remove(entity.weaponMount);entity.weaponMount=null;}
  if(entity?.weaponModel){
    entity.weaponModel.parent?.remove(entity.weaponModel);
    entity.weaponModel.traverse(o=>{if(o.isMesh){o.geometry?.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material?.dispose()}});
    entity.weaponModel=null;
  }
}
function importedWeaponGripOffset(id){
  const offsets={melee:[0,.07,-.04],pistol:[0,.105,-.055],smg:[0,.135,.045],rifle:[0,.13,.08],shotgun:[0,.105,-.19],sniper:[0,.12,.01],launcher:[0,.12,-.03]};
  return offsets[id]||[0,.1,0];
}
function attachWeaponModel(entity){
  if(!entity?.group)return;
  disposeWeaponModel(entity);
  const active=getActiveWeapon(entity),id=active?.id||'pistol';
  entity.weaponModel=makeWeaponModel(id);
  if(entity.group.userData.importedCharacter){
    const controller=entity.group.userData.importedController;
    const hand=controller?.bones?.rightHand;
    if(hand){
      const mount=new THREE.Group();mount.name='RetardadosRoyaleWeaponMount';
      const offset=importedWeaponGripOffset(id);
      entity.weaponModel.position.set(offset[0],offset[1],offset[2]);
      entity.weaponModel.scale.setScalar(.95);
      mount.add(entity.weaponModel);hand.add(mount);entity.weaponMount=mount;
      if(controller){controller.weaponMount=mount;controller.weaponHand=hand;}
      updateImportedWeaponMount(entity);
    }else{
      // Rig sem osso de mão reconhecível: mantém a arma no ponto de empunhadura genérico.
      entity.weaponModel.position.set(.64,.86,.035);entity.weaponModel.rotation.set(0,-.12,.035);entity.weaponModel.scale.setScalar(1.18);entity.group.add(entity.weaponModel);
    }
  }else{
    // Personagens originais continuam usando exatamente o encaixe original.
    entity.weaponModel.position.set(.64,.86,.035);entity.weaponModel.rotation.set(0,-.12,.035);entity.weaponModel.scale.setScalar(1.18);entity.group.add(entity.weaponModel);
  }
  if(entity===player&&roundActive)refreshFirstPersonWeapon();
}

function rebuildFirstPersonRig(){
  if(firstPersonRig){camera.remove(firstPersonRig);firstPersonRig.traverse(o=>{if(o.isMesh){o.geometry?.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material?.dispose()}})}
  firstPersonRig=new THREE.Group();firstPersonWeapon=null;
  const chosenRaw=getCharacterById(profile.character)||CHARACTERS[0];
  const chosen=chosenRaw.id==='custom'?{...chosenRaw,...profile.customAppearance}:chosenRaw;
  const sleeve=mat(chosen.shirt),skin=mat(chosen.skin),dark=mat('#252932');
  const arm=new THREE.Mesh(new THREE.BoxGeometry(.17,.16,.39),sleeve);arm.position.set(-.10,-.13,.015);arm.rotation.x=-.25;firstPersonRig.add(arm);
  const hand=new THREE.Mesh(new THREE.BoxGeometry(.13,.10,.12),skin);hand.position.set(.015,-.055,-.11);firstPersonRig.add(hand);
  firstPersonRig.position.set(.28,-.24,-.45);firstPersonRig.rotation.set(-.055,.025,-.025);firstPersonRig.visible=false;
  camera.add(firstPersonRig);refreshFirstPersonWeapon();
}
function refreshFirstPersonWeapon(){
  if(!firstPersonRig)return;
  if(firstPersonWeapon){firstPersonRig.remove(firstPersonWeapon);firstPersonWeapon.traverse(o=>{if(o.isMesh){o.geometry?.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material?.dispose()}})}
  const id=player?getActiveWeapon(player)?.id||'pistol':'pistol';firstPersonWeapon=makeWeaponModel(id);
  firstPersonWeapon.position.set(.06,.015,-.16);firstPersonWeapon.rotation.set(-.025,.02,.025);firstPersonWeapon.scale.setScalar(1.38);firstPersonRig.add(firstPersonWeapon);
}
function makeVerityModel(){
  const g=new THREE.Group();
  const coreMat=new THREE.MeshStandardMaterial({color:'#4a4017',metalness:.72,roughness:.28,emissive:'#b99400',emissiveIntensity:.72});
  const goldMat=new THREE.MeshStandardMaterial({color:'#ffe04b',metalness:.55,roughness:.22,emissive:'#ffd51a',emissiveIntensity:.95});
  const darkMat=new THREE.MeshStandardMaterial({color:'#292b2d',metalness:.6,roughness:.35});
  const core=new THREE.Mesh(new THREE.IcosahedronGeometry(.29,1),coreMat);core.rotation.set(.25,.35,.15);g.add(core);
  const ring1=new THREE.Mesh(new THREE.TorusGeometry(.34,.045,8,22),goldMat);ring1.rotation.x=.58;ring1.rotation.y=.35;g.add(ring1);
  const ring2=new THREE.Mesh(new THREE.TorusGeometry(.32,.032,8,22),darkMat);ring2.rotation.y=.92;ring2.rotation.z=.4;g.add(ring2);
  const cap=new THREE.Mesh(new THREE.CylinderGeometry(.095,.12,.12,8),goldMat);cap.position.y=.3;g.add(cap);
  for(let i=0;i<6;i++){const a=i*Math.PI/3;const spike=new THREE.Mesh(new THREE.ConeGeometry(.055,.18,5),goldMat);spike.position.set(Math.cos(a)*.28,Math.sin(a)*.22,.02);spike.rotation.z=-a;g.add(spike)}
  g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});
  return g;
}

function addPart(group,geometry,material,pos,part='body',scale=null){const mesh=new THREE.Mesh(geometry,material);mesh.position.set(...pos);if(scale)mesh.scale.set(...scale);mesh.castShadow=renderer.shadowMap.enabled;mesh.receiveShadow=true;mesh.userData.part=part;group.add(mesh);return mesh}
function normalizedBoneName(name){return String(name||'').toLowerCase().replace(/[^a-z0-9]/g,'')}
function findImportedHumanoidBones(root){
  const bones=[];root?.traverse?.(object=>{if(object.isBone)bones.push(object)});
  const sideMatch=(name,side)=>{
    const n=normalizedBoneName(name);
    return n.includes(side==='left'?'left':'right') || n.startsWith(side==='left'?'l':'r');
  };
  const find=(side,kind)=>bones.find(b=>{
    const n=normalizedBoneName(b.name);if(!sideMatch(n,side))return false;
    if(kind==='upperArm')return /(upperarm|arm)$/.test(n)&&!/(forearm|lowerarm|hand|finger|clavicle|shoulder)/.test(n);
    if(kind==='forearm')return /(forearm|lowerarm|armforearm)$/.test(n)&&!/(hand|finger)/.test(n);
    if(kind==='hand')return /hand$/.test(n)&&!/(finger|thumb|toe)/.test(n);
    if(kind==='upperLeg')return /(upleg|upperleg|thigh|leg)$/.test(n)&&!/(lower|calf|shin|foot|toe)/.test(n);
    if(kind==='lowerLeg')return /(leg|calf|shin)$/.test(n)&&!/(upleg|upperleg|thigh|foot)/.test(n);
    return false;
  });
  const head=bones.find(b=>/(^|)(head|skull)$/.test(normalizedBoneName(b.name)));
  const spine=bones.find(b=>/(spine|chest|upperbody|torso)/.test(normalizedBoneName(b.name)));
  const leftArm=find('left','upperArm'),rightArm=find('right','upperArm');
  const leftForearm=find('left','forearm'),rightForearm=find('right','forearm');
  const leftHand=find('left','hand'),rightHand=find('right','hand');
  return {
    leftLeg:find('left','upperLeg'),rightLeg:find('right','upperLeg'),
    leftLowerLeg:find('left','lowerLeg'),rightLowerLeg:find('right','lowerLeg'),
    leftArm,rightArm,leftForearm,rightForearm,leftHand,rightHand,spine,head
  };
}

function createImportedAnimationController(modelRoot, clips=[]){
  const controller={mixer:null,actions:{},activeAction:null,activeRole:'',bones:findImportedHumanoidBones(modelRoot),baseRotations:new Map(),phase:0,landTimer:0,wasAir:false,hasCompatibleClip:false,weaponMount:null,weaponHand:null,_qA:new THREE.Quaternion(),_qB:new THREE.Quaternion(),_qC:new THREE.Quaternion(),_vA:new THREE.Vector3(),_vB:new THREE.Vector3(),_vC:new THREE.Vector3(),_vD:new THREE.Vector3(),_pA:new THREE.Vector3(),_pB:new THREE.Vector3(),_pC:new THREE.Vector3(),_pD:new THREE.Vector3()};
  if(Array.isArray(clips)&&clips.length){
    try{
      controller.mixer=new THREE.AnimationMixer(modelRoot);
      for(const sourceClip of clips){
        if(!sourceClip)continue;
        const role=classifyAnimationName(sourceClip.name||'');
        if(!role||controller.actions[role])continue;
        const clip=sourceClip.clone();
        // Keep the game physics in charge of movement: flatten horizontal root motion in clips.
        for(const track of clip.tracks||[]){
          if(!/\.position$/i.test(track.name||''))continue;
          const targetName=String(track.name||'').split('.')[0].split(/[|/:]/).pop().toLowerCase().replace(/[^a-z0-9]/g,'');
          const rootLike=/^(root|armature|hips|pelvis|mixamorighips|mixamorigroot|mixamorigpelvis)$/.test(targetName);
          if(!rootLike)continue;
          if(track.values?.length>=3&&track.values.length%3===0){
            const x=track.values[0],z=track.values[2];
            for(let i=0;i<track.values.length;i+=3){track.values[i]=x;track.values[i+2]=z;}
          }
        }
        const action=controller.mixer.clipAction(clip);
        action.enabled=true;action.setEffectiveWeight(1);
        if(role==='land'){action.setLoop(THREE.LoopOnce,1);action.clampWhenFinished=true;}
        else if(role==='jump'){action.setLoop(THREE.LoopOnce,1);action.clampWhenFinished=true;}
        else action.setLoop(THREE.LoopRepeat,Infinity);
        controller.actions[role]=action;
      }
      controller.hasCompatibleClip=Object.keys(controller.actions).length>0;
    }catch(error){console.warn('Animações do personagem importado não puderam ser preparadas:',error);controller.mixer=null;controller.actions={};}
  }
  const legBones=[controller.bones.leftLeg,controller.bones.rightLeg,controller.bones.leftLowerLeg,controller.bones.rightLowerLeg].filter(Boolean);
  const trackTargetsBone=(track,bone)=>{
    const target=normalizedBoneName(String(track?.name||'').split('.')[0].split(/[|/:]/).pop());
    const boneName=normalizedBoneName(bone?.name);
    return !!target&&!!boneName&&(target===boneName||target.endsWith(boneName)||boneName.endsWith(target));
  };
  controller.hasLegAnimationTrack=['walk','run'].some(role=>{
    const clip=controller.actions[role]?.getClip();
    return !!clip&&legBones.some(bone=>(clip.tracks||[]).some(track=>trackTargetsBone(track,bone)));
  });
  for(const bone of Object.values(controller.bones)){if(bone&&!controller.baseRotations.has(bone))controller.baseRotations.set(bone,bone.rotation.clone());}
  return controller;
}
function createNormalizedImportedModel(asset,facingOffset=Math.PI){
  const modelRoot=cloneImportedScene(asset);
  modelRoot.updateMatrixWorld?.(true);
  const bounds=new THREE.Box3().setFromObject(modelRoot);
  if(!Number.isFinite(bounds.min.x)||!Number.isFinite(bounds.min.y)||!Number.isFinite(bounds.min.z)||!Number.isFinite(bounds.max.x)||!Number.isFinite(bounds.max.y)||!Number.isFinite(bounds.max.z)){
    throw new Error('Não foi possível calcular os limites espaciais deste modelo. Confira a geometria antes de importar.');
  }
  const size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());
  const targetHeight=2.55;
  const scale=(Number.isFinite(size.y)&&size.y>.001)?clamp(targetHeight/size.y,.002,100):1;
  modelRoot.scale.multiplyScalar(scale);
  modelRoot.position.x-=center.x*scale;
  modelRoot.position.y-=bounds.min.y*scale;
  modelRoot.position.z-=center.z*scale;
  const container=new THREE.Group();container.rotation.y=Number.isFinite(Number(facingOffset))?Number(facingOffset):Math.PI;container.add(modelRoot);
  return {container,modelRoot,scale,originalBounds:{x:size.x,y:size.y,z:size.z}};
}
function makeImportedCharacter(data, entity=null){
  const recordId=data.importedRecordId||String(data.id||'').replace(/^imported:/,'');
  const asset=importedModelCache.get(recordId);
  if(!asset)throw new Error(`O modelo ${data.name||'importado'} ainda não foi carregado. Abra a seleção de personagens e selecione-o novamente.`);
  const group=new THREE.Group();group.userData.entity=entity;group.userData.importedCharacter=true;group.userData.importedRecordId=recordId;
  const currentMeta=importedCharacterMetadata.get(recordId);
  const facingOffset=Number.isFinite(Number(data.facingOffset))?Number(data.facingOffset):Number.isFinite(Number(currentMeta?.facingOffset))?Number(currentMeta.facingOffset):Math.PI;
  const visual=createNormalizedImportedModel(asset,facingOffset);group.add(visual.container);
  const controller=createImportedAnimationController(visual.modelRoot,asset.animations||[]);
  group.userData.importedController=controller;group.userData.importedModelRoot=visual.modelRoot;
  if(entity)entity.importedAnimationController=controller;
  group.traverse(o=>{if(o.isMesh||o.isSkinnedMesh){o.userData.entity=entity;o.userData.part=o.userData.part||'body';o.castShadow=renderer.shadowMap.enabled;o.receiveShadow=true;if(entity&&!entity.isRemote)shootables.push(o)}});
  if(entity&&!entity.isRemote){
    const legsHit=new THREE.Mesh(new THREE.BoxGeometry(.78,.86,.62),hitboxMaterial);legsHit.position.set(0,.43,0);legsHit.userData={entity,part:'leg',hitbox:true};group.add(legsHit);shootables.push(legsHit);
    const bodyHit=new THREE.Mesh(new THREE.BoxGeometry(.96,.91,.76),hitboxMaterial);bodyHit.position.set(0,1.075,0);bodyHit.userData={entity,part:'body',hitbox:true};group.add(bodyHit);shootables.push(bodyHit);
    const headHit=new THREE.Mesh(new THREE.SphereGeometry(.405,10,8),hitboxMaterial);headHit.position.set(0,1.925,0);headHit.userData={entity,part:'head',hitbox:true};group.add(headHit);shootables.push(headHit);
    entity.hitboxes=[legsHit,bodyHit,headHit];
  }
  return group;
}
function makeCharacter(data, entity=null){
  if(data?.imported)return makeImportedCharacter(data,entity);
  if(data.id==='custom'&&profile.customAppearance)data={...data,...profile.customAppearance};
  const group=new THREE.Group(); group.userData.entity=entity;
  const showUserCosmetics = !entity || (!entity.isBot && !entity.isRemote);
  const skin=mat(data.skin), hair=mat(data.hair), shirt=mat(data.shirt), pants=mat(data.pants), shoes=mat(data.shoes), dark=mat('#17191e'), eye=mat('#f7f7f1'), pupil=mat('#151515'), mouth=mat('#6c3430');
  // Legs, sneakers and torso: readable stylized silhouettes, same collision dimensions for every avatar.
  // Pivoted legs: the mesh geometry moves around the hip instead of sliding across the floor.
  const legLeft=new THREE.Group(),legRight=new THREE.Group();legLeft.position.set(-.19,.8,0);legRight.position.set(.19,.8,0);group.add(legLeft,legRight);
  addPart(legLeft,new THREE.BoxGeometry(.31,.76,.34),pants,[0,-.38,0],'leg');
  addPart(legLeft,new THREE.BoxGeometry(.34,.18,.5),shoes,[0,-.72,-.055],'shoe');
  addPart(legRight,new THREE.BoxGeometry(.31,.76,.34),pants,[0,-.38,0],'leg');
  addPart(legRight,new THREE.BoxGeometry(.34,.18,.5),shoes,[0,-.72,-.055],'shoe');
  group.userData.legs=[legLeft,legRight];
  addPart(group,new THREE.BoxGeometry(.76,.77,.39),shirt,[0,1.14,0],'body');
  addPart(group,new THREE.BoxGeometry(.22,.72,.23),shirt,[-.51,1.16,0],'arm');addPart(group,new THREE.BoxGeometry(.22,.72,.23),shirt,[.51,1.16,0],'arm');
  addPart(group,new THREE.SphereGeometry(.13,12,9),skin,[-.51,.79,-.01],'hand');addPart(group,new THREE.SphereGeometry(.13,12,9),skin,[.58,.79,.035],'hand');
  addPart(group,new THREE.CylinderGeometry(.13,.14,.16,12),skin,[0,1.57,0],'neck');
  addPart(group,new THREE.SphereGeometry(.39,20,16),skin,[0,1.91,0],'head',[.92,1.05,.87]);
  if(data.style==='long-blond'){
    // Long tousled blond locks and volume around the crown and shoulders.
    addPart(group,new THREE.SphereGeometry(.39,15,11),hair,[0,2.19,.015],'hair',[1.12,.66,1.02]);
    addPart(group,new THREE.SphereGeometry(.28,12,9),hair,[-.16,2.30,-.015],'hair',[1.0,.62,.92]);
    addPart(group,new THREE.SphereGeometry(.27,12,9),hair,[.15,2.31,.02],'hair',[1.0,.60,.94]);
    const lockGeo=new THREE.CapsuleGeometry(.105,.48,4,8);
    const leftLock=addPart(group,lockGeo,hair,[-.31,1.91,.015],'hair',[1,1.15,1]);leftLock.rotation.z=-.09;
    const rightLock=addPart(group,lockGeo,hair,[.31,1.90,.02],'hair',[1,1.17,1]);rightLock.rotation.z=.1;
    addPart(group,new THREE.SphereGeometry(.25,12,9),hair,[0,1.94,.22],'hair',[1.2,1.1,.72]);
    const fringe1=addPart(group,new THREE.ConeGeometry(.13,.36,7),hair,[-.13,2.13,-.30],'hair');fringe1.rotation.z=-.22;fringe1.rotation.x=-.14;
    const fringe2=addPart(group,new THREE.ConeGeometry(.13,.40,7),hair,[.08,2.12,-.31],'hair');fringe2.rotation.z=.12;fringe2.rotation.x=-.1;
    const fringe3=addPart(group,new THREE.ConeGeometry(.105,.29,7),hair,[.25,2.17,-.24],'hair');fringe3.rotation.z=.38;fringe3.rotation.x=-.08;
  }else if(data.style==='curly'){
    addPart(group,new THREE.SphereGeometry(.35,14,10),hair,[0,2.17,0],'hair',[1.08,.48,.97]);
    for(let i=0;i<9;i++){const angle=i/9*Math.PI*2;addPart(group,new THREE.SphereGeometry(.105,9,7),hair,[Math.cos(angle)*.26,2.29+Math.sin(i*2)*.035,Math.sin(angle)*.22],'hair')}
  }else if(data.style==='messy'){
    addPart(group,new THREE.SphereGeometry(.42,14,10),hair,[0,2.22,.005],'hair',[1.14,.7,1.02]);
    for(let i=0;i<7;i++){const x=rnd(-.29,.29),z=rnd(-.2,.2);const sp=addPart(group,new THREE.ConeGeometry(.115,.29,7),hair,[x,2.48+Math.random()*.06,z],'hair');sp.rotation.z=rnd(-.65,.65);sp.rotation.x=rnd(-.3,.3)}
  }else if(data.style==='fringe'){
    addPart(group,new THREE.SphereGeometry(.37,15,10),hair,[0,2.18,0],'hair',[1.06,.55,.98]);
    addPart(group,new THREE.BoxGeometry(.57,.18,.16),hair,[0,2.08,-.31],'hair').rotation.z=.04;
    addPart(group,new THREE.SphereGeometry(.13,9,7),hair,[-.2,2.13,-.27],'hair',[1.3,.7,.8]);
  }else{
    addPart(group,new THREE.SphereGeometry(.38,14,10),hair,[0,2.19,0],'hair',[1.05,.58,1]);
    const stripe=mat('#e9c2ff');addPart(group,new THREE.BoxGeometry(.15,.46,.12),stripe,[.2,2.01,-.3],'hair').rotation.z=-.22;
  }
  // Eyes point toward -Z, the character's forward direction.
  addPart(group,new THREE.SphereGeometry(.057,9,7),eye,[-.145,1.94,-.326],'face');addPart(group,new THREE.SphereGeometry(.057,9,7),eye,[.145,1.94,-.326],'face');
  addPart(group,new THREE.SphereGeometry(.027,8,6),pupil,[-.145,1.94,-.373],'face');addPart(group,new THREE.SphereGeometry(.027,8,6),pupil,[.145,1.94,-.373],'face');
  addPart(group,new THREE.BoxGeometry(.19,.035,.025),mouth,[0,1.75,-.329],'face');
  if(data.id==='custom'){
    const hatmat=mat('#e7b84f');addPart(group,new THREE.CylinderGeometry(.23,.29,.12,12),hatmat,[0,2.48,0],'accessory');
    addPart(group,new THREE.BoxGeometry(.49,.065,.26),hatmat,[0,2.43,-.05],'accessory');
  }
  if(showUserCosmetics && profile.equipped?.includes('crown')){
    const crownMat=mat('#d2a34b',.55,.1);addPart(group,new THREE.TorusGeometry(.28,.055,6,16),crownMat,[0,2.44,0],'accessory');
    for(let i=0;i<5;i++){const a=i/5*Math.PI*2;const spike=addPart(group,new THREE.ConeGeometry(.075,.2,5),crownMat,[Math.cos(a)*.24,2.58,Math.sin(a)*.24],'accessory');spike.rotation.z=Math.cos(a)*.18;spike.rotation.x=Math.sin(a)*.18}
  }
  if(showUserCosmetics && profile.equipped?.includes('neon')){
    const aura=new THREE.Mesh(new THREE.TorusGeometry(.66,.035,6,24),new THREE.MeshBasicMaterial({color:'#42ffc7',transparent:true,opacity:.86}));aura.rotation.x=Math.PI/2;aura.position.y=1.08;aura.userData.part='accessory';group.add(aura);
    const belt=new THREE.Mesh(new THREE.TorusGeometry(.47,.025,6,24),new THREE.MeshBasicMaterial({color:'#42ffc7',transparent:true,opacity:.75}));belt.rotation.x=Math.PI/2;belt.position.y=.72;belt.userData.part='accessory';group.add(belt);
  }
  group.traverse(o=>{if(o.isMesh){o.userData.entity=entity;o.userData.part=o.userData.part||'body';if(!entity?.isRemote)shootables.push(o)}});
  if(entity&&!entity.isRemote){
    // Separate, invisible combat hitboxes keep impacts consistent across all character skins.
    const legsHit=new THREE.Mesh(new THREE.BoxGeometry(.78,.86,.62),hitboxMaterial);legsHit.position.set(0,.43,0);legsHit.userData={entity,part:'leg',hitbox:true};group.add(legsHit);shootables.push(legsHit);
    const bodyHit=new THREE.Mesh(new THREE.BoxGeometry(.96,.91,.76),hitboxMaterial);bodyHit.position.set(0,1.075,0);bodyHit.userData={entity,part:'body',hitbox:true};group.add(bodyHit);shootables.push(bodyHit);
    const headHit=new THREE.Mesh(new THREE.SphereGeometry(.405,10,8),hitboxMaterial);headHit.position.set(0,1.925,0);headHit.userData={entity,part:'head',hitbox:true};group.add(headHit);shootables.push(headHit);
    entity.hitboxes=[legsHit,bodyHit,headHit];
  }
  return group;
}
function refreshArmorVisuals(e){
  if(!e?.group)return;
  for(const mesh of e.armorVisuals||[]){mesh.parent?.remove(mesh);mesh.geometry?.dispose();if(Array.isArray(mesh.material))mesh.material.forEach(m=>m.dispose());else mesh.material?.dispose()}
  e.armorVisuals=[];
  const add=(parent,geometry,color,pos,scale=null)=>{
    const mesh=new THREE.Mesh(geometry,mat(color,.38,.58));mesh.position.set(pos[0],pos[1],pos[2]);if(scale)mesh.scale.set(scale[0],scale[1],scale[2]);mesh.castShadow=renderer.shadowMap.enabled;mesh.receiveShadow=true;mesh.userData={armorVisual:true};parent.add(mesh);e.armorVisuals.push(mesh);return mesh;
  };
  const equipped=e.armor||{};
  const helmet=ARMOR_ITEMS[equipped.helmet];
  if(helmet){
    add(e.group,new THREE.SphereGeometry(.42,16,10,0,Math.PI*2,0,Math.PI*.57),helmet.color,[0,2.08,0],[1.04,.92,1.04]);
    add(e.group,new THREE.BoxGeometry(.48,.105,.14),'#222b35',[0,2.00,-.335]);
    add(e.group,new THREE.BoxGeometry(.3,.045,.06),'#d6eaff',[0,2.005,-.414]);
  }
  const chest=ARMOR_ITEMS[equipped.chestplate];
  if(chest){
    add(e.group,new THREE.BoxGeometry(.72,.56,.135),chest.color,[0,1.17,-.245]);
    add(e.group,new THREE.SphereGeometry(.17,10,8),chest.color,[-.39,1.43,-.04],[1,.78,.9]);
    add(e.group,new THREE.SphereGeometry(.17,10,8),chest.color,[.39,1.43,-.04],[1,.78,.9]);
    add(e.group,new THREE.BoxGeometry(.13,.46,.025),'#303842',[0,1.16,-.319]);
  }
  const boots=ARMOR_ITEMS[equipped.boots];
  if(boots){
    for(const leg of (e.group.userData.legs||[])){
      add(leg,new THREE.BoxGeometry(.27,.46,.07),boots.color,[0,-.38,-.195]);
      add(leg,new THREE.BoxGeometry(.3,.095,.075),'#2c333d',[0,-.16,-.201]);
    }
  }
  const shoes=ARMOR_ITEMS[equipped.shoes];
  if(shoes){
    for(const leg of (e.group.userData.legs||[])){
      add(leg,new THREE.BoxGeometry(.31,.16,.37),shoes.color,[0,-.705,-.08]);
      add(leg,new THREE.BoxGeometry(.24,.055,.075),'#252c34',[0,-.69,-.267]);
    }
  }
}
function equipArmor(e,itemId,{dropOld=false,refresh=true}={}){
  const def=ARMOR_ITEMS[itemId];if(!e||!def)return false;
  e.armor=e.armor||{helmet:null,chestplate:null,boots:null,shoes:null};
  const previousId=e.armor[def.slot],previous=ARMOR_ITEMS[previousId];
  if(previousId===itemId||(previous&&previous.shield>=def.shield))return false;
  e.armor[def.slot]=itemId;
  e.maxShield=100+ARMOR_SLOTS.reduce((sum,slot)=>sum+(ARMOR_ITEMS[e.armor[slot]]?.shield||0),0);
  e.shield=clamp((e.shield||0)+def.shield-(previous?.shield||0),0,e.maxShield);
  if(dropOld&&previousId)spawnLoot('armor',previousId,e.pos.x+rnd(-1.2,1.2),e.pos.z+rnd(-1.2,1.2));
  if(refresh)refreshArmorVisuals(e);
  if(e===player)updateHud(true);
  return true;
}
function giveRandomArmor(e){
  if(Math.random()>.39)return;
  const shuffled=[...ARMOR_SLOTS].sort(()=>Math.random()-.5);
  const count=Math.random()<.18?3:Math.random()<.58?2:1;
  for(const slot of shuffled.slice(0,count)){
    const id=randomArmorForSlot(slot);if(id)equipArmor(e,id,{dropOld:false,refresh:false});
  }
  refreshArmorVisuals(e);
}
function buildEnvironment(seed=null){
  const chosenSeed = Number.isFinite(Number(seed)) && seed !== null ? ((Number(seed) >>> 0) || 1) : ((Math.floor(Math.random()*0xffffffff)>>>0)||1);
  const layout=generateArenaLayout(chosenSeed);activeArenaSeed=layout.seed;
  const track=(object,{blocker=false,shootable=false}={})=>{world.add(object);environmentObjects.push(object);if(blocker)blockers.push(object);if(shootable)shootables.push(object);return object};
  const wallGeo=new THREE.BoxGeometry(520,7,3);
  for(const w of layout.walls){const m=new THREE.Mesh(wallGeo,boundaryMat);m.position.set(w.x,3.4,w.z);m.rotation.y=w.ry;m.castShadow=true;m.receiveShadow=true;track(m,{blocker:true,shootable:true})}
  for(const o of layout.obstacles){
    const geo=o.shape==='cylinder'?new THREE.CylinderGeometry(o.sx*.58,o.sx*.7,o.sy,6):new THREE.BoxGeometry(o.sx,o.sy,o.sz);
    const mesh=new THREE.Mesh(geo,mat(o.color));mesh.position.set(o.x,o.sy/2,o.z);mesh.rotation.y=o.rotationY;mesh.castShadow=renderer.shadowMap.enabled;mesh.receiveShadow=true;mesh.userData.blocker=true;mesh.userData.arenaObstacle=o.id;track(mesh,{blocker:true,shootable:true});
  }
  // Original absurd low-poly set pieces; they remain visual landmarks and are not colliders.
  for(const prop of layout.setPieces){
    const base=new THREE.Mesh(new THREE.CylinderGeometry(2.1,2.1,.35,12),mat('#444955'));base.position.set(prop.x,.18,prop.z);track(base);
    const orb=new THREE.Mesh(new THREE.SphereGeometry(1.25,14,12),mat(prop.color,.35,.1));orb.position.set(prop.x,1.6,prop.z);orb.castShadow=true;track(orb);
    const bar=new THREE.Mesh(new THREE.BoxGeometry(3.2,.16,.16),mat('#2b3039'));bar.position.set(prop.x,2.4,prop.z);bar.rotation.z=.35;track(bar);
  }
}
function rebuildArenaForSeed(seed){
  const chosenSeed=(Number(seed)>>>0)||1;if(activeArenaSeed===chosenSeed)return;
  const old=new Set(environmentObjects);
  for(const object of environmentObjects){world.remove(object);object.geometry?.dispose();if(object.material&&object.material!==boundaryMat){if(Array.isArray(object.material))object.material.forEach(m=>m.dispose());else object.material.dispose()}}
  environmentObjects.length=0;blockers.length=0;
  shootables.splice(0,shootables.length,...shootables.filter(object=>!old.has(object)));
  buildEnvironment(chosenSeed);
}
function clearRemotePlayers(){
  for(const remote of remotePlayers.values()){
    if(remote.group){world.remove(remote.group);remote.group.traverse(o=>{if(o.isMesh){const at=shootables.indexOf(o);if(at>=0)shootables.splice(at,1)}})}
  }
  remotePlayers.clear();
  const list=$('online-player-list');if(list)list.replaceChildren();
}

buildEnvironment();

function addEntity(data,opts={}){
  const e={id:Math.random().toString(36).slice(2),data,group:null,pos:new THREE.Vector3(opts.x||0,0,opts.z||0),vel:new THREE.Vector3(),yaw:0,hp:100,shield:opts.shield??100,maxHp:100,maxShield:100,armor:{helmet:null,chestplate:null,boots:null,shoes:null},armorVisuals:[],alive:true,isBot:!!opts.isBot,name:opts.name||data.name,weaponSlots:[],activeSlot:0,fireAt:0,reloadAt:0,scoreKills:0,damage:0,aiThink:0,strafe:Math.random()<.5?-1:1,aiMode:'seek',grounded:true,ammoDrop:null,wasOutside:false,walkPhase:0,stepTimer:0,movingSpeed:0,hitboxes:[],verityCount:0};
  e.group=makeCharacter(data,e);e.group.position.copy(e.pos);world.add(e.group);
  e.weaponSlots=opts.isBot?[newWeapon('pistol')]:[newWeapon('pistol'),newWeapon('melee')]; e.activeSlot=0;
  if(opts.isBot){
    if(Math.random()<.36){e.weaponSlots=[newWeapon(Math.random()<.65?'smg':'rifle')];}
    if(Math.random()<.12)e.weaponSlots=[newWeapon('shotgun')];
    e.shield=Math.random()<.5?0:50;
    giveRandomArmor(e);
  }
  refreshArmorVisuals(e);
  attachWeaponModel(e);
  entities.push(e);if(e.isBot)bots.push(e);if(!e.isBot)player=e;
  return e;
}
function newWeapon(id){const w=WEAPONS[id]||WEAPONS.pistol;return {id,ammo:w.mag,reserve:w.reserve}}
function weaponDef(e){return WEAPONS[e.weaponSlots[e.activeSlot]?.id||'pistol']||WEAPONS.pistol}
function getActiveWeapon(e){return e.weaponSlots[e.activeSlot]||e.weaponSlots[0]}
function removeEntity(e){if(e.group){world.remove(e.group);for(let i=shootables.length-1;i>=0;i--)if(shootables[i].userData.entity===e)shootables.splice(i,1)} }
function randomSpot(min=30,max=225){const a=rnd(0,Math.PI*2),r=rnd(min,max);return {x:Math.sin(a)*r,z:Math.cos(a)*r}}
function makeVehicleModel(paint){
  const root=new THREE.Group(), wheels=[];
  const bodyMat=mat(paint,.42,.12), darkMat=mat('#20242b',.82,.04), glassMat=new THREE.MeshStandardMaterial({color:'#7fc4d8',roughness:.2,metalness:.1,transparent:true,opacity:.72}), chromeMat=mat('#aeb8c5',.3,.7), headMat=new THREE.MeshStandardMaterial({color:'#fff2b0',emissive:'#ffca52',emissiveIntensity:.5}), tailMat=new THREE.MeshStandardMaterial({color:'#ff4c55',emissive:'#a20d1b',emissiveIntensity:.45});
  const part=(geo,material,pos,rot=null)=>{const m=new THREE.Mesh(geo,material);m.position.set(pos[0],pos[1],pos[2]);if(rot)m.rotation.set(rot[0]||0,rot[1]||0,rot[2]||0);m.castShadow=true;m.receiveShadow=true;root.add(m);return m};
  // Original low-poly open-top car, facing local -Z so steering aligns with the game's yaw convention.
  part(new THREE.BoxGeometry(2.12,.48,4.15),bodyMat,[0,.58,0]);
  part(new THREE.BoxGeometry(1.88,.34,1.05),bodyMat,[0,.91,-1.34]);
  part(new THREE.BoxGeometry(1.82,.3,.86),bodyMat,[0,.84,1.47]);
  part(new THREE.BoxGeometry(1.57,.15,1.48),darkMat,[0,.92,.12]);
  part(new THREE.BoxGeometry(.055,.46,1.28),glassMat,[-.77,1.19,.1]);part(new THREE.BoxGeometry(.055,.46,1.28),glassMat,[.77,1.19,.1]);
  // Windshield and rear glass are tilted transparent plates.
  part(new THREE.BoxGeometry(1.48,.48,.06),glassMat,[0,1.22,-.74],[.28,0,0]);
  part(new THREE.BoxGeometry(1.43,.42,.06),glassMat,[0,1.2,.89],[-.28,0,0]);
  part(new THREE.BoxGeometry(2.02,.13,.14),darkMat,[0,.34,-2.06]);part(new THREE.BoxGeometry(2.02,.13,.14),darkMat,[0,.34,2.06]);
  part(new THREE.BoxGeometry(.42,.16,.08),headMat,[-.68,.7,-2.105]);part(new THREE.BoxGeometry(.42,.16,.08),headMat,[.68,.7,-2.105]);
  part(new THREE.BoxGeometry(.35,.17,.08),tailMat,[-.69,.69,2.105]);part(new THREE.BoxGeometry(.35,.17,.08),tailMat,[.69,.69,2.105]);
  part(new THREE.BoxGeometry(.07,.07,.34),chromeMat,[-1.07,.91,-.58]);part(new THREE.BoxGeometry(.07,.07,.34),chromeMat,[1.07,.91,-.58]);
  for(const x of [-1.08,1.08])for(const z of [-1.35,1.35]){
    const wheel=new THREE.Group();wheel.position.set(x,.38,z);root.add(wheel);
    const tire=new THREE.Mesh(new THREE.CylinderGeometry(.39,.39,.22,12),darkMat);tire.rotation.z=Math.PI/2;tire.castShadow=true;wheel.add(tire);
    const hub=new THREE.Mesh(new THREE.CylinderGeometry(.19,.19,.235,10),chromeMat);hub.rotation.z=Math.PI/2;wheel.add(hub);wheels.push(wheel);
  }
  root.traverse(o=>{if(o.isMesh){o.castShadow=renderer.shadowMap.enabled;o.receiveShadow=true}});
  root.userData.wheels=wheels;return root;
}
function randomVehicleSpot(ignoreCar=null){
  for(let i=0;i<160;i++){
    const p=randomSpot(38,218);if(!vehicleCanMoveTo(p.x,p.z,ignoreCar))continue;
    let tooClose=false;for(const e of entities){if(e.alive&&Math.hypot(e.pos.x-p.x,e.pos.z-p.z)<15){tooClose=true;break}}
    if(!tooClose)return p;
  }
  for(let i=0;i<100;i++){const p=randomSpot(18,70);if(vehicleCanMoveTo(p.x,p.z,ignoreCar))return p;}
  return {x:0,z:35};
}
function spawnVehicle(initial=false){
  while(vehicles.length>=MAX_VEHICLES)removeVehicle(vehicles[0],false);
  const paints=['#ff7438','#4d8cf5','#45c7a5','#e5c44a','#b77aff','#f2f3f5','#e75c72'];const paint=paints[Math.floor(Math.random()*paints.length)];
  const p=randomVehicleSpot();const model=makeVehicleModel(paint);const car={id:++vehicleSerial,pos:new THREE.Vector3(p.x,0,p.z),yaw:rnd(0,Math.PI*2),speed:0,occupied:false,model,group:model,paint,bornAt:matchElapsed,expiresAt:matchElapsed+VEHICLE_LIFETIME,oldPos:new THREE.Vector3(p.x,0,p.z),wheels:model.userData.wheels||[],hitCooldown:new Map()};
  model.position.copy(car.pos);model.rotation.y=-car.yaw;world.add(model);vehicles.push(car);
  if(!initial) {makeToast('UM CARRO APARECEU EM ALGUM LUGAR DA ARENA');playTone(520,.09,'triangle',.025)}
  return car;
}
function removeVehicle(car,expired=false){
  if(!car)return;const wasDriving=activeVehicle===car;
  if(wasDriving){activeVehicle=null;cameraVehicleLastYaw=null;car.occupied=false;}
  const ix=vehicles.indexOf(car);if(ix>=0)vehicles.splice(ix,1);world.remove(car.group);
  if(wasDriving&&player?.alive){
    const rgtX=Math.cos(car.yaw),rgtZ=Math.sin(car.yaw);let ex=car.pos.x+rgtX*3.2,ez=car.pos.z+rgtZ*3.2;
    if(!canMoveTo(ex,ez,player)){ex=car.pos.x-rgtX*3.2;ez=car.pos.z-rgtZ*3.2;}
    if(!canMoveTo(ex,ez,player)){ex=clamp(car.pos.x+4,-246,246);ez=clamp(car.pos.z+3,-246,246);}
    player.pos.set(ex,0,ez);player.group.position.copy(player.pos);player.group.scale.setScalar(1);player.group.rotation.y=-car.yaw;player.group.visible=cameraMode!=='first';if(player.weaponModel)player.weaponModel.visible=true;
    if(expired)makeToast('O CARRO SAIU DE CIRCULAÇÃO');
  }
  const prompt=$('vehicle-prompt');if(prompt)prompt.classList.add('hidden');const mobileButton=$('touch-vehicle');if(mobileButton)mobileButton.classList.add('hidden');const vh=$('vehicle-hud');if(vh)vh.classList.add('hidden');
}
function nearestVehicle(e,range=5){let best=null,bd=range;for(const car of vehicles){if(car.occupied&&car!==activeVehicle)continue;const d=Math.hypot(car.pos.x-e.pos.x,car.pos.z-e.pos.z);if(d<bd){best=car;bd=d}}return best?{car:best,d:bd}:null;}
function toggleVehicle(){
  if(!player||!player.alive||!roundActive)return;
  if(activeVehicle){const car=activeVehicle;car.occupied=false;car.speed=0;activeVehicle=null;cameraVehicleLastYaw=null;
    const rx=Math.cos(car.yaw),rz=Math.sin(car.yaw);let ex=car.pos.x+rx*3.15,ez=car.pos.z+rz*3.15;
    if(!canMoveTo(ex,ez,player,car)){ex=car.pos.x-rx*3.15;ez=car.pos.z-rz*3.15;}
    if(!canMoveTo(ex,ez,player,car)){makeToast('NÃO HÁ ESPAÇO PARA SAIR DO CARRO');activeVehicle=car;car.occupied=true;return;}
    player.pos.set(ex,0,ez);player.group.position.copy(player.pos);player.group.scale.setScalar(1);player.group.rotation.y=-car.yaw;player.group.visible=cameraMode!=='first';if(player.weaponModel)player.weaponModel.visible=true;
    $('vehicle-hud').classList.add('hidden');$('vehicle-prompt').classList.add('hidden');$('touch-vehicle').textContent='DIRIGIR';makeToast('VOCÊ SAIU DO CARRO');playTone(260,.07,'triangle');return;
  }
  const nearby=nearestVehicle(player,5.5);if(!nearby){makeToast('NENHUM CARRO POR PERTO');return;}const car=nearby.car;if(car.occupied){makeToast('ESTE CARRO JÁ ESTÁ OCUPADO');return;}
  activeVehicle=car;cameraYaw=car.yaw;cameraVehicleLastYaw=car.yaw;car.occupied=true;car.speed=0;player.pos.set(car.pos.x,0,car.pos.z);player.group.position.set(car.pos.x,0,car.pos.z);player.group.scale.setScalar(.74);player.group.rotation.y=-car.yaw;player.group.visible=cameraMode!=='first';if(player.weaponModel)player.weaponModel.visible=false;
  $('vehicle-hud').classList.remove('hidden');$('touch-vehicle').textContent='SAIR DO CARRO';makeToast('VOCÊ ESTÁ DIRIGINDO — W/S ACELERAR, A/D VIRAR');playTone(390,.1,'triangle');
}
function syncPlayerToVehicle(){if(!activeVehicle||!player?.alive)return;const car=activeVehicle;player.pos.set(car.pos.x,0,car.pos.z);player.group.position.set(car.pos.x,0,car.pos.z);player.group.rotation.y=-car.yaw;player.yaw=car.yaw;}
function updateVehicleDriving(car,dt){
  let throttle=0,steer=0;if(keyDown.KeyW||keyDown.ArrowUp)throttle+=1;if(keyDown.KeyS||keyDown.ArrowDown)throttle-=1;if(keyDown.KeyD||keyDown.ArrowRight)steer+=1;if(keyDown.KeyA||keyDown.ArrowLeft)steer-=1;
  throttle+=-touchMove.y;steer+=touchMove.x;throttle=clamp(throttle,-1,1);steer=clamp(steer,-1,1);
  const old=car.pos.clone();car.oldPos.copy(old);
  if(throttle>.03)car.speed=Math.min(23,car.speed+14*throttle*dt);else if(throttle<-.03)car.speed=Math.max(-8,car.speed+17*throttle*dt);else car.speed*=Math.max(0,1-1.7*dt);
  if(Math.abs(car.speed)<.08)car.speed=0;
  if(Math.abs(car.speed)>.25&&Math.abs(steer)>.03)car.yaw+=steer*dt*(.45+Math.min(Math.abs(car.speed)/23,1)*.85)*Math.sign(car.speed);
  const nx=car.pos.x+Math.sin(car.yaw)*car.speed*dt,nz=car.pos.z-Math.cos(car.yaw)*car.speed*dt;
  if(vehicleCanMoveTo(nx,nz,car)){car.pos.x=nx;car.pos.z=nz;}else{if(Math.abs(car.speed)>2){playNoise(.08,.045,750);playTone(75,.05,'sawtooth',.025)}car.speed*=-.18;}
  car.group.position.copy(car.pos);car.group.rotation.y=-car.yaw;
  for(const wheel of car.wheels)wheel.rotation.x-=car.speed*dt/.39;
  handleVehicleImpacts(car,old,car.pos.clone());syncPlayerToVehicle();
  $('vehicle-speed').textContent=Math.round(Math.abs(car.speed)*3.6);
  if(Math.abs(car.speed)>2&&Math.random()<dt*.5&&player?.alive){playNoise(.035,.009,350)}
}
function handleVehicleImpacts(car,from,to){if(activeVehicle!==car||Math.abs(car.speed)<5)return;const dx=to.x-from.x,dz=to.z-from.z,len2=dx*dx+dz*dz;let kx=dx,kz=dz;const kl=Math.hypot(kx,kz);if(kl>.001){kx/=kl;kz/=kl}else{kx=Math.sin(car.yaw);kz=-Math.cos(car.yaw)}
  for(const bot of bots){if(!roundActive)return;if(!bot.alive||matchElapsed<(bot.vehicleHitUntil||0))continue;
    const px=bot.pos.x-from.x,pz=bot.pos.z-from.z;const t=len2>.0001?clamp((px*dx+pz*dz)/len2,0,1):1;const cx=from.x+dx*t,cz=from.z+dz*t;const swept=Math.hypot(bot.pos.x-cx,bot.pos.z-cz)<1.75;
    const rx=bot.pos.x-to.x,rz=bot.pos.z-to.z,cs=Math.cos(car.yaw),sn=Math.sin(car.yaw),localX=rx*cs+rz*sn,localZ=-rx*sn+rz*cs;const bodyOverlap=Math.abs(localX)<1.52&&Math.abs(localZ)<2.55;
    if(!swept&&!bodyOverlap)continue;bot.vehicleHitUntil=matchElapsed+1.65;bot.knockback={x:kx,z:kz,remaining:1.0,duration:1.0,speed:32};const damage=Math.round(clamp(28+(Math.abs(car.speed)-5)*3.2,35,80));damageDealt+=damage;applyDamage(bot,damage,player,false);popEffect(bot.pos.clone().add(new THREE.Vector3(0,1,0)),'#ffc94a',.65);playNoise(.17,.08,800);playTone(55,.14,'sawtooth',.045);makeToast(`ATROPELAMENTO! -${damage} DE VIDA`);
  }
}
function updateVehicles(dt){
  if(!roundActive)return;
  if(matchElapsed>=nextVehicleSpawn){spawnVehicle(false);nextVehicleSpawn=matchElapsed+VEHICLE_SPAWN_INTERVAL;}
  for(const car of [...vehicles]){
    if(matchElapsed>=car.expiresAt){removeVehicle(car,true);continue;}
    if(car===activeVehicle)updateVehicleDriving(car,dt);
  }
  updateVehiclePrompt();
}
function updateVehiclePrompt(){if(!player||!roundActive)return;const prompt=$('vehicle-prompt'),button=$('touch-vehicle');if(!prompt||!button)return;
  if(activeVehicle){prompt.classList.remove('hidden');prompt.innerHTML='<b>DIRIGINDO</b> · W/S acelerar · A/D virar · E sair';button.classList.remove('hidden');button.textContent='SAIR DO CARRO';$('vehicle-hud').classList.remove('hidden');return;}
  const near=nearestVehicle(player,5.5);if(near){prompt.classList.remove('hidden');prompt.innerHTML='<b>CARRO</b> · E / botão DIRIGIR para entrar';button.classList.remove('hidden');button.textContent='DIRIGIR';$('vehicle-hud').classList.add('hidden');}else{prompt.classList.add('hidden');button.classList.add('hidden');$('vehicle-hud').classList.add('hidden');}
}
function clearMatch(){
  clearRemotePlayers();
  activeVehicle=null;for(const car of [...vehicles]){world.remove(car.group)}vehicles.length=0;
  for(const e of entities){if(e.group?.userData?.importedController?.mixer){const c=e.group.userData.importedController;try{c.mixer.stopAllAction();c.mixer.uncacheRoot(e.group.userData.importedModelRoot)}catch{}}if(e.group)world.remove(e.group);}
  entities=[];bots.length=0;loot.splice(0).forEach(l=>world.remove(l.mesh));
  $('vehicle-prompt')?.classList.add('hidden');$('touch-vehicle')?.classList.add('hidden');$('vehicle-hud')?.classList.add('hidden');
  // Keep obstacle colliders; rebuild only dynamic shootables list.
  shootables.splice(0,shootables.length,...blockers);
  projectileEffects.splice(0).forEach(o=>world.remove(o.obj));
  for(const p of verityProjectiles){world.remove(p.obj);disposeObject(p.obj)}verityProjectiles.length=0;
  for(const fx of veritySparkEffects){world.remove(fx.obj);fx.obj.geometry?.dispose();fx.obj.material?.dispose()}veritySparkEffects.length=0;
  for(const fx of verityBlastRings){world.remove(fx.obj);fx.obj.geometry?.dispose();fx.obj.material?.dispose()}verityBlastRings.length=0;
  player=null;currentPickup=null;roundActive=false;matchEnded=false;updateVerityUI();
}
function startMatch(){
  $('top-coins').classList.remove('menu-inline');
  if(multiplayerRoom)exitCurrentMultiplayerRoom({silent:true});
  multiplayerActive=false;updateOnlineControlLayout();
  hidePanels();$('main-menu').classList.add('hidden');$('brand').classList.add('hidden');if(preview)preview.visible=false;$('hud').classList.remove('hidden');$('top-coins').classList.add('hidden');
  clearMatch();roundActive=true;training=selectedMode==='training';matchElapsed=0;roundStart=performance.now();zoneRadius=zoneInitial;damageClock=0;killCount=0;damageDealt=0;survivedSeconds=0;matchEnded=false;nextLootSpawn=0;reloadUntil=0;cameraYaw=0;cameraVehicleLastYaw=null;cameraPitch=.13;jumpVelocity=0;grounded=true;fireHeld=false;touchMove={x:0,y:0};
  const chosen=getCharacterById(profile.character)||CHARACTERS[0];
  player=addEntity(chosen,{x:0,z:0,isBot:false,name:profile.nickname,shield:100});
  const targetCount=training?Math.min(4,botCount):botCount;
  const names=['ZÉ DO PIXEL','TIO DO LAG','MISTERIO_404','BATATA SUPREMA','CAPIVARA.EXE','SENHOR PING','PATO TÁTICO','BISCOITO X','MESTRE DO CAOS','NPC RAIZ','GUGU GAMER','SR. QUADRICULADO','ROBOZINHO'];
  for(let i=0;i<targetCount;i++){
    const pos=randomSpot(55,190);const d=CHARACTERS[(i+1+Math.floor(Math.random()*3))%3];const b=addEntity(d,{...pos,isBot:true,name:names[i%names.length],shield:Math.random()<.45?0:65});b.yaw=Math.random()*Math.PI*2;b.group.rotation.y=-b.yaw;
  }
  spawnInitialLoot(training?15:27);
  nextVeritySpawn=rnd(40,64); // still rare, with a small spawn-rate increase
  nextVehicleSpawn=VEHICLE_SPAWN_INTERVAL;spawnVehicle(true);updateVehiclePrompt();updateVerityUI();
  zoneRing.visible=!training;zoneRing.scale.setScalar(zoneRadius);zoneRing.position.set(0,.035,0);
  $('match-mode-label').textContent=training?'TREINO':'SOLO';$('hud-nickname').textContent=profile.nickname;$('hud-character').textContent=chosen.name;$('kill-count').textContent='0';$('tips').classList.add('hidden');
  applyPlatformLayout();rebuildFirstPersonRig();applyCameraMode();syncRotateHint();
  if(profile.settings.quality==='low')renderer.setPixelRatio(1);else if(profile.settings.quality==='high')renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));else renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.35));
  $('loading-note').classList.add('hidden');makeToast(training?'TREINAMENTO INICIADO':'QUE COMECE O CAOS!');updateHud(true);updateWeaponHud();
}
function setRoomConnectStatus(message='',type=''){
  for(const id of ['room-connect-status','online-menu-status','room-options-status','public-rooms-status']){
    const node=$(id);if(!node)continue;node.textContent=message;node.classList.toggle('error',type==='error');node.classList.toggle('success',type==='success');
  }
}
function updateOnlineControlLayout(){
  const active=!!multiplayerActive;
  $('game-root').classList.toggle('multiplayer-active',active);
  // Lobby code and roster are intentionally not shown over the live match.
  $('online-status').classList.add('hidden');
  $('touch-fire')?.classList.remove('hidden');
  $('touch-reload')?.classList.remove('hidden');
  for(const id of ['touch-pickup','touch-verity','touch-vehicle'])$(id)?.classList.toggle('hidden',active);
  $('pause-room-details')?.classList.toggle('hidden',!active);
  if(!active){updatePickupPrompt();updateVerityUI();updateVehiclePrompt();}
}
function clearRoomUiSubscriptions(){
  for(const unsubscribe of roomUiUnsubs.splice(0)){try{unsubscribe?.()}catch{}}
}
function currentRoomLobbyState(){return multiplayerRoom?.getLobbyState?.()||onlineLobbyState||null}
function isCurrentRoomHost(state=currentRoomLobbyState()){
  return !!(state&&multiplayerRoom&&state.hostSessionId===multiplayerRoom.sessionId);
}
function setOnlineLobbyStatus(message='',type=''){
  const node=$('online-lobby-status');if(!node)return;
  node.textContent=message;node.classList.toggle('error',type==='error');node.classList.toggle('success',type==='success');
}
function makePlayerAvatar(avatarValue, className='online-player-avatar'){
  const box=document.createElement('div');box.className=className;
  const avatar=String(avatarValue||'🎮');
  if(/^data:image\/(?:jpeg|png|webp);base64,[a-z0-9+/=]+$/i.test(avatar)&&avatar.length<=24000){
    const image=document.createElement('img');image.src=avatar;image.alt='Foto do jogador';image.loading='lazy';box.append(image);
  }else box.textContent=PROFILE_AVATAR_CHOICES.includes(avatar)?avatar:'🎮';
  return box;
}
function renderOnlineLobby(state){
  if(!state||!Array.isArray(state.players))return;
  onlineLobbyState=state;
  const room=multiplayerRoom;
  if(!room)return;
  const lobby=$('multiplayer-lobby-panel');
  const title=state.visibility==='public'?'SALA PÚBLICA':'SALA PRIVADA';
  $('online-lobby-title').textContent=title;
  $('online-lobby-subtitle').textContent=state.phase==='match'?'A partida já começou.':'Compartilhe o código para seus amigos entrarem.';
  $('online-lobby-code').textContent=state.roomId||multiplayerRoomCode||'—';
  $('online-lobby-count').textContent=`${state.players.length}/${state.maxPlayers||8}`;
  const isHost=isCurrentRoomHost(state);
  const list=$('online-lobby-roster');
  const ordered=[...state.players].sort((a,b)=>Number(b.sessionId===state.hostSessionId)-Number(a.sessionId===state.hostSessionId)||((a.joinedOrder||0)-(b.joinedOrder||0)));
  const nextIds=new Set(ordered.map(person=>String(person.sessionId)));
  for(const oldCard of [...list.children]){
    const oldId=oldCard.dataset.sessionId||'';
    if(nextIds.has(oldId))oldCard.remove();
    else if(!oldCard.classList.contains('online-lobby-player-leaving')){
      oldCard.classList.add('online-lobby-player-leaving');
      oldCard.addEventListener('animationend',()=>oldCard.remove(),{once:true});
    }
  }
  for(const person of ordered){
    const card=document.createElement('article');card.className='online-lobby-player-card';
    card.dataset.sessionId=String(person.sessionId||'');
    if(person.sessionId===multiplayerRoom.sessionId)card.classList.add('is-you');
    if(person.sessionId===state.hostSessionId)card.classList.add('is-host');
    const avatar=makePlayerAvatar(person.avatar,'online-lobby-avatar');
    const identity=document.createElement('div');identity.className='online-lobby-player-identity';
    const nameLine=document.createElement('div');nameLine.className='online-lobby-player-name-line';
    const name=document.createElement('strong');name.textContent=String(person.name||'JOGADOR').slice(0,32);nameLine.append(name);
    if(person.sessionId===state.hostSessionId){const crown=document.createElement('span');crown.className='online-lobby-crown';crown.textContent='♛';crown.title='Anfitrião';crown.setAttribute('aria-label','Anfitrião');nameLine.append(crown)}
    const role=document.createElement('small');role.className='online-lobby-role';role.textContent=person.sessionId===state.hostSessionId?'Anfitrião':(person.sessionId===multiplayerRoom.sessionId?'Você':'Jogador');
    const character=document.createElement('small');character.className='online-lobby-character';character.textContent=(CHARACTERS.find(c=>c.id===person.characterId)?.name)||'PERSONAGEM';
    identity.append(nameLine,role,character);card.append(avatar,identity);
    if(isHost&&person.sessionId!==state.hostSessionId&&state.phase==='lobby'){
      const actions=document.createElement('div');actions.className='online-lobby-player-actions';
      const transfer=document.createElement('button');transfer.type='button';transfer.className='secondary';transfer.textContent='TRANSFERIR';transfer.title=`Transferir anfitrião para ${person.name||'jogador'}`;
      transfer.addEventListener('click',()=>sendLobbyAction('transfer',person.sessionId));
      const kick=document.createElement('button');kick.type='button';kick.className='lobby-kick-button';kick.textContent='EXPULSAR';kick.title=`Expulsar ${person.name||'jogador'} da sala`;
      kick.addEventListener('click',()=>sendLobbyAction('kick',person.sessionId));
      actions.append(transfer,kick);card.append(actions);
    }
    list.append(card);
  }
  $('online-lobby-start').classList.toggle('hidden',!isHost||state.phase!=='lobby');
  $('online-lobby-invite').classList.toggle('hidden',!isHost||state.phase!=='lobby');
  $('online-lobby-leave').classList.remove('hidden');
  $('online-lobby-start').disabled=!isHost||state.phase!=='lobby';
  if(state.phase==='match'){
    if(!multiplayerActive)startOnlineMatch(room);
    return;
  }
  if(lobby)lobby.classList.remove('hidden');
  if(isHost)setOnlineLobbyStatus('Você é o anfitrião. Gerencie a sala ou inicie quando todos estiverem prontos.','success');
  else setOnlineLobbyStatus('Aguardando o anfitrião iniciar a partida.');
  renderPauseRoomDetails(state);
}
function renderPauseRoomDetails(state=currentRoomLobbyState()){
  const details=$('pause-room-details');if(!details)return;
  const visible=!!(multiplayerActive&&state&&Array.isArray(state.players));
  details.classList.toggle('hidden',!visible);
  if(!visible)return;
  $('pause-room-code').textContent=state.roomId||multiplayerRoomCode||'—';
  $('pause-room-count').textContent=`${state.players.length}/${state.maxPlayers||8}`;
  const list=$('pause-room-player-list');list.replaceChildren();
  const ordered=[...state.players].sort((a,b)=>Number(b.sessionId===state.hostSessionId)-Number(a.sessionId===state.hostSessionId)||((a.joinedOrder||0)-(b.joinedOrder||0)));
  for(const person of ordered){
    const row=document.createElement('div');row.className='pause-room-player';
    row.append(makePlayerAvatar(person.avatar,'pause-room-avatar'));
    const name=document.createElement('span');name.className='pause-room-name';name.textContent=String(person.name||'JOGADOR').slice(0,32);
    row.append(name);
    if(person.sessionId===state.hostSessionId){const host=document.createElement('small');host.className='pause-room-host';host.textContent='♛ Anfitrião';row.append(host)}
    list.append(row);
  }
}
function sendLobbyAction(action,targetSessionId=''){
  const state=currentRoomLobbyState();
  if(!multiplayerRoom||!isCurrentRoomHost(state)||state?.phase!=='lobby'){
    setOnlineLobbyStatus('Somente o anfitrião pode usar essa ação.','error');return;
  }
  if(action==='kick'&&!window.confirm('Expulsar este jogador da sala?'))return;
  if(action==='transfer'&&!window.confirm('Transferir o cargo de anfitrião para este jogador?'))return;
  try{
    multiplayerRoom.send('lobby:action',{action,targetSessionId,actorSessionId:multiplayerRoom.sessionId});
    if(action==='start')setOnlineLobbyStatus('Iniciando a partida para todos os jogadores...','success');
    else if(action==='transfer')setOnlineLobbyStatus('Transferindo o cargo de anfitrião...','success');
    else if(action==='kick')setOnlineLobbyStatus('Solicitação de expulsão enviada.','success');
  }catch(error){setOnlineLobbyStatus(error?.message||'Não foi possível executar essa ação.','error')}
}
function handleOnlineRoomLost(room,message='A conexão com a sala foi encerrada. Você pode tentar entrar novamente.'){
  if(multiplayerRoom!==room)return;
  clearRoomUiSubscriptions();multiplayerRoom=null;multiplayerRoomCode='';onlineLobbyState=null;multiplayerActive=false;roundActive=false;
  $('multiplayer-lobby-panel').classList.add('hidden');$('game-root').classList.remove('multiplayer-active');$('online-status').classList.add('hidden');$('pause-room-details').classList.add('hidden');clearRemotePlayers();
  openMainMenu();showPanel('join-room-panel');setRoomConnectStatus(message,'error');
}
function handleOnlineRoomKicked(room,reason='Você foi removido da sala pelo anfitrião.'){
  if(multiplayerRoom!==room)return;
  clearRoomUiSubscriptions();multiplayerRoom=null;multiplayerRoomCode='';onlineLobbyState=null;multiplayerActive=false;roundActive=false;
  $('multiplayer-lobby-panel').classList.add('hidden');$('game-root').classList.remove('multiplayer-active');$('online-status').classList.add('hidden');$('pause-room-details').classList.add('hidden');
  room.leave?.().catch?.(()=>{});clearRemotePlayers();openMainMenu();makeToast(reason);
}
async function showMultiplayerLobby(room){
  clearRoomUiSubscriptions();
  multiplayerRoom=room;multiplayerRoomCode=String(room.roomId||'');onlineLobbyState=room.getLobbyState?.()||null;multiplayerActive=false;roundActive=false;
  $('game-root').classList.remove('multiplayer-active');$('online-status').classList.add('hidden');$('pause-room-details').classList.add('hidden');$('hud').classList.add('hidden');$('brand').classList.remove('hidden');
  if(preview)preview.visible=true;
  showPanel('multiplayer-lobby-panel');
  if(onlineLobbyState)renderOnlineLobby(onlineLobbyState);
  roomUiUnsubs.push(room.onMessage('lobby',state=>renderOnlineLobby(state)));
  roomUiUnsubs.push(room.onMessage('lobby:kicked',data=>handleOnlineRoomKicked(room,data?.reason)));
  roomUiUnsubs.push(room.onLeave(()=>handleOnlineRoomLost(room)));
  roomUiUnsubs.push(room.onError((code,message)=>setOnlineLobbyStatus(message||'Erro de conexão com a sala.','error')));
  renderPauseRoomDetails(onlineLobbyState);
}
function addRemotePlayer(state){
  const data=CHARACTERS.find(c=>c.id===state.characterId)||CHARACTERS[0];
  const e={id:state.sessionId,sessionId:state.sessionId,data,name:state.name||data.name,isBot:false,isRemote:true,alive:true,
    pos:new THREE.Vector3(state.x||0,state.y||0,state.z||0),yaw:state.yaw||0,movingSpeed:0,walkPhase:0,stepTimer:0,group:null,netTarget:null};
  e.group=makeCharacter(data,e);e.group.position.copy(e.pos);e.group.rotation.y=-e.yaw;world.add(e.group);remotePlayers.set(e.sessionId,e);return e;
}
function updateOnlineRoster(players){
  const list=$('online-player-list');if(!list)return;list.replaceChildren();
  const ordered=[...players].sort((a,b)=>Number(b.sessionId===multiplayerRoom?.sessionId)-Number(a.sessionId===multiplayerRoom?.sessionId));
  for(const state of ordered){
    const row=document.createElement('div');row.className='online-player-chip'+(state.sessionId===multiplayerRoom?.sessionId?' local':'');
    const dot=document.createElement('span');dot.className='online-player-dot';
    const avatar=document.createElement('span');avatar.className='online-player-avatar';avatar.textContent=PROFILE_AVATAR_CHOICES.includes(state.avatar)?state.avatar:'🎮';
    const identity=document.createElement('div');identity.className='online-player-identity';
    const name=document.createElement('span');name.className='online-player-name';name.textContent=state.name||'JOGADOR';
    const userId=document.createElement('small');userId.className='online-player-id';userId.textContent=state.userId||'ID indisponível';
    const character=document.createElement('small');character.className='online-player-character';character.textContent=(CHARACTERS.find(c=>c.id===state.characterId)?.name)||'ENZO';
    identity.append(name,userId);row.append(dot,avatar,identity,character);list.append(row);
  }
  $('online-player-count').textContent=String(players.length);
}
function handleOnlineSnapshot(room,snapshot){
  if(room!==multiplayerRoom||!multiplayerActive||!snapshot||!Array.isArray(snapshot.players))return;
  if(Number.isFinite(snapshot.mapSeed))rebuildArenaForSeed(snapshot.mapSeed);
  const seen=new Set();
  for(const state of snapshot.players){
    if(!state||typeof state.sessionId!=='string')continue;seen.add(state.sessionId);
    const target={x:clamp(Number(state.x)||0,-253,253),y:clamp(Number(state.y)||0,0,20),z:clamp(Number(state.z)||0,-253,253),yaw:Number(state.yaw)||0,speed:clamp(Number(state.speed)||0,0,10),moving:!!state.moving,running:!!state.running,jumping:!!state.jumping};
    if(state.sessionId===room.sessionId){
      if(player){player.name=String(state.name||profile.nickname);player.netTarget=target;player.onlineCharacterId=state.characterId;}
    }else{
      let remote=remotePlayers.get(state.sessionId);if(!remote)remote=addRemotePlayer(state);
      remote.name=String(state.name||remote.name);remote.netTarget=target;
    }
  }
  for(const [id,remote] of remotePlayers){
    if(seen.has(id))continue;
    if(remote.group){world.remove(remote.group);remote.group.traverse(o=>{if(o.isMesh){const i=shootables.indexOf(o);if(i>=0)shootables.splice(i,1)}})}
    remotePlayers.delete(id);
  }
  updateOnlineRoster(snapshot.players);updateHud(true);
  $('online-connection-state').textContent='CONECTADO';
}
function updateOnlineInterpolation(dt){
  if(!multiplayerActive)return;
  const all=[];if(player)all.push(player);for(const e of remotePlayers.values())all.push(e);
  for(const e of all){const t=e.netTarget;if(!t||!e.group)continue;const alpha=1-Math.exp(-dt*(e===player?18:12));
    e.pos.x+=(t.x-e.pos.x)*alpha;e.pos.y+=(t.y-e.pos.y)*alpha;e.pos.z+=(t.z-e.pos.z)*alpha;
    const delta=Math.atan2(Math.sin(t.yaw-e.yaw),Math.cos(t.yaw-e.yaw));e.yaw+=delta*alpha;
    e.movingSpeed=t.speed;e.isRunning=t.running;e.isJumping=t.jumping;e.group.position.set(e.pos.x,e.pos.y,e.pos.z);e.group.rotation.y=-e.yaw;
  }
}
function disconnectMultiplayer({silent=false}={}){
  const oldRoom=multiplayerRoom;clearRoomUiSubscriptions();multiplayerRoom=null;multiplayerRoomCode='';onlineLobbyState=null;multiplayerActive=false;onlineSendClock=0;onlineJumpQueued=false;
  $('game-root').classList.remove('multiplayer-active');$('online-status').classList.add('hidden');$('online-connection-state').textContent='DESCONECTADO';clearRemotePlayers();
  if(oldRoom)leaveRoom(oldRoom).catch(error=>console.warn('Saída da sala online:',error));
  if(!silent)makeToast('Você saiu da sala multiplayer.');
}
function exitCurrentMultiplayerRoom({silent=false}={}){
  const oldRoom=multiplayerRoom;
  if(!oldRoom)return;
  clearRoomUiSubscriptions();multiplayerRoom=null;multiplayerRoomCode='';onlineLobbyState=null;multiplayerActive=false;onlineSendClock=0;onlineJumpQueued=false;
  $('multiplayer-lobby-panel').classList.add('hidden');$('game-root').classList.remove('multiplayer-active');$('online-status').classList.add('hidden');$('pause-room-details').classList.add('hidden');clearRemotePlayers();
  if(typeof oldRoom.exitLobby==='function')oldRoom.exitLobby().catch(error=>console.warn('Saída da sala online:',error));
  else leaveRoom(oldRoom).catch(error=>console.warn('Saída da sala online:',error));
  if(!silent)makeToast('Você saiu da sala multiplayer.');
}
function startOnlineMatch(room){
  if(!room||room!==multiplayerRoom)return;
  if(multiplayerActive&&roundActive)return;
  clearRoomUiSubscriptions();
  $('top-coins').classList.remove('menu-inline');
  $('multiplayer-lobby-panel').classList.add('hidden');
  clearMatch();multiplayerRoom=room;multiplayerRoomCode=String(room.roomId||'');onlineLobbyState=room.getLobbyState?.()||onlineLobbyState;multiplayerActive=true;onlineSendClock=0;onlineJumpQueued=false;
  hidePanels();$('main-menu').classList.add('hidden');$('brand').classList.add('hidden');if(preview)preview.visible=false;
  $('hud').classList.remove('hidden');$('top-coins').classList.add('hidden');roundActive=true;training=true;selectedMode='online';matchElapsed=0;matchEnded=false;cameraYaw=0;cameraVehicleLastYaw=null;cameraPitch=.13;jumpVelocity=0;grounded=true;touchMove={x:0,y:0};fireHeld=false;touchFire=false;
  const chosen=getCharacterById(profile.character)||CHARACTERS[0];
  const startState=onlineLobbyState;const spawnIndex=Math.max(0,(startState?.players||[]).findIndex(p=>p.sessionId===room.sessionId));const angle=spawnIndex*2.399963229728653;const radius=spawnIndex===0?0:3+Math.floor(spawnIndex/4)*1.5;
  player=addEntity(chosen,{x:Math.sin(angle)*radius,z:Math.cos(angle)*radius,isBot:false,name:profile.nickname,shield:100});player.sessionId=room.sessionId;
  $('match-mode-label').textContent='MULTIPLAYER';$('hud-nickname').textContent=profile.nickname;$('hud-character').textContent=chosen.name;$('kill-count').textContent='0';$('tips').classList.add('hidden');
  $('online-room-code').textContent=multiplayerRoomCode||'—';$('online-connection-state').textContent='CONECTADO';$('online-status').classList.add('hidden');updateOnlineControlLayout();
  zoneRing.visible=false;applyPlatformLayout();rebuildFirstPersonRig();applyCameraMode();syncRotateHint();updateHud(true);updateWeaponHud();
  roomUiUnsubs.push(room.onMessage('snapshot',snapshot=>handleOnlineSnapshot(room,snapshot)));
  roomUiUnsubs.push(room.onMessage('lobby',state=>{onlineLobbyState=state;renderPauseRoomDetails(state)}));
  roomUiUnsubs.push(room.onLeave((code)=>{console.warn('Conexão multiplayer encerrada:',code);handleOnlineRoomLost(room)}));
  roomUiUnsubs.push(room.onError((code,message)=>{console.error('Erro na sala online:',code,message);$('online-connection-state').textContent='ERRO DE REDE';}));
  setRoomConnectStatus('');
  makeToast('Partida multiplayer iniciada!');
}
let multiplayerConnecting=false;
function currentOnlineIdentity(){const id=profile.character||'enzo';const avatar=String(profile.avatar||'🎮');const validPhoto=avatar.length<=24000&&/^data:image\/(?:jpeg|png|webp);base64,[a-z0-9+/=]+$/i.test(avatar);return {nickname:profile.nickname,userId:profile.userId,avatar:PROFILE_AVATAR_CHOICES.includes(avatar)||validPhoto?avatar:'🎮',characterId:typeof id==='string'&&id.startsWith('imported:')?'enzo':id,mapSeed:activeArenaSeed||1};}
function openRoomOptions(){setRoomConnectStatus('');showPanel('room-options-panel');}

async function createOnlineRoomFromMenu(){
  if(multiplayerConnecting)return;multiplayerConnecting=true;const button=$('create-private-room');button.disabled=true;setRoomConnectStatus('Conectando ao serviço de sinalização e criando sala privada...');
  try{const room=await createPrivateRoom(currentOnlineIdentity());showMultiplayerLobby(room);}
  catch(error){console.error('Falha ao criar sala privada:',error);setRoomConnectStatus(error?.message||'Não foi possível criar a sala privada.','error');}
  finally{multiplayerConnecting=false;button.disabled=false;}
}
async function createPublicRoomFromMenu(buttonId='create-public-room'){
  if(multiplayerConnecting)return;multiplayerConnecting=true;const button=$(buttonId);if(button)button.disabled=true;setRoomConnectStatus('Conectando ao serviço de sinalização e criando sala pública...');
  try{const room=await createPublicRoom(currentOnlineIdentity());showMultiplayerLobby(room);}
  catch(error){console.error('Falha ao criar sala pública:',error);setRoomConnectStatus(error?.message||'Não foi possível criar a sala pública.','error');}
  finally{multiplayerConnecting=false;if(button)button.disabled=false;}
}
function setPublicRoomsStatus(message='',type=''){const node=$('public-rooms-status');if(node){node.textContent=message;node.classList.toggle('error',type==='error');node.classList.toggle('success',type==='success');}}
function renderPublicRooms(rooms){
  const list=$('public-room-list');if(!list)return;list.replaceChildren();
  if(!rooms.length){const empty=document.createElement('div');empty.className='public-room-empty';empty.textContent='A lista automática global não está ativada nesta versão. Peça ao anfitrião o código de uma sala pública para entrar.';list.append(empty);return;}
  for(const roomInfo of rooms){
    const metadata=roomInfo.metadata||{};
    const count=Number(roomInfo.clients??metadata.playerCount??0);
    const max=Number(roomInfo.maxClients??metadata.maxPlayers??8);
    const card=document.createElement('article');card.className='public-room-card';
    const main=document.createElement('div');main.className='public-room-card-main';
    const title=document.createElement('strong');title.className='public-room-card-title';title.textContent=metadata.title||'Retardados Royale';
    const meta=document.createElement('small');meta.className='public-room-card-meta';meta.textContent=`Anfitrião: ${metadata.hostName||'JOGADOR'} · ${count}/${max} jogadores`;
    const code=document.createElement('span');code.className='public-room-card-code';code.textContent=`CÓDIGO: ${roomInfo.roomId}`;
    main.append(title,meta,code);
    const join=document.createElement('button');join.type='button';join.textContent='ENTRAR';join.disabled=count>=max;join.addEventListener('click',()=>joinListedPublicRoom(roomInfo.roomId,join));
    card.append(main,join);list.append(card);
  }
}
async function refreshPublicRooms(){
  if(multiplayerConnecting)return;const button=$('refresh-public-rooms');if(button)button.disabled=true;setPublicRoomsStatus('Procurando salas públicas...');
  try{const rooms=await listPublicRooms();renderPublicRooms(rooms);setPublicRoomsStatus(rooms.length?`${rooms.length} sala(s) pública(s) com vagas.`:'A listagem automática global não está disponível sem um catálogo central. Para entrar, peça o código da sala pública ao anfitrião.');}
  catch(error){console.error('Falha ao consultar informações de salas públicas:',error);renderPublicRooms([]);setPublicRoomsStatus(error?.message||'A listagem global não está disponível nesta versão. Peça o código ao anfitrião.');}
  finally{if(button)button.disabled=false;}
}
async function openPublicRooms(){showPanel('public-rooms-panel');await refreshPublicRooms();}
async function joinListedPublicRoom(roomId,button){
  if(multiplayerConnecting)return;multiplayerConnecting=true;if(button)button.disabled=true;setPublicRoomsStatus('Entrando na sala pública...');
  try{const room=await joinRoomByCode(roomId,currentOnlineIdentity());showMultiplayerLobby(room);}
  catch(error){console.error('Falha ao entrar na sala pública:',error);setPublicRoomsStatus(error?.message||'Não foi possível entrar. A sala pode ter ficado cheia; atualize a lista.','error');}
  finally{multiplayerConnecting=false;if(button)button.disabled=false;}
}
async function joinOnlineRoomFromMenu(){
  if(multiplayerConnecting)return;const code=$('room-code-input').value.trim();if(!code){setRoomConnectStatus('Digite o código da sala.','error');return;}
  multiplayerConnecting=true;$('join-room-submit').disabled=true;setRoomConnectStatus('Conectando à sala...');
  try{const room=await joinPrivateRoom(code,currentOnlineIdentity());showMultiplayerLobby(room);}
  catch(error){console.error('Falha ao entrar na sala:',error);setRoomConnectStatus(error?.message||'Não foi possível entrar. Confira o código e a conexão com a internet.','error');}
  finally{multiplayerConnecting=false;$('join-room-submit').disabled=false;}
}
async function copyOnlineRoomCode(){
  if(!multiplayerRoomCode)return;
  try{await navigator.clipboard.writeText(multiplayerRoomCode);makeToast('Código copiado: '+multiplayerRoomCode);}
  catch{window.prompt('Copie este código de sala:',multiplayerRoomCode);}
}

function spawnInitialLoot(count){for(let i=0;i<count;i++){const p=randomSpot(15,220);const r=Math.random();if(r<.49){const keys=['smg','rifle','shotgun','sniper','launcher'];const id=keys[Math.floor(Math.random()*keys.length)];spawnLoot('weapon',id,p.x,p.z)}else if(r<.68)spawnLoot('ammo','ammo',p.x,p.z);else if(r<.80)spawnLoot('shield','shield',p.x,p.z);else if(r<.90)spawnLoot('medkit','medkit',p.x,p.z);else spawnLoot('armor',ARMOR_POOL[Math.floor(Math.random()*ARMOR_POOL.length)],p.x,p.z)} }
function spawnLoot(type,id,x,z){
  const armorDef=type==='armor'?ARMOR_ITEMS[id]:null;
  const c=type==='verity'?'#ffe23c':type==='weapon'?(WEAPONS[id]?.rarity==='legendary'?'#ffbb55':WEAPONS[id]?.rarity==='rare'?'#67a7ff':WEAPONS[id]?.rarity==='uncommon'?'#62e39a':'#d9dee7'):armorDef?.color|| (type==='medkit'?'#62d78a':type==='shield'?'#62c9ff':'#f3d35b');
  const group=new THREE.Group();
  const base=type==='verity'?new THREE.Mesh(new THREE.CylinderGeometry(.43,.5,.13,12),mat('#39351f')):new THREE.Mesh(new THREE.BoxGeometry(.8,.2,.65),mat('#252a32'));base.position.y=type==='verity'?.1:.18;group.add(base);
  let top;
  if(type==='verity'){
    top=makeVerityModel();top.scale.setScalar(.88);top.position.y=.55;
  }else if(type==='medkit'){
    top=new THREE.Mesh(new THREE.BoxGeometry(.42,.35,.4),mat(c));const cross=new THREE.Mesh(new THREE.BoxGeometry(.3,.08,.08),mat('#f8f8ed'));cross.position.set(0,.3,-.01);group.add(cross);
  }else if(type==='weapon'){
    top=new THREE.Mesh(new THREE.BoxGeometry(.85,.16,.16),mat(c));top.rotation.y=.2;top.position.y=.4;
  }else if(type==='armor'&&armorDef){
    const armorMat=mat(c,.36,.62);
    if(armorDef.slot==='helmet'){
      top=new THREE.Group();const dome=new THREE.Mesh(new THREE.SphereGeometry(.27,12,8,0,Math.PI*2,0,Math.PI*.65),armorMat);dome.position.y=.47;top.add(dome);const visor=new THREE.Mesh(new THREE.BoxGeometry(.32,.07,.09),mat('#242b34',.35,.3));visor.position.set(0,.43,-.22);top.add(visor);
    }else if(armorDef.slot==='chestplate'){
      top=new THREE.Group();const plate=new THREE.Mesh(new THREE.BoxGeometry(.48,.42,.2),armorMat);plate.position.y=.43;top.add(plate);for(const side of [-1,1]){const shoulder=new THREE.Mesh(new THREE.SphereGeometry(.13,8,6),armorMat);shoulder.position.set(side*.28,.55,0);top.add(shoulder)}
    }else{
      top=new THREE.Group();for(const side of [-1,1]){const foot=new THREE.Mesh(new THREE.BoxGeometry(.2,.25,.38),armorMat);foot.position.set(side*.16,.34,-.02);top.add(foot)}
    }
    top.position.y=.08;
  }else{
    top=new THREE.Mesh(new THREE.OctahedronGeometry(.28,0),mat(c,.35,.15));top.position.y=.43;
  }
  group.add(top);
  const halo=new THREE.Mesh(new THREE.TorusGeometry(.55,.035,6,24),new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:.8}));halo.rotation.x=Math.PI/2;halo.position.y=.04;group.add(halo);
  group.position.set(x,.05,z);world.add(group);const l={id:Math.random().toString(36).slice(2),type,item:id,x,z,mesh:group,phase:Math.random()*10,expiresAt:type==='verity'?matchElapsed+88:null};loot.push(l);return l;
}
function dropLoot(e){
  const w=getActiveWeapon(e);if(w&&w.id!=='pistol'&&w.id!=='melee')spawnLoot('weapon',w.id,e.pos.x+rnd(-1.5,1.5),e.pos.z+rnd(-1.5,1.5));
  if(Math.random()<.6)spawnLoot('ammo','ammo',e.pos.x+rnd(-1.6,1.6),e.pos.z+rnd(-1.6,1.6));
  if(Math.random()<.3)spawnLoot('shield','shield',e.pos.x+rnd(-1.8,1.8),e.pos.z+rnd(-1.8,1.8));
  for(const slot of ARMOR_SLOTS){const id=e.armor?.[slot];if(id)spawnLoot('armor',id,e.pos.x+rnd(-2.0,2.0),e.pos.z+rnd(-2.0,2.0));}
  for(let i=0;i<(e.verityCount||0);i++)spawnLoot('verity','verity',e.pos.x+rnd(-2.2,2.2),e.pos.z+rnd(-2.2,2.2));e.verityCount=0;
}
function nearestLoot(e,filter=null){let best=null,bd=Infinity;for(const l of loot){if(filter&&!filter(l))continue;const d=dist2(e.pos,l);if(d<bd){bd=d;best=l}}return best?{loot:best,d:Math.sqrt(bd)}:null}
function canMoveTo(x,z,e,ignoreVehicle=null){
  const r=.48;if(Math.abs(x)>253||Math.abs(z)>253)return false;
  for(const o of blockers){const p=o.position;const box=o.geometry?.parameters;if(!box)continue;let halfX,halfZ;if(o.geometry.type==='BoxGeometry'){halfX=(box.width||1)/2;halfZ=(box.depth||1)/2;}else{halfX=halfZ=(box.radiusTop||box.radiusBottom||3);}
    if(Math.abs(x-p.x)<halfX+r&&Math.abs(z-p.z)<halfZ+r){if(o.rotation.y&&Math.abs(o.rotation.y%Math.PI)>0.05&&o.geometry.type==='BoxGeometry'){
        const dx=x-p.x,dz=z-p.z;const cs=Math.cos(-o.rotation.y),sn=Math.sin(-o.rotation.y);const lx=dx*cs-dz*sn,lz=dx*sn+dz*cs;if(Math.abs(lx)<(box.width||1)/2+r&&Math.abs(lz)<(box.depth||1)/2+r)return false;
      }else return false;}
  }
  for(const car of vehicles){if(car===ignoreVehicle||(car===activeVehicle&&e===player))continue;if(Math.abs(x-car.pos.x)<2.15&&Math.abs(z-car.pos.z)<2.55)return false;}
  return true;
}
function vehicleCanMoveTo(x,z,ignoreCar=null){
  if(Math.abs(x)>249||Math.abs(z)>249)return false;
  const vehicleRadius=2.05;
  for(const o of blockers){const box=o.geometry?.parameters;if(!box)continue;const dx=x-o.position.x,dz=z-o.position.z;let lx=dx,lz=dz;if(o.geometry.type==='BoxGeometry'){const cs=Math.cos(o.rotation.y||0),sn=Math.sin(o.rotation.y||0);lx=dx*cs-dz*sn;lz=dx*sn+dz*cs;const ox=Math.max(Math.abs(lx)-(box.width||1)/2,0),oz=Math.max(Math.abs(lz)-(box.depth||1)/2,0);if(ox*ox+oz*oz<vehicleRadius*vehicleRadius)return false;}else{const rad=Math.max(box.radiusTop||0,box.radiusBottom||0,1);if(dx*dx+dz*dz<(rad+1.65)*(rad+1.65))return false;}}
  for(const car of vehicles){if(car===ignoreCar)continue;if(Math.abs(x-car.pos.x)<3.2&&Math.abs(z-car.pos.z)<4.8)return false;}
  return true;
}
function moveEntity(e,dx,dz,dt){const ox=e.pos.x,oz=e.pos.z,nx=e.pos.x+dx*dt,nz=e.pos.z+dz*dt;if(canMoveTo(nx,e.pos.z,e))e.pos.x=nx;if(canMoveTo(e.pos.x,nz,e))e.pos.z=nz;e.group.position.x=e.pos.x;e.group.position.z=e.pos.z;e.movingSpeed=dt>0?Math.hypot(e.pos.x-ox,e.pos.z-oz)/dt:0;}
function transitionImportedAnimation(controller,role,speed=1){
  if(!controller?.actions)return false;
  let resolved=controller.actions[role]?role:null;
  if(!resolved&&role==='idle'&&controller.actions.hold)resolved='hold';
  // If there is no walk clip, a run cycle can be retimed to support regular movement.
  if(!resolved&&role==='walk'&&controller.actions.run)resolved='run';
  if(!resolved&&role==='run'&&controller.actions.walk)resolved='walk';
  const next=resolved?controller.actions[resolved]:null;
  if(!next){
    if(controller.activeAction){controller.activeAction.fadeOut(.12);controller.activeAction=null;controller.activeRole='';}
    return false;
  }
  if(controller.activeAction!==next){
    const previous=controller.activeAction;
    next.reset();next.enabled=true;next.setEffectiveWeight(1);next.setEffectiveTimeScale(speed);next.play();
    if(previous)previous.crossFadeTo(next,.2,true);
    controller.activeAction=next;controller.activeRole=resolved;
  }else next.setEffectiveTimeScale(speed);
  return true;
}
function firstBoneChild(bone){
  if(!bone)return null;
  const queue=[...(bone.children||[])];
  while(queue.length){const node=queue.shift();if(node?.isBone)return node;queue.push(...(node?.children||[]));}
  return null;
}
function alignImportedBoneSegment(bone,child,targetWorld,controller,root){
  if(!bone||!child||bone===child)return false;
  root.updateMatrixWorld(true);
  const start=bone.getWorldPosition(controller._vA),end=child.getWorldPosition(controller._vB);
  const current=end.sub(start);const target=targetWorld.clone().sub(bone.getWorldPosition(controller._vC));
  if(current.lengthSq()<1e-7||target.lengthSq()<1e-7)return false;
  current.normalize();target.normalize();
  controller._qA.setFromUnitVectors(current,target);
  bone.getWorldQuaternion(controller._qB);
  controller._qA.multiply(controller._qB);
  if(bone.parent)bone.parent.getWorldQuaternion(controller._qC);else controller._qC.identity();
  controller._qC.invert().multiply(controller._qA);
  bone.quaternion.copy(controller._qC);
  root.updateMatrixWorld(true);
  return true;
}
function updateImportedWeaponMount(e){
  const controller=e?.group?.userData?.importedController,mount=e?.weaponMount,hand=controller?.weaponHand;
  if(!mount||!hand||!e.group)return;
  e.group.updateMatrixWorld(true);
  hand.getWorldQuaternion(controller._qA);
  e.group.getWorldQuaternion(controller._qB);
  mount.quaternion.copy(controller._qA.invert().multiply(controller._qB));
  mount.position.set(0,0,0);
  mount.updateMatrixWorld(true);
}
function applyImportedWeaponPose(e,controller){
  if(!e?.weaponModel||!controller?.bones)return;
  const b=controller.bones,group=e.group;
  group.updateMatrixWorld(true);
  const worldPoint=(x,y,z,out)=>group.localToWorld(out.set(x,y,z));
  const sideOf=(bone,fallback)=>{
    if(!bone)return fallback;
    bone.getWorldPosition(controller._vD);group.worldToLocal(controller._vD);
    return Math.abs(controller._vD.x)>.015?Math.sign(controller._vD.x):fallback;
  };
  // Derive left/right from the actual imported rig after its facing correction.
  // This avoids twisting the arms across the torso when a model was rotated 180°.
  const rightSide=sideOf(b.rightArm,-1),leftSide=sideOf(b.leftArm,-rightSide);
  // Generic two-handed hold pose, layered after the imported clip.
  const rightElbow=worldPoint(rightSide*.49,1.34,-.16,controller._pA),rightWrist=worldPoint(rightSide*.34,1.19,-.48,controller._pB);
  const leftElbow=worldPoint(leftSide*.48,1.33,-.17,controller._pC),leftWrist=worldPoint(leftSide*.25,1.17,-.43,controller._pD);
  const rightForearm=b.rightForearm||firstBoneChild(b.rightArm);
  const leftForearm=b.leftForearm||firstBoneChild(b.leftArm);
  const rightHand=b.rightHand||firstBoneChild(rightForearm||b.rightArm);
  const leftHand=b.leftHand||firstBoneChild(leftForearm||b.leftArm);
  if(b.rightArm&&rightForearm)alignImportedBoneSegment(b.rightArm,rightForearm,rightElbow,controller,group);
  else if(b.rightArm&&rightHand)alignImportedBoneSegment(b.rightArm,rightHand,rightWrist,controller,group);
  if(rightForearm&&rightHand)alignImportedBoneSegment(rightForearm,rightHand,rightWrist,controller,group);
  if(b.leftArm&&leftForearm)alignImportedBoneSegment(b.leftArm,leftForearm,leftElbow,controller,group);
  else if(b.leftArm&&leftHand)alignImportedBoneSegment(b.leftArm,leftHand,leftWrist,controller,group);
  if(leftForearm&&leftHand)alignImportedBoneSegment(leftForearm,leftHand,leftWrist,controller,group);
  updateImportedWeaponMount(e);
}
function updateImportedCharacterAnimation(e,dt){
  const controller=e?.group?.userData?.importedController;if(!controller)return;
  const speed=e.alive?(e.movingSpeed||0):0;
  const isAir=e===player&&!multiplayerActive?(!grounded||(e.pos?.y||0)>.035):!!e.isJumping||(e.pos?.y||0)>.035;
  if(controller.wasAir&&!isAir&&controller.actions.land)controller.landTimer=.38;
  if(isAir)controller.landTimer=0;else controller.landTimer=Math.max(0,controller.landTimer-dt);
  controller.wasAir=isAir;
  let role='idle',timeScale=1;
  if(isAir){
    const rising=e===player&&!multiplayerActive?jumpVelocity>.25:!!e.isJumping;
    role=rising&&controller.actions.jump?'jump':controller.actions.fall?'fall':rising&&controller.actions.jump?'jump':'idle';
  }else if(controller.landTimer>0&&controller.actions.land)role='land';
  else if(speed>.45){
    if(speed>8&&controller.actions.run){role='run';timeScale=1.08;}
    else if(controller.actions.walk){role='walk';timeScale=speed>8?1.2:clamp(speed/6.4,.72,1.12);}
    else if(controller.actions.run){role='run';timeScale=speed>8?1.12:.72;}
    else role='walk';
  }
  if(!controller.actions[role]&&role!=='idle'){
    if(role==='walk'&&controller.actions.run)timeScale=speed>8?1.08:.72;
    else role='idle';
  }
  const clipActive=transitionImportedAnimation(controller,role,timeScale);
  if(controller.mixer)controller.mixer.update(dt);
  // In-place procedural gait when the imported rig has no usable walk/run cycle.
  // Do not reset the arms here; the weapon pose below owns the arm chains.
  const bones=controller.bones||{};
  const hasLegs=!!(bones.leftLeg&&bones.rightLeg);
  const hasLocomotionTracks=!!controller.hasLegAnimationTrack;
  if(hasLegs&&!hasLocomotionTracks){
    controller.phase+=dt*(speed>8?14:9.2);
    const moving=speed>.45&&!isAir&&e.alive;
    const swing=moving?Math.sin(controller.phase)*clamp(speed/7,0,1)*(speed>8?.72:.48):0;
    const baseL=controller.baseRotations.get(bones.leftLeg),baseR=controller.baseRotations.get(bones.rightLeg);
    if(baseL)bones.leftLeg.rotation.copy(baseL);
    if(baseR)bones.rightLeg.rotation.copy(baseR);
    bones.leftLeg.rotation.x=(baseL?.x||0)+swing;
    bones.rightLeg.rotation.x=(baseR?.x||0)-swing;
  }
  if(e.weaponModel)applyImportedWeaponPose(e,controller);
  if(speed>.45){
    e.stepTimer=(e.stepTimer||0)-dt;const interval=speed>8?.27:.39;
    if(e.stepTimer<=0){e.stepTimer=interval;if(e===player)soundFootstep(1);else if(player&&dist2(e.pos,player.pos)<34*34)soundFootstep(.25)}
  }else e.stepTimer=0;
}

function updateEntityAnimation(e,dt){
  if(!e?.group)return;
  if(e.group.userData.importedCharacter){updateImportedCharacterAnimation(e,dt);return;}
  if(!e.group.userData.legs)return;const speed=e.alive?(e.movingSpeed||0):0;
  if(speed>.45){e.walkPhase=(e.walkPhase||0)+dt*(speed>8?14:9.2);const amp=clamp(speed/7,0,1)*(speed>8?.78:.53);const swing=Math.sin(e.walkPhase)*amp;e.group.userData.legs[0].rotation.x=swing;e.group.userData.legs[1].rotation.x=-swing;
    e.stepTimer=(e.stepTimer||0)-dt;const interval=speed>8?.27:.39;if(e.stepTimer<=0){e.stepTimer=interval;if(e===player)soundFootstep(1);else if(player&&dist2(e.pos,player.pos)<34*34)soundFootstep(.25)}
  }else{e.stepTimer=0;for(const leg of e.group.userData.legs)leg.rotation.x+=(0-leg.rotation.x)*Math.min(1,dt*12)}
}
function getAudio(){try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}catch{return null}}
function playTone(freq=300,duration=.06,type='square',gain=.045){
  if(!profile.settings.volume)return;const ac=getAudio();if(!ac)return;try{const osc=ac.createOscillator(),g=ac.createGain();osc.type=type;osc.frequency.setValueAtTime(freq,ac.currentTime);g.gain.setValueAtTime(gain*(profile.settings.volume/60),ac.currentTime);g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+duration);osc.connect(g);g.connect(ac.destination);osc.start();osc.stop(ac.currentTime+duration)}catch{}
}
function playNoise(duration=.09,gain=.04,cutoff=1500){if(!profile.settings.volume)return;const ac=getAudio();if(!ac)return;try{const length=Math.max(1,Math.floor(ac.sampleRate*duration)),buffer=ac.createBuffer(1,length,ac.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<length;i++){const decay=1-i/length;data[i]=(Math.random()*2-1)*decay*(.7+.3*Math.random())}const src=ac.createBufferSource(),filter=ac.createBiquadFilter(),g=ac.createGain();src.buffer=buffer;filter.type='lowpass';filter.frequency.value=cutoff;g.gain.value=gain*(profile.settings.volume/60);src.connect(filter);filter.connect(g);g.connect(ac.destination);src.start()}catch{}}
function soundShot(id,volume=1){playNoise(id==='shotgun'?.15:id==='sniper'?.2:id==='launcher'?.22:.075,.12*volume,id==='sniper'?950:id==='shotgun'?1350:id==='launcher'?650:2100);playTone(id==='sniper'?72:id==='shotgun'?115:id==='launcher'?58:id==='smg'?175:220,rnd(.055,.13),id==='launcher'?'sawtooth':'square',.055*volume);if(id==='launcher')playTone(470,.16,'sine',.035*volume)}
function soundFootstep(volume=1){playNoise(.055,.025*volume,450);playTone(78,.045,'triangle',.012*volume)}
function soundJump(){playTone(270,.1,'triangle',.025);playNoise(.045,.012,700)}
function soundUiClick(){playTone(480,.035,'sine',.016)}
function flashShotIndicator(){const fx=$('shot-flash');if(!fx)return;fx.classList.add('visible');clearTimeout(fx._timer);fx._timer=setTimeout(()=>fx.classList.remove('visible'),95)}
function makeToast(txt){const t=$('toast');t.textContent=txt;t.classList.remove('hidden');toastTimer=2.1}
function addFeed(txt){const box=$('kill-feed');const d=document.createElement('div');d.textContent=txt;box.prepend(d);while(box.children.length>4)box.lastElementChild.remove();setTimeout(()=>d.remove(),5000)}
function spawnTracer(from,to,color='#ffcf78'){
  const geo=new THREE.BufferGeometry().setFromPoints([from.clone(),to.clone()]);const line=new THREE.Line(geo,new THREE.LineBasicMaterial({color,transparent:true,opacity:.9}));world.add(line);projectileEffects.push({obj:line,life:.08});
}
function popEffect(pos,color='#ff7438',size=.5){const m=new THREE.Mesh(new THREE.SphereGeometry(size,8,6),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.6,wireframe:true}));m.position.copy(pos);world.add(m);projectileEffects.push({obj:m,life:.25,expand:true})}
function fireWeapon(e,isPlayer=false){
  if(!roundActive||!e?.alive||(isPlayer&&activeVehicle))return;const w=getActiveWeapon(e);const def=weaponDef(e);const now=performance.now()/1000;if(now<e.fireAt||now<e.reloadAt)return;
  if(def.kind==='melee'){
    e.fireAt=now+def.rate;const dir=new THREE.Vector3(Math.sin(e.yaw),0,-Math.cos(e.yaw));let target=null,bd=def.range;
    for(const other of entities){if(other===e||!other.alive)continue;const d=e.pos.distanceTo(other.pos);if(d>bd)continue;const to=other.pos.clone().sub(e.pos);to.y=0;to.normalize();if(dir.dot(to)>.55){target=other;bd=d}}
    if(target){applyDamage(target,def.damage,e,false);popEffect(target.pos.clone().add(new THREE.Vector3(0,1,0)),'#f9e0ad',.3)}playTone(155,.08,'triangle');return;
  }
  if(w.ammo<=0){if(isPlayer)makeToast('SEM MUNIÇÃO — pressione R para recarregar');playTone(90,.04,'square',.02);return}
  w.ammo--;e.fireAt=now+def.rate;if(isPlayer){lastShot=now;updateWeaponHud();$('crosshair').classList.add('shooting');setTimeout(()=>$('crosshair').classList.remove('shooting'),70);flashShotIndicator()}if(isPlayer||(player&&dist2(e.pos,player.pos)<38*38))soundShot(def.id,isPlayer?1:.28);
  const pellets=def.pellets||1;
  scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);
  for(let i=0;i<pellets;i++){
    let origin,direction,hitPoint,targetHit=null,hitObj=null;
    if(isPlayer){origin=camera.position.clone();direction=camera.getWorldDirection(new THREE.Vector3());const spread=def.spread;direction.x+=rnd(-spread,spread);direction.y+=rnd(-spread,spread);direction.z+=rnd(-spread,spread);direction.normalize()}
    else{origin=e.pos.clone().add(new THREE.Vector3(0,1.42,0));const target=nearestEnemy(e);if(!target)continue;const targetPos=target.pos.clone().add(new THREE.Vector3(0,1.25,0));direction=targetPos.clone().sub(origin).normalize();const accuracy=botAccuracy();direction.x+=rnd(-accuracy,accuracy);direction.y+=rnd(-accuracy*.7,accuracy*.7);direction.z+=rnd(-accuracy,accuracy);direction.normalize()}
    raycaster.set(origin,direction);raycaster.far=def.range;
    const candidates=shootables.filter(o=>{const ent=o.userData.entity;return (!ent||ent!==e)&&(!ent||ent.alive)});const hits=raycaster.intersectObjects(candidates,false);
    if(hits.length){const h=hits[0];hitPoint=h.point.clone();hitObj=h.object;targetHit=h.object.userData.entity||null;
      if(targetHit&&targetHit!==e&&targetHit.alive&&def.kind!=='explosive'){let damage=def.damage;if(def.pellets)damage=def.damage;if(h.object.userData.part==='head')damage*=def.head||1.65;const distance=origin.distanceTo(h.point);const falloff=clamp(1-distance/(def.range*1.4),.45,1);damage=Math.round(damage*falloff);applyDamage(targetHit,damage,e,h.object.userData.part==='head');if(isPlayer)damageDealt+=damage;}
      if(def.kind==='explosive'){popEffect(hitPoint,'#ff8f43',1.15);for(const ent of entities){if(!ent.alive||ent===e)continue;const d=ent.pos.distanceTo(hitPoint);if(d<6)applyDamage(ent,Math.round(55*(1-d/8)),e,false)}}
      else if(targetHit)popEffect(hitPoint,'#ffd56c',.16);
    }else{hitPoint=origin.clone().add(direction.multiplyScalar(def.range))}
    spawnTracer(origin,hitPoint,def.id==='sniper'?'#fff2b8':def.id==='launcher'?'#ff864a':'#ffdc8a');
  }
  if(w.ammo===0&&w.reserve>0&&isPlayer)makeToast('Carregador vazio — R para recarregar');
  if(isPlayer)updateWeaponHud();
}
function botAccuracy(){return botDifficulty==='easy'?.09:botDifficulty==='hard'?.025:.055}
function nearestEnemy(e){let best=null,bd=Infinity;for(const o of entities){if(o===e||!o.alive)continue;const d=dist2(e.pos,o.pos);if(d<bd){bd=d;best=o}}return best}
function applyDamage(target,amount,attacker,headshot=false){
  if(!target||!target.alive||amount<=0)return;let dmg=amount;
  if(target.shield>0){const soak=Math.min(target.shield,dmg);target.shield-=soak;dmg-=soak;playTone(530,.025,'sine',.015)}
  if(dmg>0)target.hp=Math.max(0,target.hp-dmg);
  if(attacker){attacker.damage=(attacker.damage||0)+amount;}
  if(attacker===player&&target!==player)addDailyMissionProgress('damage',amount);
  if(target===player){$('hit-direction').classList.remove('hidden');setTimeout(()=>$('hit-direction').classList.add('hidden'),180);playTone(110,.07,'sawtooth',.03)}
  if(headshot&&attacker===player)makeToast('ACERTO NA CABEÇA!');
  if(target.hp<=0)eliminate(target,attacker);
  if(target===player)updateHud(true);
}
function eliminate(e,killer){
  if(!e.alive)return;e.alive=false;e.group.visible=false;e.hp=0;
  dropLoot(e);
  if(killer){killer.scoreKills=(killer.scoreKills||0)+1;if(killer===player){killCount++;profile.missions.kills++;addDailyMissionProgress('kills',1);$('kill-count').textContent=killCount;addFeed(`Você eliminou ${e.name}`);playTone(720,.15,'triangle',.05)}else if(e===player){addFeed(`${killer.name} eliminou você`)}}
  else addFeed(`${e.name} foi eliminado`);
  if(e===player){endMatch(false);return}
  if(!training&&entities.filter(e=>e.alive).length<=1&&player?.alive){endMatch(true);return}
  updateHud(true);
}
function reloadPlayer(){if(!player||!player.alive||!roundActive)return;const w=getActiveWeapon(player),def=weaponDef(player);if(def.kind==='melee'||w.ammo===def.mag||w.reserve<=0||performance.now()/1000<player.reloadAt)return;player.reloadAt=performance.now()/1000+def.reload;reloadUntil=player.reloadAt;makeToast('RECARREGANDO...');playTone(190,.09,'triangle');setTimeout(()=>{if(!player||!roundActive)return;const active=getActiveWeapon(player);const d=weaponDef(player);if(d.kind==='melee')return;const need=d.mag-active.ammo;const take=Math.min(need,active.reserve);active.ammo+=take;active.reserve-=take;player.reloadAt=0;reloadUntil=0;updateWeaponHud();playTone(380,.08,'triangle')},def.reload*1000)}
function switchWeapon(slot){
  if(!player||!roundActive||multiplayerActive)return;
  const index=Number(slot);
  if(!Number.isInteger(index)||index<0||index>=player.weaponSlots.length)return;
  const changed=index!==player.activeSlot;
  player.activeSlot=index;
  attachWeaponModel(player);
  updateWeaponHud();
  if(changed){playTone(350,.035,'sine',.018);makeToast(`${weaponDef(player).name} equipada`)}
}
function collectNearest(e){const near=nearestLoot(e);if(!near||near.d>3.0){if(e===player)makeToast('Nenhum item por perto');return false}const l=near.loot;
  if(l.type==='weapon'){
    const existing=e.weaponSlots.findIndex(w=>w.id===l.item);
    if(existing>=0){const w=e.weaponSlots[existing],def=WEAPONS[w.id];w.reserve=Math.min(w.reserve+def.mag,def.mag*5);makeToast(`${def.name}: munição recolhida`)}
    else{const fresh=newWeapon(l.item);if(e.weaponSlots.length<5){e.weaponSlots.push(fresh);e.activeSlot=e.weaponSlots.length-1}else{e.weaponSlots[e.activeSlot]=fresh}attachWeaponModel(e);makeToast(`${WEAPONS[l.item].name} coletada`)}
  }else if(l.type==='ammo'){
    for(const w of e.weaponSlots){if(w.id!=='melee')w.reserve+=w.id==='sniper'?5:w.id==='launcher'?2:24}makeToast('Munição coletada');
  }else if(l.type==='armor'){
    const armor=ARMOR_ITEMS[l.item];if(!armor){makeToast('Armadura desconhecida');return false}
    const previous=ARMOR_ITEMS[e.armor?.[armor.slot]];
    if(!equipArmor(e,l.item,{dropOld:true})){makeToast(`Você já tem ${ARMOR_SLOT_LABELS[armor.slot].toLowerCase()} igual ou melhor`);return false}
    makeToast(`${armor.name} equipada · +${armor.shield-(previous?.shield||0)} de escudo máximo`);
  }else if(l.type==='verity'){
    if(e!==player){return false}
    e.verityCount=(e.verityCount||0)+1;updateVerityUI();makeToast(`VERITY coletado · ${e.verityCount} arremesso${e.verityCount===1?'':'s'} disponível${e.verityCount===1?'':'is'}`);
  }else if(l.type==='shield'){if(e.shield>=e.maxShield&&e.hp>=100){makeToast('Escudo e vida já estão cheios');return false}e.shield=Math.min(e.maxShield,e.shield+35);makeToast('Escudo recuperado')}
  else if(l.type==='medkit'){if(e.hp>=100){makeToast('Vida já está cheia');return false}e.hp=Math.min(100,e.hp+45);makeToast('Vida recuperada')}
  world.remove(l.mesh);const ix=loot.indexOf(l);if(ix>=0)loot.splice(ix,1);playTone(650,.07,'sine');if(e===player)updateWeaponHud();return true;
}
function updatePlayer(dt){
  if(!player||!player.alive)return;const now=performance.now()/1000;player.movingSpeed=0;
  if(multiplayerActive){
    let forward=0,right=0;if(keyDown.KeyW||keyDown.ArrowUp)forward+=1;if(keyDown.KeyS||keyDown.ArrowDown)forward-=1;if(keyDown.KeyD||keyDown.ArrowRight)right+=1;if(keyDown.KeyA||keyDown.ArrowLeft)right-=1;
    forward+=-touchMove.y;right+=touchMove.x;let len=Math.hypot(forward,right);if(len>1){forward/=len;right/=len}
    onlineSendClock+=dt;
    if(multiplayerRoom&&onlineSendClock>=.05){onlineSendClock%=.05;try{multiplayerRoom.send('input',{forward,right,yaw:cameraYaw,run:!!(keyDown.ShiftLeft||keyDown.ShiftRight),jump:!!(onlineJumpQueued||keyDown.Space)});}catch(error){console.warn('Could not send movement input:',error)}onlineJumpQueued=false;}
    updatePickupPrompt();return;
  }
  if(activeVehicle){syncPlayerToVehicle();player.movingSpeed=0;return;}
  if(player.knockback&&player.knockback.remaining>0){const k=player.knockback,ratio=clamp(k.remaining/k.duration,0,1);moveEntity(player,k.x*k.speed*ratio,k.z*k.speed*ratio,dt);player.yaw=Math.atan2(k.x,-k.z);player.group.rotation.y=-player.yaw;k.remaining-=dt;if(k.remaining<=0)player.knockback=null;player.group.position.y=player.pos.y;updatePickupPrompt();return;}else if(player.knockback)player.knockback=null;
  let forward=0,right=0;if(keyDown.KeyW||keyDown.ArrowUp)forward+=1;if(keyDown.KeyS||keyDown.ArrowDown)forward-=1;if(keyDown.KeyD||keyDown.ArrowRight)right+=1;if(keyDown.KeyA||keyDown.ArrowLeft)right-=1;
  forward+=-touchMove.y;right+=touchMove.x;let len=Math.hypot(forward,right);if(len>1){forward/=len;right/=len}
  const fwd=new THREE.Vector3(Math.sin(cameraYaw),0,-Math.cos(cameraYaw));const rgt=new THREE.Vector3(Math.cos(cameraYaw),0,Math.sin(cameraYaw));const move=fwd.multiplyScalar(forward).add(rgt.multiplyScalar(right));const sprint=keyDown.ShiftLeft||keyDown.ShiftRight;const speed=sprint?10:6.4;
  if(len>.01){moveEntity(player,move.x*speed,move.z*speed,dt);player.yaw=Math.atan2(move.x,-move.z);if(profile.equipped?.includes('trail')){trailClock-=dt;if(trailClock<=0){trailClock=.075;const cube=new THREE.Mesh(new THREE.BoxGeometry(.14,.14,.14),new THREE.MeshBasicMaterial({color:Math.random()<.5?'#5de3db':'#ffcc5c',transparent:true,opacity:.8}));cube.position.set(player.pos.x+rnd(-.45,.45),.18+rnd(0,.25),player.pos.z+rnd(-.45,.45));world.add(cube);projectileEffects.push({obj:cube,life:.55,expand:true})}}}
  else player.yaw=cameraYaw;
  if(cameraMode==='first')player.yaw=cameraYaw;
  player.group.rotation.y=-player.yaw;
  if(keyDown.Space&&grounded){jumpVelocity=7.4;grounded=false;soundJump()}
  if(!grounded){jumpVelocity-=20*dt;player.pos.y+=jumpVelocity*dt;if(player.pos.y<=0){player.pos.y=0;jumpVelocity=0;grounded=true}}
  player.group.position.y=player.pos.y;
  // Mobile firing is intentionally bound only to the on-screen FIRE button.
  // Touches can synthesize mouse events on some browsers, so ignore desktop-fire state in mobile mode.
  const desktopFire=effectivePlatform()!=='mobile'&&(mouseDown||fireHeld||keyDown.KeyF);
  if(desktopFire||touchFire)fireWeapon(player,true);
  updatePickupPrompt();
}
function updatePickupPrompt(){
  updateVerityUI();
  if(multiplayerActive){currentPickup=null;$('pickup-prompt').classList.add('hidden');$('touch-pickup')?.classList.add('hidden');return}
  const actionButton=$('touch-pickup');
  if(!player||!roundActive){currentPickup=null;$('pickup-prompt').classList.add('hidden');actionButton?.classList.add('hidden');return}
  const n=nearestLoot(player);
  if(n&&n.d<3){
    currentPickup=n.loot;
    $('pickup-name').textContent=n.loot.type==='verity'?'VERITY · GRANADA DE ONDA':n.loot.type==='weapon'?(WEAPONS[n.loot.item]?.name||'ARMA'):n.loot.type==='armor'?(ARMOR_ITEMS[n.loot.item]?.name||'ARMADURA'):n.loot.type==='ammo'?'MUNIÇÃO':n.loot.type==='shield'?'POÇÃO DE ESCUDO':'KIT DE CURA';
    $('pickup-prompt').classList.remove('hidden');
    actionButton?.classList.toggle('hidden',effectivePlatform()!=='mobile');
    if(actionButton){actionButton.textContent='E';actionButton.setAttribute('aria-label',`Interagir: pegar ${$('pickup-name').textContent}`);actionButton.title=`Pegar ${$('pickup-name').textContent}`}
  }else{
    currentPickup=null;$('pickup-prompt').classList.add('hidden');actionButton?.classList.add('hidden');
  }
}
function updateBots(dt){if(!roundActive)return;const now=performance.now()/1000;
  for(const b of bots){if(!b.alive)continue;b.movingSpeed=0;
    if(b.knockback&&b.knockback.remaining>0){const k=b.knockback,ratio=clamp(k.remaining/k.duration,0,1);moveEntity(b,k.x*k.speed*ratio,k.z*k.speed*ratio,dt);k.remaining-=dt;if(k.remaining<=0)b.knockback=null;continue;}else if(b.knockback)b.knockback=null;
    b.aiThink-=dt;let target=nearestEnemy(b);if(!target)continue;const delta=target.pos.clone().sub(b.pos);const d=delta.length();const dir=delta.clone().setY(0).normalize();b.yaw=Math.atan2(dir.x,-dir.z);b.group.rotation.y=-b.yaw;
    // Bots who only have a starter pistol occasionally detour to a nearby weapon pickup.
    const best=nearestLoot(b,l=>l.type!=='verity');const hasStarter=b.weaponSlots.every(w=>w.id==='pistol'||w.id==='melee');const armorUpgrade=best?.loot.type==='armor'&&canEquipArmor(b,best.loot.item);let seekLoot=!!best&&best.d<50&&((hasStarter&&Math.random()<.55)||(armorUpgrade&&best.d<18&&Math.random()<.6));
    let moveDir=dir.clone();if(seekLoot){moveDir=new THREE.Vector3(best.loot.x-b.pos.x,0,best.loot.z-b.pos.z).normalize();if(best.d<2.4)collectBotLoot(b,best.loot)}
    else if(d<13){moveDir.multiplyScalar(-.35);moveDir.add(new THREE.Vector3(dir.z*b.strafe*.85,0,-dir.x*b.strafe*.85)).normalize()}
    else if(d<38){moveDir.multiplyScalar(.35);moveDir.add(new THREE.Vector3(dir.z*b.strafe*.8,0,-dir.x*b.strafe*.8)).normalize()}
    const spd=botDifficulty==='hard'?4.3:botDifficulty==='easy'?2.3:3.3;moveEntity(b,moveDir.x*spd,moveDir.z*spd,dt);
    if(b.aiThink<=0){b.aiThink=rnd(.5,1.2);if(Math.random()<.08)b.strafe*=-1;}
    if(d<70&&now>=b.fireAt&&now>=b.reloadAt){const def=weaponDef(b),w=getActiveWeapon(b);if(def.kind!=='melee'&&w.ammo===0){if(w.reserve>0){b.reloadAt=now+def.reload;const reloadDur=def.reload;setTimeout(()=>{if(!b.alive)return;const active=getActiveWeapon(b),wd=weaponDef(b),take=Math.min(wd.mag-active.ammo,active.reserve);active.ammo+=take;active.reserve-=take;b.reloadAt=0;attachWeaponModel(b)},reloadDur*1000)}else{b.weaponSlots[0]=newWeapon('melee');b.activeSlot=0;attachWeaponModel(b)}}else if(d<def.range&&d>2){
        // Bots now use the same ray/hitbox damage path as the player; accuracy remains difficulty-scaled.
        fireWeapon(b,false);b.fireAt=Math.max(b.fireAt,now+def.rate*rnd(1.08,1.35));
      }}
  }
}
function canEquipArmor(e,itemId){const item=ARMOR_ITEMS[itemId];if(!item)return false;const current=ARMOR_ITEMS[e.armor?.[item.slot]];return !current||item.shield>current.shield}
function collectBotLoot(b,l){if(!l||!loot.includes(l))return;if(l.type==='weapon'){if(b.weaponSlots.every(w=>w.id==='pistol'||w.id==='melee')){b.weaponSlots[0]=newWeapon(l.item);b.activeSlot=0;attachWeaponModel(b)}else if(Math.random()<.35){b.weaponSlots[0]=newWeapon(l.item);b.activeSlot=0;attachWeaponModel(b)}}else if(l.type==='armor'){if(!equipArmor(b,l.item,{dropOld:true}))return;}else if(l.type==='shield')b.shield=Math.min(b.maxShield,b.shield+25);else if(l.type==='medkit')b.hp=Math.min(100,b.hp+30);else if(l.type==='ammo')for(const w of b.weaponSlots)w.reserve+=15;world.remove(l.mesh);loot.splice(loot.indexOf(l),1)}
function updateLoot(dt){for(let i=loot.length-1;i>=0;i--){const l=loot[i];if(l.type==='verity'&&l.expiresAt!=null&&matchElapsed>=l.expiresAt){world.remove(l.mesh);loot.splice(i,1);nextVeritySpawn=Math.max(nextVeritySpawn,matchElapsed+rnd(18,32));continue}l.phase+=dt;l.mesh.position.y=.05+Math.sin(l.phase*2)*.12;l.mesh.rotation.y+=dt*(l.type==='verity'?.85:.45);if(l.type==='verity'){const top=l.mesh.children[1];if(top)top.rotation.y+=dt*1.35;}}}
function disposeObject(obj){obj?.traverse?.(o=>{if(o.isMesh||o.isPoints||o.isLine){o.geometry?.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material?.dispose()}})}
function updateVerityUI(){
  const count=player?.verityCount||0;const badge=$('verity-counter'),number=$('verity-count'),button=$('touch-verity');
  if(number)number.textContent=count;if(badge)badge.classList.toggle('hidden',count<=0);
  if(button){button.classList.toggle('hidden',count<=0||effectivePlatform()!=='mobile');button.textContent=`✹ V ×${count}`;button.setAttribute('aria-label',`Arremessar Verity. Disponíveis: ${count}`)}
}
function throwVerity(e=player){
  if(!roundActive||!e?.alive||e!==player)return;
  if(activeVehicle){makeToast('Saia do carro para arremessar Verity');return}
  if((e.verityCount||0)<=0){makeToast('Você não tem Verity. Procure o item dourado na arena.');return}
  scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);
  const aim=camera.getWorldDirection(new THREE.Vector3()).normalize();
  let flat=new THREE.Vector3(aim.x,0,aim.z);if(flat.lengthSq()<.001)flat.set(Math.sin(e.yaw),0,-Math.cos(e.yaw));flat.normalize();
  const origin=e.pos.clone().add(new THREE.Vector3(flat.x*.65,1.35,flat.z*.65));
  const obj=makeVerityModel();obj.scale.setScalar(.82);obj.position.copy(origin);world.add(obj);
  const vertical=clamp(6.8+aim.y*5,5.8,9.1);const speed=17;
  verityProjectiles.push({obj,velocity:new THREE.Vector3(flat.x*speed,vertical,flat.z*speed),life:0});
  e.verityCount--;updateVerityUI();playTone(330,.09,'triangle',.045);playNoise(.07,.025,920);makeToast(`VERITY arremessado · ${e.verityCount} restante${e.verityCount===1?'':'s'}`);
}
function explodeVerity(pos){
  pos.y=.12;
  const ring=new THREE.Mesh(new THREE.TorusGeometry(1,.095,8,48),new THREE.MeshBasicMaterial({color:'#ffe33d',transparent:true,opacity:.96,depthWrite:false,side:THREE.DoubleSide}));ring.rotation.x=Math.PI/2;ring.position.copy(pos);world.add(ring);verityBlastRings.push({obj:ring,life:.62,maxLife:.62});
  popEffect(pos.clone().add(new THREE.Vector3(0,.65,0)),'#ffe13a',1.35);
  const count=88,positions=new Float32Array(count*3),velocities=new Float32Array(count*3);
  for(let i=0;i<count;i++){
    positions[i*3]=pos.x+rnd(-.28,.28);positions[i*3+1]=pos.y+rnd(.2,.8);positions[i*3+2]=pos.z+rnd(-.28,.28);
    const angle=rnd(0,Math.PI*2),speed=rnd(7,26),up=rnd(4,18);velocities[i*3]=Math.cos(angle)*speed;velocities[i*3+1]=up;velocities[i*3+2]=Math.sin(angle)*speed;
  }
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const material=new THREE.PointsMaterial({color:'#ffdf32',size:.23,sizeAttenuation:true,transparent:true,opacity:1,depthWrite:false,blending:THREE.AdditiveBlending});
  const sparks=new THREE.Points(geo,material);world.add(sparks);veritySparkEffects.push({obj:sparks,velocities,age:0,life:1.25});
  const radius=25;
  for(const ent of entities){
    if(!ent.alive)continue;
    const dx=ent.pos.x-pos.x,dz=ent.pos.z-pos.z,d=Math.hypot(dx,dz);if(d>radius)continue;
    let kx=dx,kz=dz;if(d<.05){const a=rnd(0,Math.PI*2);kx=Math.cos(a);kz=Math.sin(a)}else{kx/=d;kz/=d}
    if(ent===player&&activeVehicle){const car=activeVehicle;car.yaw=Math.atan2(kx,-kz);car.speed=Math.max(car.speed,26*(1-d/radius*.25));continue}
    const strength=clamp(48*(1-d/radius*.3),32,48);ent.knockback={x:kx,z:kz,remaining:1.18,duration:1.18,speed:strength};
    if(ent===player)makeToast('ONDA DE CHOQUE! Você foi arremessado para longe!');
  }
  playNoise(.42,.11,190);playTone(72,.48,'sawtooth',.095);playTone(780,.18,'triangle',.04);makeToast('VERITY DETONOU — ONDA DE CHOQUE!');
}
function updateVerityProjectiles(dt){
  for(let i=verityProjectiles.length-1;i>=0;i--){const p=verityProjectiles[i];p.life+=dt;p.velocity.y-=18*dt;p.obj.position.addScaledVector(p.velocity,dt);p.obj.rotation.x+=dt*7;p.obj.rotation.y+=dt*9;
    if(p.obj.position.y<=.34||Math.abs(p.obj.position.x)>255||Math.abs(p.obj.position.z)>255){const at=p.obj.position.clone();world.remove(p.obj);disposeObject(p.obj);verityProjectiles.splice(i,1);explodeVerity(at);}
  }
}
function updateVerityEffects(dt){
  for(let i=verityBlastRings.length-1;i>=0;i--){const fx=verityBlastRings[i];fx.life-=dt;const t=1-clamp(fx.life/fx.maxLife,0,1);fx.obj.scale.setScalar(1+t*25);fx.obj.material.opacity=Math.max(0,fx.life/fx.maxLife);if(fx.life<=0){world.remove(fx.obj);disposeObject(fx.obj);verityBlastRings.splice(i,1)}}
  for(let i=veritySparkEffects.length-1;i>=0;i--){const fx=veritySparkEffects[i];fx.age+=dt;const a=fx.obj.geometry.attributes.position;for(let j=0;j<a.count;j++){const ix=j*3;a.array[ix]+=fx.velocities[ix]*dt;a.array[ix+1]+=fx.velocities[ix+1]*dt;fx.velocities[ix+1]-=23*dt;a.array[ix+2]+=fx.velocities[ix+2]*dt;}a.needsUpdate=true;fx.obj.material.opacity=Math.max(0,1-fx.age/fx.life);if(fx.age>=fx.life){world.remove(fx.obj);disposeObject(fx.obj);veritySparkEffects.splice(i,1)}}
}

function updateZone(dt){if(training){zoneRing.visible=false;$('zone-label').textContent='TREINO LIVRE';return}zoneRing.visible=true;const elapsed=matchElapsed;let factor=clamp((elapsed-zoneStarts)/zoneDuration,0,1);zoneRadius=zoneInitial-(zoneInitial-zoneFinal)*factor;zoneRing.scale.setScalar(zoneRadius);$('zone-label').textContent=elapsed<zoneStarts?'FECHA EM '+Math.ceil(zoneStarts-elapsed)+'s':factor>=1?'ZONA FINAL':'RAIO '+Math.round(zoneRadius)+'m';
  damageClock+=dt;if(damageClock>=1){damageClock=0;for(const e of entities){if(!e.alive)continue;const d=Math.hypot(e.pos.x,e.pos.z);if(d>zoneRadius){const dmg=elapsed<zoneStarts?2:Math.min(15,4+Math.floor((elapsed-zoneStarts)/35));applyDamage(e,dmg,null,false);if(e===player)makeToast('FORA DA ZONA SEGURA!')}}}
}
function placeCameraWithCollision(pivot, desiredPosition, dt){
  cameraRayDirection.copy(desiredPosition).sub(pivot);
  const desiredDistance=cameraRayDirection.length();
  if(desiredDistance<.001){camera.position.copy(desiredPosition);return;}
  cameraRayDirection.multiplyScalar(1/desiredDistance);
  cameraCollisionRaycaster.set(pivot,cameraRayDirection);
  cameraCollisionRaycaster.near=.08;
  cameraCollisionRaycaster.far=desiredDistance;
  let safeDistance=desiredDistance;
  if(blockers.length){
    const hit=cameraCollisionRaycaster.intersectObjects(blockers,false)[0];
    if(hit)safeDistance=Math.min(safeDistance,Math.max(.55,hit.distance-.3));
  }
  cameraResolvedPosition.copy(pivot).addScaledVector(cameraRayDirection,safeDistance);
  const obstructed=safeDistance<desiredDistance-.08;
  // Compress quickly against a wall; return to the preferred boom length more gently.
  camera.position.lerp(cameraResolvedPosition,1-Math.exp(-dt*(obstructed?24:6.5)));
}
function updateCamera(dt){
  if(!player){
    if(preview)preview.rotation.y+=dt*.15;
    cameraOrbitPosition.set(7,5.3,13);
    camera.position.lerp(cameraOrbitPosition,1-Math.exp(-dt*2));
    camera.lookAt(0,1.4,3);return;
  }
  if(activeVehicle){
    const car=activeVehicle;
    // Keep the camera azimuth relative to the vehicle as it steers, while preserving manual orbit input.
    if(cameraVehicleLastYaw===null)cameraVehicleLastYaw=car.yaw;
    const vehicleYawDelta=Math.atan2(Math.sin(car.yaw-cameraVehicleLastYaw),Math.cos(car.yaw-cameraVehicleLastYaw));
    cameraYaw+=vehicleYawDelta;cameraVehicleLastYaw=car.yaw;
    const fx=Math.sin(car.yaw),fz=-Math.cos(car.yaw);
    if(cameraMode==='first'){
      cameraOrbitPosition.set(car.pos.x+fx*.42,car.pos.y+1.42,car.pos.z+fz*.42);
      camera.position.lerp(cameraOrbitPosition,1-Math.exp(-dt*14));
      cameraRayDirection.set(Math.sin(cameraYaw),-cameraPitch,-Math.cos(cameraYaw)).normalize();
      cameraLookTarget.copy(camera.position).addScaledVector(cameraRayDirection,80);
      camera.lookAt(cameraLookTarget);
    }else{
      cameraPivot.set(car.pos.x,car.pos.y+1.15,car.pos.z);
      const dist=7.4,height=3.15;
      cameraOrbitPosition.set(car.pos.x-Math.sin(cameraYaw)*dist,car.pos.y+height+cameraPitch*2,car.pos.z+Math.cos(cameraYaw)*dist);
      placeCameraWithCollision(cameraPivot,cameraOrbitPosition,dt);
      cameraLookTarget.set(car.pos.x+Math.sin(cameraYaw)*5,car.pos.y+1.0-cameraPitch*4,car.pos.z-Math.cos(cameraYaw)*5);
      camera.lookAt(cameraLookTarget);
    }
    camera.updateMatrixWorld(true);if(firstPersonRig)firstPersonRig.visible=false;if(player.group)player.group.visible=cameraMode!=='first';return;
  }
  if(cameraMode==='first'){
    cameraOrbitPosition.set(player.pos.x,player.pos.y+1.62,player.pos.z);
    camera.position.lerp(cameraOrbitPosition,1-Math.exp(-dt*14));
    cameraRayDirection.set(Math.sin(cameraYaw),-cameraPitch,-Math.cos(cameraYaw)).normalize();
    cameraLookTarget.copy(camera.position).addScaledVector(cameraRayDirection,80);
    camera.lookAt(cameraLookTarget);camera.updateMatrixWorld(true);
  }else{
    // The view yaw determines both the camera boom and the movement frame. Strafe/turn animations
    // no longer pull the camera to an independent player-facing yaw.
    cameraPivot.set(player.pos.x,player.pos.y+1.45,player.pos.z);
    const dist=5.8,height=2.2;
    cameraOrbitPosition.set(
      player.pos.x-Math.sin(cameraYaw)*dist,
      player.pos.y+height+cameraPitch*3,
      player.pos.z+Math.cos(cameraYaw)*dist
    );
    placeCameraWithCollision(cameraPivot,cameraOrbitPosition,dt);
    cameraLookTarget.set(
      player.pos.x+Math.sin(cameraYaw)*13,
      player.pos.y+1.45-cameraPitch*7,
      player.pos.z-Math.cos(cameraYaw)*13
    );
    camera.lookAt(cameraLookTarget);camera.updateMatrixWorld(true);
  }
  const showFP=roundActive&&cameraMode==='first'&&player.alive;
  if(firstPersonRig)firstPersonRig.visible=showFP&&!activeVehicle;
  if(player.group&&player.alive)player.group.visible=activeVehicle?cameraMode!=='first':!showFP;
}
function updateMinimap(){if(!player)return;const scale=0.2;const px=clamp(50+player.pos.x*scale,2,98),pz=clamp(50+player.pos.z*scale,2,98);$('minimap-player').style.left=px+'%';$('minimap-player').style.top=pz+'%';const d=clamp(zoneRadius*scale,7,98);$('minimap-zone').style.width=d*2+'%';$('minimap-zone').style.height=d*2+'%';const container=$('minimap-dots');container.innerHTML='';for(const b of bots){if(!b.alive)continue;const dot=document.createElement('i');dot.className='minimap-dot';dot.style.left=clamp(50+b.pos.x*scale,2,98)+'%';dot.style.top=clamp(50+b.pos.z*scale,2,98)+'%';container.append(dot)}for(const remote of remotePlayers.values()){const dot=document.createElement('i');dot.className='minimap-remote-dot';dot.style.left=clamp(50+remote.pos.x*scale,2,98)+'%';dot.style.top=clamp(50+remote.pos.z*scale,2,98)+'%';container.append(dot)}for(const car of vehicles){const dot=document.createElement('i');dot.className='minimap-car-dot';dot.title='Carro';dot.style.left=clamp(50+car.pos.x*scale,2,98)+'%';dot.style.top=clamp(50+car.pos.z*scale,2,98)+'%';container.append(dot)}for(const item of loot){if(item.type!=='verity')continue;const dot=document.createElement('i');dot.className='minimap-verity-dot';dot.title='Verity';dot.style.left=clamp(50+item.x*scale,2,98)+'%';dot.style.top=clamp(50+item.z*scale,2,98)+'%';container.append(dot)}}
function updateHud(force=false){if(!player)return;const now=performance.now();if(!force&&now-lastHud<100)return;lastHud=now;$('hp-number').textContent=Math.ceil(player.hp);$('shield-number').textContent=`${Math.ceil(player.shield)} / ${Math.ceil(player.maxShield)}`;$('health-fill').style.width=clamp(player.hp,0,100)+'%';$('shield-fill').style.width=clamp(player.shield/Math.max(1,player.maxShield)*100,0,100)+'%';$('alive-count').textContent=multiplayerActive?(1+remotePlayers.size):entities.filter(e=>e.alive).length;$('kill-count').textContent=killCount;$('match-time').textContent=formatTime(matchElapsed);updateMinimap();updateVerityUI()}
function formatTime(s){s=Math.floor(s);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function weaponThumbnail(id='pistol'){
  if(Object.prototype.hasOwnProperty.call(weaponPreviewCache,id))return weaponPreviewCache[id];
  if(weaponPreviewFailed)return null;
  try{
    if(!weaponPreviewRenderer){
      const thumbCanvas=document.createElement('canvas');thumbCanvas.width=144;thumbCanvas.height=48;
      weaponPreviewRenderer=new THREE.WebGLRenderer({canvas:thumbCanvas,alpha:true,antialias:false,preserveDrawingBuffer:true,powerPreference:'low-power'});
      weaponPreviewRenderer.setSize(144,48,false);weaponPreviewRenderer.setPixelRatio(1);weaponPreviewRenderer.setClearColor(0x000000,0);
      weaponPreviewScene=new THREE.Scene();
      weaponPreviewScene.add(new THREE.HemisphereLight('#ffffff','#565b66',2.4));
      const keyLight=new THREE.DirectionalLight('#fff1d6',2.6);keyLight.position.set(2,4,3);weaponPreviewScene.add(keyLight);
      weaponPreviewCamera=new THREE.OrthographicCamera(-.78,.78,.26,-.26,.1,20);weaponPreviewCamera.position.set(1.35,.72,1.6);weaponPreviewCamera.lookAt(0,0,-.06);
    }
    const model=makeWeaponModel(id);model.rotation.y=.12;model.rotation.x=-.04;model.scale.setScalar(1.32);weaponPreviewScene.add(model);
    weaponPreviewRenderer.render(weaponPreviewScene,weaponPreviewCamera);const url=weaponPreviewRenderer.domElement.toDataURL('image/png');weaponPreviewScene.remove(model);
    model.traverse(o=>{if(o.isMesh){o.geometry?.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material?.dispose()}});
    weaponPreviewCache[id]=url;return url;
  }catch(error){weaponPreviewFailed=true;try{weaponPreviewRenderer?.dispose()}catch{}weaponPreviewRenderer=null;weaponPreviewScene=null;weaponPreviewCamera=null;return null}
}
function weaponHudIcon(id='pistol'){const thumbnail=weaponThumbnail(id);return thumbnail?`<img class="weapon-svg weapon-thumb" src="${thumbnail}" alt="" draggable="false">`:weaponSvgIcon(id)}
function weaponSvgIcon(id='pistol'){
 const common='<path d="M7 15h10v13H7z" fill="#9aa4b3"/><path d="M12 9h28v8H12z" fill="currentColor"/><path d="M37 10h22v6H37z" fill="#d6dde7"/>';
 const shapes={
  pistol:'<path d="M12 8h37v8H12z"/><path d="M18 16h15l-3 15H20z"/><path d="M46 10h19v4H46z"/>',
  smg:'<path d="M9 9h41v10H9z"/><path d="M46 11h28v5H46z"/><path d="M20 18h10v12H20z"/><path d="M5 11h6v6H5z"/><path d="M53 6h9v4h-9z"/>',
  rifle:'<path d="M5 10h44v8H5z"/><path d="M43 12h39v4H43z"/><path d="M23 18h12v12H23z"/><path d="M11 7h22v3H11z"/><path d="M8 18h13v5H8z"/>',
  shotgun:'<path d="M8 11h38v10H8z"/><path d="M39 9h40v4H39z"/><path d="M39 17h40v4H39z"/><path d="M19 21h12v9H19z"/><path d="M8 13h6v6H8z"/>',
  sniper:'<path d="M7 12h42v7H7z"/><path d="M44 14h45v3H44z"/><path d="M31 8h17v4H31z"/><path d="M36 8v4M43 8v4" stroke="#ffc94a" stroke-width="2"/><path d="M19 19h11v11H19z"/>',
  launcher:'<path d="M7 8h63v16H7z"/><path d="M66 6h12v20H66z"/><path d="M16 24h12v8H16z"/><path d="M4 11h4v10H4z"/>',
  melee:'<path d="M23 5h10v10H23z"/><path d="M26 15h4v18h-4z"/><path d="M14 6h28v7H14z"/>'
 };
 const shape=shapes[id]||shapes.pistol;return `<svg class="weapon-svg weapon-${id}" viewBox="0 0 96 36" aria-hidden="true"><g fill="currentColor">${shape}</g><path d="M5 33h86" stroke="#ffffff40" stroke-width="1"/></svg>`;
}
function updateWeaponHud(){
  if(!player)return;
  const w=getActiveWeapon(player),d=weaponDef(player);
  $('weapon-name').textContent=d.name;$('weapon-symbol').innerHTML=weaponHudIcon(w.id);
  $('weapon-rarity').textContent=({common:'COMUM',uncommon:'INCOMUM',rare:'RARO',legendary:'LENDÁRIO'})[d.rarity];
  $('weapon-rarity').className='rarity '+d.rarity;
  $('ammo-current').textContent=d.kind==='melee'?'∞':w.ammo;$('ammo-reserve').textContent=d.kind==='melee'?'∞':w.reserve;
  const bar=$('hotbar');
  let buttons=Array.from(bar.querySelectorAll('button[data-weapon-slot]'));
  const needsRebuild=buttons.length!==player.weaponSlots.length||buttons.some((button,i)=>button.dataset.weaponId!==player.weaponSlots[i]?.id);
  if(needsRebuild){
    bar.replaceChildren();buttons=[];
    player.weaponSlots.forEach((slot,i)=>{
      const def=WEAPONS[slot.id]||WEAPONS.pistol;
      const button=document.createElement('button');button.type='button';button.className='hotbar-slot';
      button.dataset.weaponSlot=String(i);button.dataset.weaponId=slot.id;
      button.innerHTML='<span class="slot-num"></span><span class="slot-symbol"></span><span class="slot-ammo"></span>';
      bar.append(button);buttons.push(button);
    });
  }
  buttons.forEach((button,i)=>{
    const slot=player.weaponSlots[i],def=WEAPONS[slot.id]||WEAPONS.pistol,active=i===player.activeSlot;
    button.dataset.weaponSlot=String(i);button.classList.toggle('active',active);
    button.setAttribute('aria-label',`Equipar ${def.name}, espaço ${i+1}`);
    button.setAttribute('aria-pressed',String(active));button.setAttribute('aria-current',active?'true':'false');
    button.title=`${i+1} · ${def.name}`;
    button.querySelector('.slot-num').textContent=String(i+1);
    button.querySelector('.slot-symbol').innerHTML=weaponHudIcon(slot.id);
    button.querySelector('.slot-ammo').textContent=def.kind==='melee'?'∞':String(slot.ammo);
  });
}
const hotbarElement=$('hotbar');
hotbarElement.addEventListener('pointerdown',event=>{
  const button=event.target?.closest?.('button[data-weapon-slot]');
  if(!button||!hotbarElement.contains(button)||!roundActive||!player?.alive||multiplayerActive)return;
  if(event.button!==undefined&&event.button!==0)return;
  event.preventDefault();event.stopPropagation();switchWeapon(button.dataset.weaponSlot);
});
hotbarElement.addEventListener('click',event=>{
  // Keyboard and assistive-technology activation do not always emit pointerdown.
  if(event.detail!==0)return;
  const button=event.target?.closest?.('button[data-weapon-slot]');
  if(button&&hotbarElement.contains(button)&&roundActive&&player?.alive&&!multiplayerActive)switchWeapon(button.dataset.weaponSlot);
});
function endMatch(victory){if(matchEnded)return;resetTransientInputs();matchEnded=true;roundActive=false;if(activeVehicle){activeVehicle.occupied=false;activeVehicle.speed=0;activeVehicle=null;}$('rotate-hint').classList.add('hidden');zoneRing.visible=false;fireHeld=false;touchFire=false;$('hud').classList.add('hidden');$('result-panel').classList.remove('hidden');const survived=Math.floor(matchElapsed);survivedSeconds=survived;const earned=Math.max(15,Math.floor(survived/10)+killCount*14+(victory?100:0));const xpGain=Math.max(20,Math.floor(survived/3)+killCount*35+(victory?150:0));profile.stats.matches++;if(victory)profile.stats.wins++;profile.stats.elims+=killCount;profile.stats.damage+=Math.round(damageDealt);profile.stats.survival+=survived;profile.coins+=earned;profile.stats.coinsEarned+=earned;profile.xp+=xpGain;profile.level=1+Math.floor(profile.xp/500);profile.missions.wins+=victory?1:0;profile.missions.damage+=Math.round(damageDealt);if(player?.weaponSlots.some(w=>w.id==='sniper'||w.id==='launcher'))profile.missions.weapon++;
  const position=victory?1:Math.max(2,entities.filter(e=>e.alive).length+1);$('result-title').textContent=victory?'VITÓRIA ROYALE!':'FIM DE JOGO';$('result-title').style.color=victory?'#ffc94a':'#f5f6f8';$('result-subtitle').textContent=victory?'Você sobreviveu à bagunça. Respeito.':'A arena venceu desta vez. Tente outra estratégia.';$('result-stats').innerHTML=[['POSIÇÃO',`#${position}`],['ELIMINAÇÕES',killCount],['DANO CAUSADO',Math.round(damageDealt)],['TEMPO VIVO',formatTime(survived)],['EXPERIÊNCIA',`+${xpGain} XP`],['RECOMPENSA',`+${earned} RC`]].map(([a,b])=>`<div class="result-stat"><b>${b}</b><small>${a}</small></div>`).join('');updateMissions();saveProfile();playTone(victory?700:150,.3,'triangle',.06);$('top-coins').classList.remove('hidden');$('coin-count').textContent=profile.coins;
}
function updateMissions(){
 const daily=ensureDailyMission();
 const dailyProgress=Math.min(daily.goal,Math.floor(Number(daily.progress)||0));
 const dailyDone=dailyProgress>=daily.goal;
 const remaining=formatDailyTime(Number(daily.expiresAt)-Date.now());
 $('daily-mission-card').innerHTML=`<article class="daily-mission-row ${dailyDone?'complete':''}"><div class="daily-mission-kicker">MISSÃO DIÁRIA · EXPIRA EM ${remaining}</div><div class="daily-mission-main"><div class="daily-mission-symbol">✦</div><div class="daily-mission-copy"><b>${daily.name}</b><small>${daily.desc} (${dailyProgress}/${daily.goal})</small><div class="mission-progress"><span style="width:${Math.min(100,dailyProgress/daily.goal*100)}%"></span></div></div><div class="mission-reward">${daily.claimed?'RESGATADA':dailyDone?`<button data-claim-daily type="button">RESGATAR</button>`:`${COIN} ${daily.reward}`}</div></div></article>`;
 const defs=[{id:'kills',name:'Caçador de confusão',desc:'Consiga 5 eliminações no total.',goal:5,reward:100,value:profile.missions.kills},{id:'wins',name:'No topo',desc:'Vença uma partida.',goal:1,reward:125,value:profile.missions.wins},{id:'damage',name:'Pancadaria organizada',desc:'Cause 500 de dano acumulado.',goal:500,reward:100,value:profile.missions.damage},{id:'weapon',name:'Arsenal estranho',desc:'Termine uma partida tendo usado arma lendária.',goal:1,reward:75,value:profile.missions.weapon}];
 $('missions-list').innerHTML=defs.map(m=>{const done=m.value>=m.goal,claimed=profile.claimed.includes(m.id);return `<div class="mission-row"><div style="flex:1"><b>${m.name} ${claimed?'✓':''}</b><small>${m.desc} (${Math.min(m.value,m.goal)}/${m.goal})</small><div class="mission-progress"><span style="width:${Math.min(100,m.value/m.goal*100)}%"></span></div></div><div class="mission-reward">${claimed?'RESGATADA':done?`<button data-claim="${m.id}" type="button">RESGATAR</button>`:`${COIN} ${m.reward}`}</div></div>`}).join('');
 $('daily-mission-card').querySelector('[data-claim-daily]')?.addEventListener('click',()=>{
   const current=ensureDailyMission();if(current.claimed||current.progress<current.goal)return;
   current.claimed=true;profile.coins+=current.reward;profile.stats.coinsEarned+=current.reward;dailyMissionDirty=true;saveProfile();updateMissions();playTone(820,.12,'sine');makeToast(`Missão diária concluída · +${current.reward} RC`);
 });
 $('missions-list').querySelectorAll('[data-claim]').forEach(btn=>btn.addEventListener('click',()=>{const id=btn.dataset.claim;const def=defs.find(m=>m.id===id);if(!def||profile.claimed.includes(id)||def.value<def.goal)return;profile.claimed.push(id);profile.coins+=def.reward;profile.stats.coinsEarned+=def.reward;saveProfile();updateMissions();playTone(760,.1,'sine');}));
}
function updateProfileUI(){
 $('coin-count').textContent=profile.coins;$('nickname-label').textContent=profile.nickname;$('menu-level').textContent=`NÍVEL ${profile.level}`;$('menu-wins').textContent=profile.stats.wins;$('menu-elims').textContent=profile.stats.elims;
 $('profile-user-id')?.replaceChildren(document.createTextNode(profile.userId||'—'));$('profile-nickname')?.replaceChildren(document.createTextNode(profile.nickname));$('profile-level')?.replaceChildren(document.createTextNode(String(profile.level)));$('profile-wins')?.replaceChildren(document.createTextNode(String(profile.stats.wins)));$('profile-elims')?.replaceChildren(document.createTextNode(String(profile.stats.elims)));
 setAvatarElement($('nickname-avatar'),profile.avatar);setAvatarElement($('profile-avatar-preview'),profile.avatar);setAvatarElement($('hud-profile-avatar'),profile.avatar);document.querySelectorAll('[data-profile-avatar]').forEach(item=>item.classList.toggle('selected',item.dataset.profileAvatar===profile.avatar));
 document.querySelectorAll('.coin-count').forEach(x=>x.textContent=profile.coins);
 const ownedCount=$('lobby-owned-count');if(ownedCount)ownedCount.textContent=`${profile.owned.length} ${profile.owned.length===1?'ITEM':'ITENS'}`;
 const selected=getCharacterById(profile.character)||CHARACTERS.find(c=>c.id===profile.character)||CHARACTERS[0];updateCharacterSelectionSummary(selected);
}
function openMainMenu(){$('top-coins').classList.add('menu-inline');resetTransientInputs();if(multiplayerRoom)exitCurrentMultiplayerRoom({silent:true});multiplayerActive=false;updateOnlineControlLayout();roundActive=false;$('rotate-hint').classList.add('hidden');player=null;clearMatch();if(preview)preview.visible=true;$('hud').classList.add('hidden');$('brand').classList.remove('hidden');$('main-menu').classList.remove('hidden');$('top-coins').classList.remove('hidden');$('coin-count').textContent=profile.coins;$('result-panel').classList.add('hidden');hidePanels();syncPreview();updateProfileUI();if(firstPersonRig)firstPersonRig.visible=false;applyPlatformLayout();applyCameraMode();document.exitPointerLock?.()}
function showPanel(id){document.querySelectorAll('.panel').forEach(p=>p.classList.add('hidden'));const panel=$(id);if(!panel)return;panel.classList.remove('hidden');if(id!=='pause-panel'){$('main-menu').classList.remove('hidden');$('top-coins').classList.add('menu-inline')}else{$('top-coins').classList.remove('menu-inline')}$('top-coins').classList.remove('hidden');const screen=id.replace(/-panel$/,'');if(screen==='characters'){renderCharacterSelect();const chosen=getCharacterById(selectedCharacter);if(chosen?.imported)ensureImportedCharacterLoaded(chosen.id).then(asset=>showImportModelPreview(asset,chosen)).catch(error=>setImportStatus(error?.message||'Não foi possível carregar a prévia.','error'));}if(screen==='store')renderStore();if(screen==='inventory')renderCollection();if(screen==='missions')updateMissions();if(screen==='profile')updateProfileUI();if(screen==='stats')renderStats();if(screen==='settings')syncSettings();if(screen==='pause')renderPauseRoomDetails()}
function hidePanels(){document.querySelectorAll('.panel').forEach(p=>p.classList.add('hidden'));if(!roundActive&&player===null&&preview&&$('main-menu'))preview.visible=true}
function setImportStatus(message='',type=''){
  const node=$('import-character-status');if(!node)return;
  node.textContent=String(message||'');node.className='import-status'+(type?' '+type:'');
}
function ensureImportPreviewRenderer(){
  if(importPreviewRenderer)return true;
  const canvas=$('import-preview-canvas');if(!canvas)return false;
  try{
    importPreviewRenderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:(window.devicePixelRatio||1)<=1.5,powerPreference:'low-power'});
    importPreviewRenderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.25));
    importPreviewRenderer.outputColorSpace=THREE.SRGBColorSpace;
    importPreviewScene=new THREE.Scene();importPreviewScene.background=new THREE.Color('#171c25');
    importPreviewCamera=new THREE.PerspectiveCamera(38,1,.05,80);importPreviewCamera.position.set(0,1.55,5.8);importPreviewCamera.lookAt(0,1.2,0);
    importPreviewScene.add(new THREE.HemisphereLight('#dcecff','#47505e',2.2));
    const key=new THREE.DirectionalLight('#fff0d8',2.6);key.position.set(-3,6,4);importPreviewScene.add(key);
    const rim=new THREE.DirectionalLight('#78b9ff',1.15);rim.position.set(4,3,-3);importPreviewScene.add(rim);
    const floor=new THREE.Mesh(new THREE.CircleGeometry(1.5,36),new THREE.MeshStandardMaterial({color:'#343a46',roughness:.94,metalness:.02}));floor.rotation.x=-Math.PI/2;floor.position.y=.002;importPreviewScene.add(floor);
    const gridPreview=new THREE.GridHelper(3.5,14,'#647080','#343b48');gridPreview.position.y=.008;importPreviewScene.add(gridPreview);
    return true;
  }catch(error){
    console.error('Falha ao criar a prévia 3D:',error);importPreviewRenderer=null;importPreviewScene=null;importPreviewCamera=null;
    setImportStatus('A prévia 3D não pôde ser aberta neste dispositivo. O jogo continuará funcionando; confira suporte a WebGL e memória disponível.','error');return false;
  }
}
function clearImportModelPreview({hide=true}={}){
  if(importPreviewMixer){try{importPreviewMixer.stopAllAction();if(importPreviewMixerRoot)importPreviewMixer.uncacheRoot(importPreviewMixerRoot)}catch{}}
  importPreviewMixer=null;importPreviewAction=null;importPreviewMixerRoot=null;
  if(importPreviewObject&&importPreviewScene)importPreviewScene.remove(importPreviewObject);
  importPreviewObject=null;importPreviewYaw=0;importPreviewPointer=null;
  if(hide)$('import-preview-pane')?.classList.add('hidden');
}
function showImportModelPreview(asset,meta={}){
  if(!asset?.scene)return;
  if(!ensureImportPreviewRenderer())return;
  clearImportModelPreview({hide:false});
  try{
    const facingOffset=Number.isFinite(Number(meta.facingOffset))?Number(meta.facingOffset):(pendingCharacterImport?.asset===asset?pendingCharacterImport.facingOffset:Math.PI);
    const normalized=createNormalizedImportedModel(asset,facingOffset);
    importPreviewObject=new THREE.Group();importPreviewObject.add(normalized.container);importPreviewMixerRoot=normalized.modelRoot;
    importPreviewObject.rotation.y=importPreviewYaw;
    importPreviewScene.add(importPreviewObject);
    if(asset.animations?.length){
      importPreviewMixer=new THREE.AnimationMixer(normalized.modelRoot);
      const preferred=asset.animations.find(clip=>classifyAnimationName(clip.name||'')==='idle')
        ||asset.animations.find(clip=>classifyAnimationName(clip.name||'')==='hold');
      if(preferred){importPreviewAction=importPreviewMixer.clipAction(preferred);importPreviewAction.play();}
    }
    $('import-preview-pane')?.classList.remove('hidden');
    $('import-preview-title').textContent=`PRÉVIA 3D · ${String(meta.name||'PERSONAGEM').slice(0,28).toLocaleUpperCase()}`;
    if(meta.name&&$('import-character-name'))$('import-character-name').value=String(meta.name).slice(0,32);
    updateImportFacingButton(facingOffset);
    resizeImportPreviewRenderer();
  }catch(error){console.warn('Não foi possível montar a prévia 3D:',error);setImportStatus(`O modelo foi lido, mas a prévia falhou: ${error?.message||error}`,'error');clearImportModelPreview({hide:false});}
}
function resizeImportPreviewRenderer(){
  if(!importPreviewRenderer||!importPreviewCamera)return;
  const canvas=$('import-preview-canvas');if(!canvas)return;
  const rect=canvas.getBoundingClientRect();if(rect.width<2||rect.height<2)return;
  const width=Math.round(rect.width),height=Math.round(rect.height);
  if(canvas.width!==Math.round(width*importPreviewRenderer.getPixelRatio())||canvas.height!==Math.round(height*importPreviewRenderer.getPixelRatio()))importPreviewRenderer.setSize(width,height,false);
  importPreviewCamera.aspect=width/height;importPreviewCamera.updateProjectionMatrix();
}
function renderImportModelPreview(dt){
  if(!importPreviewRenderer||!importPreviewScene||!importPreviewObject||$('import-preview-pane')?.classList.contains('hidden'))return;
  resizeImportPreviewRenderer();
  if(importPreviewMixer)importPreviewMixer.update(dt);
  if(!importPreviewPointer)importPreviewObject.rotation.y+=dt*.18;
  try{importPreviewRenderer.render(importPreviewScene,importPreviewCamera)}catch(error){console.warn('Falha ao renderizar a prévia 3D:',error);}
}
function clearPendingImport({dispose=true,hidePreview=true}={}){
  const pending=pendingCharacterImport;pendingCharacterImport=null;
  $('import-rig-confirm')?.classList.add('hidden');$('import-rig-limit')?.classList.add('hidden');$('import-save-actions')?.classList.add('hidden');
  if(hidePreview)clearImportModelPreview({hide:true});
  if(dispose&&pending?.asset?.scene&&!importedModelCacheHasAsset(pending.asset))disposeThreeObject(pending.asset.scene);
  const input=$('import-character-file');if(input)input.value='';
}
function importedModelCacheHasAsset(asset){for(const cached of importedModelCache.values())if(cached===asset)return true;return false;}
function renderImportedCharacterManager(){
  const host=$('imported-character-manager');if(!host)return;
  const records=[...importedCharacterMetadata.values()];
  if(!records.length){host.replaceChildren();return;}
  host.innerHTML='<div class="imported-manager-heading">PERSONAGENS IMPORTADOS · ARMAZENAMENTO LOCAL</div>'+records.map(meta=>{
    const state=meta.rig?.hasRig?(meta.rig?.humanoid?'rig humanoide':'rig detectado; compatibilidade incerta'):'sem rig · estático';
    return `<div class="imported-manager-row"><div><b>${escapeImportText(meta.name)}</b><small>${escapeImportText(meta.format||'GLB')} · ${escapeImportText(state)} · ${escapeImportText(meta.rig?.animationCount||0)} animação(ões)</small></div><button type="button" data-remove-import="${escapeImportText(meta.id)}" aria-label="Remover ${escapeImportText(meta.name)}">REMOVER</button></div>`;
  }).join('');
  host.querySelectorAll('[data-remove-import]').forEach(button=>button.addEventListener('click',async()=>{
    const id=button.dataset.removeImport,meta=importedCharacterMetadata.get(id);if(!meta)return;
    if(!window.confirm(`Remover “${meta.name}” e os arquivos 3D guardados neste dispositivo? Esta ação não pode ser desfeita.`))return;
    button.disabled=true;
    try{
      if(profile.character===`imported:${id}`){profile.character='enzo';saveProfile();}
      const wasSelected=selectedCharacter===`imported:${id}`;if(wasSelected)selectedCharacter=profile.character;
      if(wasSelected||(importPreviewObject&&$('import-preview-title')?.textContent.includes(String(meta.name).slice(0,20).toLocaleUpperCase())))clearImportModelPreview({hide:true});
      await removeImportedCharacter(id);
      const cached=importedModelCache.get(id);importedModelCache.delete(id);
      if(cached?.scene)disposeThreeObject(cached.scene);
      importedCharacterMetadata.delete(id);syncPreview();renderCharacterSelect();
      setImportStatus(`Personagem “${meta.name}” removido do armazenamento local.`,'success');
    }catch(error){button.disabled=false;setImportStatus(error?.message||'Não foi possível remover o personagem.','error');}
  }));
}
function updateCharacterSelectionSummary(character=getCharacterById(selectedCharacter)){
  const name=$('character-selected-name'),desc=$('character-selected-description'),state=$('character-selected-state');
  if(name)name.textContent=character?.name||'ENZO';
  if(desc)desc.textContent=character?.desc||(character?.imported?'Modelo 3D importado':'Personagem selecionado');
  if(state){const locked=!!character?.unlockCode&&!profile.unlockedCharacters.includes(character.id);state.textContent=locked?'BLOQUEADO':character?.imported?(character.rig?.hasRig?'RIG DETECTADO':'MODELO ESTÁTICO'):'DISPONÍVEL';state.classList.toggle('locked',locked);}
  const menuName=$('menu-selected-character');if(menuName)menuName.textContent=(character?.name||'ENZO').toLocaleUpperCase();
  const menuStatus=$('menu-character-status');if(menuStatus)menuStatus.textContent=character?.imported?(character.rig?.hasRig?'PERSONAGEM PERSONALIZADO · COM RIG':'PERSONAGEM PERSONALIZADO · ESTÁTICO'):'PRONTO PARA A ARENA';
}
function renderCharacterSelect(){
  const g=$('character-grid');
  const imported=[...importedCharacterMetadata.values()].map(importedCharacterData).filter(Boolean);
  const all=[...CHARACTERS,...imported];
  const unlockedAll=all.filter(c=>!c.unlockCode||profile.unlockedCharacters.includes(c.id));
  if(!unlockedAll.some(c=>c.id===selectedCharacter))selectedCharacter=unlockedAll.find(c=>c.id===profile.character)?.id||profile.character||'enzo';
  g.innerHTML=all.map(c=>{
    const locked=!!c.unlockCode&&!profile.unlockedCharacters.includes(c.id);
    if(c.imported){
      const isSelected=selectedCharacter===c.id;
      const rigText=c.rig?.hasRig?(c.rig?.humanoid?'RIG HUMANOIDE':'RIG DETECTADO'):'MODELO ESTÁTICO';
      return `<button class="character-card ${isSelected?'selected':''}" data-character="${escapeImportText(c.id)}"><div class="character-art" data-character-art="${escapeImportText(c.id)}"><span class="imported-card-icon">3D</span></div><b>${escapeImportText(c.name)}</b><small>${escapeImportText(rigText)} · ${escapeImportText(c.rig?.animationCount||0)} animação(ões)</small>${isSelected?'<span class="chosen-mark">✓</span>':''}</button>`;
    }
    const visual=c.id==='custom'?{...c,...profile.customAppearance}:c;
    if(locked)return `<button class="character-card character-locked" data-character="${c.id}" data-locked="true" type="button"><div class="character-art" data-character-art="${c.id}"><span class="char-legs" style="background:${visual.pants}"></span><span class="char-body" style="background:${visual.shirt}"></span><span class="char-head" style="background:${c.skin}"></span><span class="char-hair" style="background:${visual.hair}"></span><span class="character-lock-mark">🔒</span></div><b>${c.name}</b><small>Bloqueado · Resgate com ${escapeImportText(c.unlockCode||'um código')}</small></button>`;
    return `<button class="character-card ${selectedCharacter===c.id?'selected':''}" data-character="${c.id}"><div class="character-art" data-character-art="${c.id}"><span class="char-legs" style="background:${visual.pants}"></span><span class="char-body" style="background:${visual.shirt}"></span><span class="char-head" style="background:${c.skin}"></span><span class="char-hair" style="background:${visual.hair}"></span></div><b>${c.name}</b><small>${c.desc}</small>${selectedCharacter===c.id?'<span class="chosen-mark">✓</span>':''}</button>`;
  }).join('');
  $('customizer').classList.toggle('hidden',selectedCharacter!=='custom');$('custom-hair').value=profile.customAppearance.hair;$('custom-shirt').value=profile.customAppearance.shirt;$('custom-pants').value=profile.customAppearance.pants;
  g.querySelectorAll('[data-character]').forEach(btn=>btn.addEventListener('click',async()=>{
    if(btn.dataset.locked==='true'){const locked=CHARACTERS.find(c=>c.id===btn.dataset.character);makeToast(locked?.unlockCode?`Resgate ${locked.unlockCode} para desbloquear`:'Personagem bloqueado');updateCharacterSelectionSummary(locked);return;}
    selectedCharacter=btn.dataset.character;renderCharacterSelect();const data=getCharacterById(selectedCharacter);
    if(data?.imported){
      setImportStatus(`Carregando ${data.name} da biblioteca local…`,'loading');
      try{const asset=await ensureImportedCharacterLoaded(selectedCharacter);showImportModelPreview(asset,data);setImportStatus(`${data.name} pronto. Clique em “USAR PERSONAGEM” para selecioná-lo.`,'success');}
      catch(error){setImportStatus(error?.message||'Não foi possível carregar esse personagem.','error');}
    }else if(!pendingCharacterImport){clearImportModelPreview({hide:true});}
    if(preview){world.remove(preview);for(let i=shootables.length-1;i>=0;i--)if(shootables[i].userData.preview)shootables.splice(i,1);}
    if(data&&!data.imported){preview=makeCharacter(data);preview.position.set(0,0,3);preview.userData.preview=true;preview.traverse(o=>{if(o.isMesh){o.userData.preview=true;o.castShadow=false;const i=shootables.indexOf(o);if(i>=0)shootables.splice(i,1)}});world.add(preview);playTone(320,.04,'sine',.02);}
  }));
  renderImportedCharacterManager();
  const selected=getCharacterById(selectedCharacter);
  updateCharacterSelectionSummary(selected);
}
async function beginImportSelectedFiles(fileList){
  const files=Array.from(fileList||[]);
  clearPendingImport({dispose:true,hidePreview:true});
  const mainCandidates=files.filter(file=>['.glb','.gltf'].includes(file.name.slice(file.name.lastIndexOf('.')).toLowerCase()));
  if(mainCandidates.length!==1){setImportStatus('Selecione exatamente um arquivo principal .glb ou .gltf. Para .gltf, inclua também as dependências na mesma seleção.','error');return;}
  const main=mainCandidates[0];setImportStatus(`Validando e carregando ${main.name}…`,'loading');
  const openButton=$('import-character-open');if(openButton)openButton.disabled=true;
  try{
    const asset=await parseCharacterFiles(files,main.name,THREE);
    pendingCharacterImport={files,mainName:main.name,asset,staticRequested:false,facingOffset:Math.PI};
    const baseName=main.name.replace(/\.(glb|gltf)$/i,'').slice(0,32);
    $('import-character-name').value=baseName||'Meu personagem';
    $('import-save-actions').classList.add('hidden');$('import-rig-limit').classList.add('hidden');
    showImportModelPreview(asset,{name:baseName||'Meu personagem'});
    const rig=asset.rig;
    if(!rig.hasRig){
      $('import-rig-confirm').classList.remove('hidden');
      $('import-rig-auto').disabled=!rig.appearsHumanoid;
      $('import-rig-auto').textContent=rig.appearsHumanoid?'ADICIONAR RIG AUTOMÁTICO':'RIG AUTOMÁTICO NÃO INDICADO';
      const rigText=$('import-rig-confirm').querySelector('p');
      rigText.textContent=rig.appearsHumanoid
        ?'Este personagem não possui um rig utilizável para animações. Deseja tentar criar um rig automaticamente? O resultado depende da geometria do modelo e pode causar deformações.'
        :'Não foi detectado rig. A forma do modelo não parece claramente humanoide; não será tentada uma rigagem humana automática. Você ainda pode importá-lo sem rig ou cancelar.';
      setImportStatus(`Modelo carregado: ${asset.complexity.meshes} malha(s), ${asset.complexity.vertices.toLocaleString('pt-BR')} vértices. Nenhum arquivo foi enviado para outro servidor. Escolha uma opção para continuar.`,'success');
    }else{
      $('import-rig-confirm').classList.add('hidden');$('import-save-actions').classList.remove('hidden');
      setImportStatus(`Modelo validado: ${rig.boneCount} ossos, ${rig.skinnedMeshCount} malha(s) com pesos e ${rig.animationCount} clipe(s). ${rig.humanoid?'Rig humanoide reconhecível.':'O rig existe, mas não foi possível confirmar que seja humanoide; só serão usadas animações que coincidam com os nomes/estrutura.'}`,'success');
    }
  }catch(error){
    console.error('Importação 3D falhou:',error);setImportStatus(error?.message||'Não foi possível abrir este arquivo.','error');
    $('import-rig-confirm')?.classList.add('hidden');$('import-rig-limit')?.classList.add('hidden');$('import-save-actions')?.classList.add('hidden');
  }finally{if(openButton)openButton.disabled=false;}
}
async function savePendingCharacterImport(forceStatic=false){
  const pending=pendingCharacterImport;if(!pending)return;
  const name=String($('import-character-name').value||'').trim().replace(/\s+/g,' ').slice(0,32);
  if(!name){setImportStatus('Digite um nome para este personagem.','error');$('import-character-name').focus();return;}
  const button=$('import-character-confirm');if(button)button.disabled=true;
  setImportStatus('Salvando arquivos 3D no IndexedDB deste dispositivo…','loading');
  try{
    const id=globalThis.crypto?.randomUUID?.()||`rr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`;
    const rig={...pending.asset.rig};
    const meta={id,name,format:pending.asset.format,mainName:pending.mainName,createdAt:new Date().toISOString(),rig,facingOffset:pending.facingOffset??Math.PI,animationMode:(forceStatic||pending.staticRequested||!rig.hasRig)?'static':'compatible-clips',fileCount:pending.files.length,totalBytes:pending.files.reduce((sum,file)=>sum+file.size,0)};
    await saveImportedCharacter(meta,pending.files);
    importedCharacterMetadata.set(id,meta);importedModelCache.set(id,{...pending.asset,rig,animations:meta.animationMode==='static'?[]:pending.asset.animations});
    pendingCharacterImport=null;$('import-rig-confirm').classList.add('hidden');$('import-rig-limit').classList.add('hidden');$('import-save-actions').classList.add('hidden');
    selectedCharacter=`imported:${id}`;
    renderCharacterSelect();showImportModelPreview(importedModelCache.get(id),meta);
    setImportStatus(`“${name}” foi importado e salvo localmente. Selecione “USAR PERSONAGEM” para escolhê-lo; os arquivos não foram enviados à internet.`,'success');
    $('import-character-file').value='';
    // The parsed asset is now the cache owner; do not dispose it when clearing pending state.
    if(button)button.disabled=false;
  }catch(error){
    console.error('Falha ao salvar personagem:',error);setImportStatus(error?.message||'Não foi possível guardar este personagem. Confira o espaço livre do navegador.','error');if(button)button.disabled=false;
  }
}
function cancelImportFlow(){clearPendingImport({dispose:true,hidePreview:true});setImportStatus('Importação cancelada. Nenhum personagem foi adicionado.');}
function updateImportFacingButton(offset){
  const button=$('import-facing-toggle');if(!button)return;
  const corrected=Math.abs(Math.sin((Number(offset)||0)/2))>.7;
  button.textContent=corrected?'DIREÇÃO CORRIGIDA · TROCAR 180°':'CORRIGIR DIREÇÃO · GIRAR 180°';
  button.setAttribute('aria-pressed',String(corrected));
}
async function toggleImportedFacing(){
  if(pendingCharacterImport){
    pendingCharacterImport.facingOffset=Math.abs(Number(pendingCharacterImport.facingOffset)||0)>.1?0:Math.PI;
    const pending=pendingCharacterImport;
    showImportModelPreview(pending.asset,{name:$('import-character-name').value||pending.mainName,facingOffset:pending.facingOffset});
    setImportStatus(pending.facingOffset?'Direção corrigida em 180°. Você poderá alternar novamente se o modelo ainda estiver de costas.':'Orientação original do arquivo restaurada.','success');
    return;
  }
  const id=String(selectedCharacter||'').startsWith('imported:')?String(selectedCharacter).slice('imported:'.length):'';
  const meta=importedCharacterMetadata.get(id);if(!meta){setImportStatus('Selecione um personagem importado para ajustar a direção.','error');return;}
  const current=Number.isFinite(Number(meta.facingOffset))?Number(meta.facingOffset):Math.PI;
  meta.facingOffset=Math.abs(current)>.1?0:Math.PI;
  try{
    await updateImportedCharacterMetadata(meta);importedCharacterMetadata.set(id,meta);
    if(profile.character===`imported:${id}`)syncPreview();
    const asset=await ensureImportedCharacterLoaded(`imported:${id}`);
    showImportModelPreview(asset,importedCharacterData(meta));
    setImportStatus(`Orientação de “${meta.name}” salva: ${meta.facingOffset?'correção de 180°':'orientação original'}.`,'success');
  }catch(error){setImportStatus(error?.message||'Não foi possível salvar a orientação do personagem.','error');}
}
function bindCharacterImportUI(){
  $('import-character-open')?.addEventListener('click',()=>{$('import-character-file').click()});
  $('import-facing-toggle')?.addEventListener('click',toggleImportedFacing);
  $('import-character-file')?.addEventListener('change',event=>beginImportSelectedFiles(event.target.files));
  $('import-rig-auto')?.addEventListener('click',()=>{
    if(!pendingCharacterImport)return;
    if(!pendingCharacterImport.asset.rig.appearsHumanoid){setImportStatus('Não será aplicado rig humanoide a este objeto. Importe sem rig ou cancele.','error');return;}
    $('import-rig-confirm').classList.add('hidden');$('import-rig-limit').classList.remove('hidden');
    setImportStatus('Auto-rigging não executado: não há motor confiável integrado localmente neste projeto. Nenhum dado foi enviado para fora do dispositivo.','error');
  });
  $('import-rig-static')?.addEventListener('click',()=>{if(!pendingCharacterImport)return;pendingCharacterImport.staticRequested=true;$('import-rig-confirm').classList.add('hidden');$('import-save-actions').classList.remove('hidden');setImportStatus('O modelo será adicionado como estático, sem inventar ossos ou deformações.','success');});
  $('import-rig-limit-static')?.addEventListener('click',()=>{if(!pendingCharacterImport)return;pendingCharacterImport.staticRequested=true;$('import-rig-limit').classList.add('hidden');$('import-save-actions').classList.remove('hidden');setImportStatus('Importação estática selecionada.','success');});
  $('import-rig-cancel')?.addEventListener('click',cancelImportFlow);$('import-rig-limit-cancel')?.addEventListener('click',cancelImportFlow);$('import-character-cancel')?.addEventListener('click',cancelImportFlow);
  $('import-character-confirm')?.addEventListener('click',()=>savePendingCharacterImport(false));
  const canvas=$('import-preview-canvas');
  canvas?.addEventListener('pointerdown',event=>{if(!importPreviewObject)return;importPreviewPointer={x:event.clientX,y:event.clientY};canvas.setPointerCapture?.(event.pointerId);});
  canvas?.addEventListener('pointermove',event=>{if(!importPreviewPointer||!importPreviewObject)return;const dx=event.clientX-importPreviewPointer.x,dy=event.clientY-importPreviewPointer.y;importPreviewPointer={x:event.clientX,y:event.clientY};importPreviewObject.rotation.y+=dx*.012;importPreviewObject.rotation.x=clamp(importPreviewObject.rotation.x+dy*.004,-.25,.25);});
  const endDrag=()=>{importPreviewPointer=null};canvas?.addEventListener('pointerup',endDrag);canvas?.addEventListener('pointercancel',endDrag);window.addEventListener('resize',resizeImportPreviewRenderer);
}
function syncPreview(){
  if(preview){world.remove(preview);for(let i=shootables.length-1;i>=0;i--)if(shootables[i].userData.preview)shootables.splice(i,1);}
  const data=getCharacterById(profile.character)||CHARACTERS[0];
  try{preview=makeCharacter(data);}catch(error){console.warn('Não foi possível montar a prévia do personagem selecionado:',error);preview=makeCharacter(CHARACTERS[0]);}
  preview.position.set(0,0,3);preview.userData.preview=true;
  preview.traverse(o=>{if(o.isMesh||o.isSkinnedMesh){o.userData.preview=true;o.castShadow=false;const i=shootables.indexOf(o);if(i>=0)shootables.splice(i,1)}});world.add(preview);
}
function getVisibleShopItems(){
  return storeFilter==='featured'
    ? SHOP_ITEMS.filter(item=>['free-sticker','neon','crown'].includes(item.id))
    : SHOP_ITEMS.slice();
}
function selectStoreItem(id){
  const item=SHOP_ITEMS.find(candidate=>candidate.id===id);if(!item)return;
  selectedStoreItemId=item.id;
  const detail=$('store-item-detail');detail?.classList.remove('hidden');
  $('store-detail-icon').textContent=item.icon;$('store-detail-name').textContent=item.name;$('store-detail-desc').textContent=item.desc;
  const owned=profile.owned.includes(item.id);
  $('store-detail-price').textContent=owned?'JÁ NA COLEÇÃO':item.price===0?'GRÁTIS':`${COIN} ${item.price}`;
  $('store-detail-state').textContent=owned?'DESBLOQUEADO':item.price===0?'DISPONÍVEL PARA RESGATE':'COSMÉTICO';
  const buy=$('store-detail-buy');buy.disabled=owned;buy.textContent=owned?'DESBLOQUEADO':item.price===0?'RESGATAR':'COMPRAR';
  $('store-grid')?.querySelectorAll('[data-store-id]').forEach(card=>card.classList.toggle('selected',card.dataset.storeId===item.id));
}
function openStorePurchase(id){
  const item=SHOP_ITEMS.find(candidate=>candidate.id===id);if(!item)return;
  if(profile.owned.includes(item.id)){makeToast('Este item já está na sua coleção');return;}
  if(profile.coins<item.price){makeToast('Royale Coins insuficientes');return;}
  pendingStorePurchaseId=item.id;
  $('store-confirm-title').textContent=item.price===0?'Resgatar item grátis?':'Confirmar compra?';
  $('store-confirm-description').textContent=`${item.name} — ${item.desc} ${item.price===0?'O item será adicionado à sua coleção.':`O custo é de ${item.price} Royale Coins.`}`;
  $('store-confirm-balance').textContent=`${COIN} ${profile.coins}`;
  $('store-confirm-accept').textContent=item.price===0?'RESGATAR':'CONFIRMAR COMPRA';
  const dialog=$('store-purchase-dialog');dialog.classList.remove('hidden');dialog.setAttribute('aria-hidden','false');
  $('store-confirm-cancel').focus();
}
function closeStorePurchase(){
  pendingStorePurchaseId=null;const dialog=$('store-purchase-dialog');dialog?.classList.add('hidden');dialog?.setAttribute('aria-hidden','true');
}
function confirmStorePurchase(){
  const item=SHOP_ITEMS.find(candidate=>candidate.id===pendingStorePurchaseId);
  if(!item){closeStorePurchase();return;}
  // Revalidate at confirmation time to avoid double clicks or a stale balance.
  if(profile.owned.includes(item.id)){closeStorePurchase();renderStore();makeToast('Este item já está na sua coleção');return;}
  if(profile.coins<item.price){closeStorePurchase();makeToast('Royale Coins insuficientes');return;}
  profile.coins-=item.price;profile.owned.push(item.id);saveProfile();closeStorePurchase();updateProfileUI();renderStore();renderCollection();playTone(680,.1,'sine');makeToast(item.price===0?'Item adicionado à coleção':`${item.name} comprado!`);
}
function renderStore(){
 const g=$('store-grid');if(!g)return;
 const visible=getVisibleShopItems();
 if(!visible.some(item=>item.id===selectedStoreItemId))selectedStoreItemId=visible[0]?.id||SHOP_ITEMS[0]?.id;
 document.querySelectorAll('[data-store-filter]').forEach(button=>{const selected=button.dataset.storeFilter===storeFilter;button.classList.toggle('selected',selected);button.setAttribute('aria-selected',String(selected));});
 g.innerHTML=visible.map(item=>{
   const owned=profile.owned.includes(item.id);
   const price=owned?'NA COLEÇÃO':item.price===0?'GRÁTIS':`${COIN} ${item.price}`;
   return `<article class="store-item ${selectedStoreItemId===item.id?'selected':''}" data-store-id="${item.id}"><button class="store-item-select" data-preview-store="${item.id}" type="button" aria-label="Ver detalhes de ${escapeImportText(item.name)}"><span class="store-visual" aria-hidden="true">${item.icon}</span><span class="store-item-title">${escapeImportText(item.name)}</span><span class="store-item-description">${escapeImportText(item.desc)}</span><span class="store-item-meta"><span>${owned?'DESBLOQUEADO':'COSMÉTICO'}</span><strong>${price}</strong></span></button><button data-buy="${item.id}" class="${owned?'owned':''}" ${owned?'disabled':''} type="button">${owned?'✓ DESBLOQUEADO':item.price===0?'RESGATAR GRÁTIS':'VER COMPRA'}</button></article>`;
 }).join('');
 g.querySelectorAll('[data-preview-store]').forEach(btn=>btn.addEventListener('click',()=>selectStoreItem(btn.dataset.previewStore)));
 g.querySelectorAll('[data-buy]').forEach(btn=>btn.addEventListener('click',()=>{selectStoreItem(btn.dataset.buy);openStorePurchase(btn.dataset.buy)}));
 selectStoreItem(selectedStoreItemId);
}
function setInventoryTab(tab){
  document.querySelectorAll('[data-inventory-tab]').forEach(button=>{const selected=button.dataset.inventoryTab===tab;button.classList.toggle('selected',selected);button.setAttribute('aria-selected',String(selected));});
  document.querySelectorAll('[data-inventory-section]').forEach(section=>section.classList.toggle('hidden',section.dataset.inventorySection!==tab));
}
function renderCollection(){
 const g=$('collection-list');
 g.innerHTML=profile.owned.length?profile.owned.map(id=>{const item=SHOP_ITEMS.find(i=>i.id===id);const equipable=['neon','crown','trail'].includes(id);const equipped=profile.equipped.includes(id);return `<div class="collection-row"><div class="collection-icon">${item?.icon||'✦'}</div><div style="flex:1"><b>${item?.name||id}</b><small>${equipable?'Acessório visual • sem vantagem competitiva':id==='free-sticker'?'Item de coleção':'Desbloqueado na coleção; efeito em atualização'}</small></div>${equipable?`<button data-equip="${id}" style="padding:8px 10px;background:${equipped?'#255640':'#353a47'};font-size:9px;font-weight:900">${equipped?'EQUIPADO':'EQUIPAR'}</button>`:'<span class="owned-tag">DESBLOQUEADO</span>'}</div>`}).join(''):'<p class="subline">Sua coleção ainda está vazia. Visite a loja!</p>';
 g.querySelectorAll('[data-equip]').forEach(btn=>btn.addEventListener('click',()=>{const id=btn.dataset.equip;if(profile.equipped.includes(id))profile.equipped=profile.equipped.filter(x=>x!==id);else profile.equipped.push(id);saveProfile();renderCollection();syncPreview();playTone(500,.05,'sine')}));
 const armorGallery=$('armor-collection');
 if(armorGallery)armorGallery.innerHTML=Object.values(ARMOR_ITEMS).map(a=>`<article class="weapon-gallery-item armor-gallery-item"><div class="weapon-gallery-visual armor-visual" style="--armor-color:${a.color}"><span>${a.icon}</span></div><b>${a.name}</b><small class="weapon-gallery-rarity ${a.rarity}">${({common:'COMUM',uncommon:'INCOMUM',rare:'RARO',legendary:'LENDÁRIO'})[a.rarity]}</small><p>${a.desc}</p><div class="weapon-gallery-stats">ESCUDO MÁXIMO <strong>+${a.shield}</strong></div></article>`).join('');
 const armorStatus=$('armor-loadout-status');
 if(armorStatus){const equipped=player?.armor?ARMOR_SLOTS.map(slot=>{const a=ARMOR_ITEMS[player.armor[slot]];return a?`${ARMOR_SLOT_LABELS[slot]}: ${a.name} (+${a.shield})`:null}).filter(Boolean):[];armorStatus.textContent=equipped.length?`Armadura atual: ${equipped.join(' • ')}. Bônus de escudo: +${Math.max(0,(player?.maxShield||100)-100)}.`:'Armaduras são equipamentos encontrados no mapa. Cada peça coletada aumenta o escudo máximo e aparece visualmente no personagem.';}
 const arsenal=$('weapon-collection');
 if(arsenal)arsenal.innerHTML=Object.values(WEAPONS).map(w=>`<article class="weapon-gallery-item"><div class="weapon-gallery-visual">${weaponHudIcon(w.id)}</div><b>${w.name}</b><small class="weapon-gallery-rarity ${w.rarity}">${({common:'COMUM',uncommon:'INCOMUM',rare:'RARO',legendary:'LENDÁRIO'})[w.rarity]}</small><p>${w.desc}</p><div class="weapon-gallery-stats">DANO <strong>${w.damage}</strong> · ALCANCE <strong>${w.range}</strong></div></article>`).join('');
}
function renderStats(){const s=profile.stats;$('stats-grid').innerHTML=[['PARTIDAS',s.matches],['VITÓRIAS',s.wins],['ELIMINAÇÕES',s.elims],['DANO CAUSADO',s.damage],['SOBREVIVÊNCIA',formatTime(s.survival)],['MOEDAS GANHAS',s.coinsEarned],['NÍVEL',profile.level],['XP TOTAL',profile.xp],['ITENS',profile.owned.length]].map(([a,b])=>`<div class="stat-box"><strong>${b}</strong><small>${a}</small></div>`).join('')}
function effectivePlatform(){if(platformMode==='mobile'||platformMode==='computer')return platformMode;return window.matchMedia('(pointer:coarse)').matches?'mobile':'computer'}
const MOBILE_CONTROL_IDS=Object.keys(DEFAULT_MOBILE_CONTROL_LAYOUT);
function clampMobileControl(control){
  return {x:clamp(Number(control?.x)||0,4,96),y:clamp(Number(control?.y)||0,6,94),size:clamp(Number(control?.size)||48,36,130),opacity:clamp(Number(control?.opacity)||0,20,100)};
}
function currentMobileControlLayout(){
  profile.settings.mobileControls=profile.settings.mobileControls||{};
  for(const [id,defaults] of Object.entries(DEFAULT_MOBILE_CONTROL_LAYOUT))profile.settings.mobileControls[id]={...defaults,...(profile.settings.mobileControls[id]||{})};
  return profile.settings.mobileControls;
}
function applyMobileControlLayout(){
  const layout=currentMobileControlLayout();
  for(const id of MOBILE_CONTROL_IDS){
    const element=$(id);if(!element)continue;const c=clampMobileControl(layout[id]);
    element.style.setProperty('--rr-touch-x',`${c.x}%`);element.style.setProperty('--rr-touch-y',`${c.y}%`);
    element.style.setProperty('--rr-touch-size',`${c.size}px`);element.style.setProperty('--rr-touch-opacity',String(c.opacity/100));
    if(id==='touch-stick')element.style.setProperty('--rr-stick-knob-size',`${clamp(c.size*.37,24,48)}px`);
  }
}
function renderMobileControlPreview(){
  const layout=currentMobileControlLayout(),host=$('mobile-control-preview');if(!host)return;
  host.querySelectorAll('[data-layout-control]').forEach(button=>{
    const id=button.dataset.layoutControl,c=clampMobileControl(layout[id]);
    button.style.left=`${c.x}%`;button.style.top=`${c.y}%`;
    const visualSize=clamp(c.size*.48,24,64);button.style.width=`${visualSize}px`;button.style.height=`${visualSize}px`;
    button.style.opacity=String(c.opacity/100);button.classList.toggle('selected',id===$('mobile-control-target')?.value);
  });
}
function syncMobileControlEditor(){
  const id=$('mobile-control-target')?.value||'touch-fire',c=clampMobileControl(currentMobileControlLayout()[id]);
  if($('mobile-control-x'))$('mobile-control-x').value=c.x;if($('mobile-control-x-value'))$('mobile-control-x-value').textContent=`${c.x}%`;
  if($('mobile-control-y'))$('mobile-control-y').value=c.y;if($('mobile-control-y-value'))$('mobile-control-y-value').textContent=`${c.y}%`;
  if($('mobile-control-size'))$('mobile-control-size').value=c.size;if($('mobile-control-size-value'))$('mobile-control-size-value').textContent=`${c.size}px`;
  if($('mobile-control-opacity'))$('mobile-control-opacity').value=c.opacity;if($('mobile-control-opacity-value'))$('mobile-control-opacity-value').textContent=`${c.opacity}%`;
  renderMobileControlPreview();
}
function changeSelectedMobileControl(field,value){
  const id=$('mobile-control-target')?.value||'touch-fire',layout=currentMobileControlLayout();
  layout[id]=clampMobileControl({...layout[id],[field]:Number(value)});
  profile.settings.mobileControls=layout;applyMobileControlLayout();syncMobileControlEditor();
}
function bindMobileControlEditor(){
  $('mobile-control-target')?.addEventListener('change',syncMobileControlEditor);
  for(const [id,field] of [['mobile-control-x','x'],['mobile-control-y','y'],['mobile-control-size','size'],['mobile-control-opacity','opacity']])$(id)?.addEventListener('input',event=>changeSelectedMobileControl(field,event.target.value));
  $('mobile-control-reset')?.addEventListener('click',()=>{profile.settings.mobileControls=Object.fromEntries(Object.entries(DEFAULT_MOBILE_CONTROL_LAYOUT).map(([id,c])=>[id,{...c}]));applyMobileControlLayout();syncMobileControlEditor();});
  const host=$('mobile-control-preview');if(!host)return;
  let drag=null;
  host.querySelectorAll('[data-layout-control]').forEach(button=>button.addEventListener('pointerdown',event=>{
    event.preventDefault();event.stopPropagation();drag={id:button.dataset.layoutControl,pointerId:event.pointerId};$('mobile-control-target').value=drag.id;syncMobileControlEditor();
    try{button.setPointerCapture(event.pointerId)}catch{}button.classList.add('dragging');
  }));
  host.addEventListener('pointermove',event=>{
    if(!drag||drag.pointerId!==event.pointerId)return;event.preventDefault();
    const rect=host.getBoundingClientRect(),layout=currentMobileControlLayout();
    layout[drag.id]=clampMobileControl({...layout[drag.id],x:((event.clientX-rect.left)/rect.width)*100,y:((event.clientY-rect.top)/rect.height)*100});
    profile.settings.mobileControls=layout;applyMobileControlLayout();syncMobileControlEditor();
  });
  const end=event=>{if(!drag||event.pointerId!==drag.pointerId)return;host.querySelectorAll('.dragging').forEach(button=>button.classList.remove('dragging'));drag=null;};
  host.addEventListener('pointerup',end);host.addEventListener('pointercancel',end);
}
function applyPlatformLayout(){
 const mode=effectivePlatform();
 $('game-root').classList.toggle('platform-mobile',mode==='mobile');$('game-root').classList.toggle('platform-computer',mode==='computer');
 $('touch-controls').classList.toggle('hidden',mode!=='mobile'||!roundActive);
 $('tips').classList.add('hidden');
 $('platform-mobile').classList.toggle('selected',mode==='mobile');$('platform-computer').classList.toggle('selected',mode==='computer');
 $('menu-control-help').textContent=mode==='mobile'?'MOBILE: joystick move/dirige · arraste a área livre para mirar · ATIRAR, PULAR, RECARGA, PEGAR, VERITY e DIRIGIR.':'PC: WASD mover/dirigir · mouse mirar · clique ou F atirar · Espaço pular · R recarregar · E pegar/entrar no carro · G arremessar Verity.';
 applyMobileControlLayout();
 $('menu-control-help').classList.toggle('hidden',!profile.settings.tips);
 if(typeof syncRotateHint==='function')syncRotateHint();
}
function setPlatformMode(mode,persist=true){platformMode=mode;if(mode==='mobile'){mouseDown=false;fireHeld=false;dragging=false}if(persist){profile.settings.platform=mode;saveProfile()}applyPlatformLayout()}
function applyCameraMode(){
 camera.fov=cameraMode==='first'?78:62;camera.updateProjectionMatrix();
 $('game-root').classList.toggle('camera-first',cameraMode==='first');$('camera-first').classList.toggle('selected',cameraMode==='first');$('camera-third').classList.toggle('selected',cameraMode==='third');
 $('camera-mode-toggle').textContent=cameraMode==='first'?'1ª PESSOA':'3ª PESSOA';$('camera-mode-toggle').setAttribute('aria-label',cameraMode==='first'?'Mudar para terceira pessoa':'Mudar para primeira pessoa');$('camera-mode-toggle').setAttribute('aria-pressed',String(cameraMode==='first'));$('camera-mode-toggle').title='Toque para alternar a câmera durante a partida';$('crosshair').classList.toggle('first-person',cameraMode==='first');
 if(player?.group&&player.alive)player.group.visible=!(roundActive&&cameraMode==='first');
 if(firstPersonRig)firstPersonRig.visible=!!(roundActive&&cameraMode==='first'&&player?.alive&&!activeVehicle);
}
function setCameraMode(mode,persist=true){cameraMode=mode==='first'?'first':'third';if(activeVehicle)cameraVehicleLastYaw=activeVehicle.yaw;if(persist){profile.settings.cameraMode=cameraMode;saveProfile()}applyCameraMode();if(roundActive&&player)rebuildFirstPersonRig()}
function syncSettings(){
 const s=profile.settings;
 $('setting-quality').value=['low','medium','high'].includes(s.quality)?s.quality:'medium';
 $('setting-volume').value=clamp(Number(s.volume??60),0,100);$('volume-value').textContent=$('setting-volume').value+'%';
 $('setting-sensitivity').value=clamp(Number(s.sensitivity??4),1,10);$('sensitivity-value').textContent=(Number($('setting-sensitivity').value)/1000).toFixed(3).replace('.',',');
 $('setting-invert').checked=!!s.invert;$('setting-tips').checked=s.tips!==false;
 currentMobileControlLayout();syncMobileControlEditor();applyMobileControlLayout();
}
function saveSettings(){
 profile.settings.quality=$('setting-quality').value;
 profile.settings.volume=clamp(+$('setting-volume').value,0,100);
 profile.settings.sensitivity=clamp(+$('setting-sensitivity').value,1,10);
 profile.settings.invert=$('setting-invert').checked;profile.settings.tips=$('setting-tips').checked;
 profile.settings.mobileControls=currentMobileControlLayout();
 renderer.shadowMap.enabled=profile.settings.quality!=='low';sun.castShadow=renderer.shadowMap.enabled;
 renderer.setPixelRatio(profile.settings.quality==='low'?1:profile.settings.quality==='high'?Math.min(window.devicePixelRatio||1,2):Math.min(window.devicePixelRatio||1,1.35));
 saveProfile();applyPlatformLayout();makeToast('Configurações salvas');hidePanels();
}
// Compatibilidade com páginas de implantação anteriores que usam o nome PascalCase.
function SaveSettings(){return saveSettings()}

bindMobileControlEditor();

// Navegação das categorias da loja e do inventário reformulado.
document.querySelectorAll('[data-store-filter]').forEach(button=>button.addEventListener('click',()=>{storeFilter=button.dataset.storeFilter==='cosmetics'?'cosmetics':'featured';renderStore();}));
document.querySelectorAll('[data-inventory-tab]').forEach(button=>button.addEventListener('click',()=>setInventoryTab(button.dataset.inventoryTab)));
$('store-detail-buy')?.addEventListener('click',()=>openStorePurchase(selectedStoreItemId));
$('store-confirm-cancel')?.addEventListener('click',closeStorePurchase);
$('store-confirm-accept')?.addEventListener('click',confirmStorePurchase);
$('store-purchase-dialog')?.addEventListener('pointerdown',event=>{if(event.target===$('store-purchase-dialog'))closeStorePurchase()});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('store-purchase-dialog').classList.contains('hidden')){event.preventDefault();closeStorePurchase()}});

// Eventos do menu principal, navegação e preferências da plataforma/câmera.
$('play-button').addEventListener('click',()=>showPanel('mode-panel'));
$('platform-computer').addEventListener('click',()=>setPlatformMode('computer'));
$('platform-mobile').addEventListener('click',()=>setPlatformMode('mobile'));
$('camera-third').addEventListener('click',()=>setCameraMode('third'));
$('camera-first').addEventListener('click',()=>setCameraMode('first'));
const cameraModeButton=$('camera-mode-toggle');
function toggleCameraModeFromInput(event){
  event?.preventDefault?.();event?.stopPropagation?.();
  setCameraMode(cameraMode==='first'?'third':'first');
  makeToast(cameraMode==='first'?'Câmera em primeira pessoa':'Câmera em terceira pessoa');
}
// Pointerdown works on touch even when preventDefault suppresses a synthetic click.
 cameraModeButton.addEventListener('pointerdown',event=>{if(event.isPrimary===false)return;toggleCameraModeFromInput(event)});
 cameraModeButton.addEventListener('click',event=>{if(event.detail===0)toggleCameraModeFromInput(event)});
document.querySelectorAll('[data-screen]').forEach(b=>b.addEventListener('click',()=>showPanel(`${b.dataset.screen}-panel`)));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',hidePanels));
$('nickname-button').addEventListener('click',()=>{updateProfileUI();showPanel('profile-panel')});
$('profile-edit-nickname').addEventListener('click',()=>{$('nickname-input').value=profile.nickname==='JOGADOR'?'':profile.nickname;$('nickname-error').textContent='';showPanel('nickname-panel');$('nickname-input').focus()});
$('profile-copy-id').addEventListener('click',async()=>{const id=profile.userId;try{await navigator.clipboard.writeText(id);makeToast('ID copiado: '+id)}catch{window.prompt('Copie seu ID de usuário:',id)}});
document.querySelectorAll('[data-profile-avatar]').forEach(button=>button.addEventListener('click',()=>{profile.avatar=PROFILE_AVATAR_CHOICES.includes(button.dataset.profileAvatar)?button.dataset.profileAvatar:'🎮';saveProfile();document.querySelectorAll('[data-profile-avatar]').forEach(item=>item.classList.toggle('selected',item.dataset.profileAvatar===profile.avatar));makeToast('Ícone de perfil atualizado')}));
$('profile-avatar-upload').addEventListener('click',()=> $('profile-avatar-file').click());
$('profile-avatar-file').addEventListener('change',event=>{
 const file=event.target.files?.[0];if(!file)return;
 if(!file.type.startsWith('image/')){makeToast('Escolha uma imagem válida.');event.target.value='';return}
 if(file.size>5*1024*1024){makeToast('A imagem deve ter no máximo 5 MB.');event.target.value='';return}
 const url=URL.createObjectURL(file),img=new Image();
 img.onload=()=>{try{const side=Math.min(img.naturalWidth,img.naturalHeight);const sx=(img.naturalWidth-side)/2,sy=(img.naturalHeight-side)/2;const canvas=document.createElement('canvas');canvas.width=128;canvas.height=128;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Canvas indisponível');ctx.drawImage(img,sx,sy,side,side,0,0,128,128);profile.avatar=canvas.toDataURL('image/jpeg',.78);saveProfile();makeToast('Foto de perfil salva neste navegador')}catch(error){makeToast('Não foi possível processar a imagem')}finally{URL.revokeObjectURL(url);event.target.value=''}};
 img.onerror=()=>{URL.revokeObjectURL(url);event.target.value='';makeToast('Não foi possível abrir a imagem')};img.src=url;
});
$('profile-reset-avatar').addEventListener('click',()=>{profile.avatar='🎮';saveProfile();document.querySelectorAll('[data-profile-avatar]').forEach(item=>item.classList.toggle('selected',item.dataset.profileAvatar===profile.avatar));makeToast('Ícone padrão restaurado')});

$('save-nickname').addEventListener('click',()=>{const n=$('nickname-input').value.trim();if(!/^[\p{L}0-9_]{3,16}$/u.test(n)){$('nickname-error').textContent='Use 3–16 caracteres: letras, números ou _. ';return}if(/admin|moderator|suporte|retardad/i.test(n)){$('nickname-error').textContent='Esse nickname não está disponível. Escolha outro.';return}profile.nickname=n;saveProfile();hidePanels();makeToast('Nickname atualizado')});
$('confirm-character').addEventListener('click',async()=>{const chosen=getCharacterById(selectedCharacter);if(!chosen||chosen.unlockCode&&!profile.unlockedCharacters.includes(chosen.id)){makeToast('Personagem ainda bloqueado');return}try{if(chosen.imported)await ensureImportedCharacterLoaded(chosen.id);profile.character=selectedCharacter;saveProfile();syncPreview();hidePanels();makeToast(`${chosen.name} selecionado`)}catch(error){setImportStatus(error?.message||'Não foi possível carregar esse personagem.','error');makeToast('Falha ao carregar o personagem')}});

function updateCustomAppearance(){profile.customAppearance={hair:$('custom-hair').value,shirt:$('custom-shirt').value,pants:$('custom-pants').value};const chosen=CHARACTERS.find(c=>c.id==='custom');if(selectedCharacter==='custom'&&preview){world.remove(preview);for(let i=shootables.length-1;i>=0;i--)if(shootables[i].userData.preview)shootables.splice(i,1);preview=makeCharacter(chosen);preview.position.set(0,0,3);preview.traverse(o=>{if(o.isMesh){o.userData.preview=true;o.castShadow=false;const i=shootables.indexOf(o);if(i>=0)shootables.splice(i,1)}});world.add(preview)}saveProfile();}
$('custom-hair').addEventListener('input',updateCustomAppearance);$('custom-shirt').addEventListener('input',updateCustomAppearance);$('custom-pants').addEventListener('input',updateCustomAppearance);
$('mode-bots').addEventListener('click',()=>{selectedMode='bots';$('mode-bots').classList.add('selected');$('mode-training').classList.remove('selected')});
$('mode-training').addEventListener('click',()=>{selectedMode='training';$('mode-training').classList.add('selected');$('mode-bots').classList.remove('selected')});
$('mode-online').addEventListener('click',openRoomOptions);$('mode-join-room').addEventListener('click',()=>{setRoomConnectStatus('');$('room-code-input').value='';showPanel('join-room-panel');$('room-code-input').focus()});$('create-private-room').addEventListener('click',createOnlineRoomFromMenu);$('create-public-room').addEventListener('click',()=>createPublicRoomFromMenu('create-public-room'));$('create-public-room-from-list').addEventListener('click',()=>createPublicRoomFromMenu('create-public-room-from-list'));$('open-public-rooms').addEventListener('click',openPublicRooms);$('refresh-public-rooms').addEventListener('click',refreshPublicRooms);$('public-rooms-back').addEventListener('click',()=>showPanel('room-options-panel'));$('join-room-submit').addEventListener('click',joinOnlineRoomFromMenu);$('room-code-input').addEventListener('input',e=>{const input=e.currentTarget;const start=input.selectionStart;const end=input.selectionEnd;input.value=input.value.toUpperCase().replace(/\s+/g,'');try{input.setSelectionRange(start,end)}catch{}});$('room-code-input').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();joinOnlineRoomFromMenu()}});$('online-copy-code').addEventListener('click',copyOnlineRoomCode);$('online-leave').addEventListener('click',()=>{exitCurrentMultiplayerRoom();openMainMenu()});
$('online-lobby-copy').addEventListener('click',copyOnlineRoomCode);
$('online-lobby-start').addEventListener('click',()=>sendLobbyAction('start'));
$('online-lobby-leave').addEventListener('click',()=>{exitCurrentMultiplayerRoom();openMainMenu()});
$('online-lobby-invite').addEventListener('click',async()=>{
  const code=multiplayerRoomCode;if(!code)return;
  const message=`Vamos jogar Retardados Royale! Entre em SALAS MULTIPLAYER e use o código ${code}.`;
  if(typeof navigator.share==='function'){
    try{await navigator.share({title:'Convite — Retardados Royale',text:message});setOnlineLobbyStatus('Convite pronto para compartilhar.','success');return}
    catch(error){if(error?.name==='AbortError')return}
  }
  await copyOnlineRoomCode();
});
$('pause-room-copy').addEventListener('click',copyOnlineRoomCode);
$('bot-count').addEventListener('input',e=>{$('bot-count-value').textContent=e.target.value;botCount=+e.target.value});
$('start-match').addEventListener('click',async event=>{const button=event.currentTarget;if(button.disabled)return;button.disabled=true;try{const chosen=getCharacterById(profile.character)||CHARACTERS[0];if(chosen.imported)await ensureImportedCharacterLoaded(chosen.id);botCount=+$('bot-count').value;botDifficulty=$('bot-difficulty').value;startMatch()}catch(error){makeToast(error?.message||'Não foi possível carregar o personagem');showPanel('characters')}finally{button.disabled=false}});
function resetTransientInputs(){
  for(const code of Object.keys(keyDown))keyDown[code]=false;
  mouseDown=false;fireHeld=false;touchFire=false;dragging=false;touchMove={x:0,y:0};onlineJumpQueued=false;
  try{touchAimId=null;touchAimPrev=null;stickPointer=null;firePointerId=null;knob.style.transform='';fireButton.classList.remove('pressed')}catch{}
  document.exitPointerLock?.();
}
$('pause-button').addEventListener('click',()=>{if(roundActive){resetTransientInputs();roundActive=false;showPanel('pause-panel')}});
$('resume-game').addEventListener('click',()=>{resetTransientInputs();hidePanels();roundActive=true;$('brand').classList.add('hidden');$('tips').classList.add('hidden');applyPlatformLayout();applyCameraMode()});
$('leave-match').addEventListener('click',openMainMenu);
$('result-menu').addEventListener('click',openMainMenu);
$('play-again').addEventListener('click',()=>startMatch());
$('setting-volume').addEventListener('input',e=>$('volume-value').textContent=e.target.value+'%');$('setting-sensitivity').addEventListener('input',e=>$('sensitivity-value').textContent=(e.target.value/1000).toFixed(3).replace('.',','));$('save-settings').addEventListener('click',saveSettings);
const redeemInput=$('redeem-code-input');
redeemInput.addEventListener('input',()=>{const start=redeemInput.selectionStart;const upper=redeemInput.value.toLocaleUpperCase('pt-BR');if(redeemInput.value!==upper){redeemInput.value=upper;try{redeemInput.setSelectionRange(start,start)}catch{}}});
redeemInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();redeemCode()}});
$('redeem-code-button').addEventListener('click',redeemCode);
$('redeem-open-characters').addEventListener('click',()=>{selectedCharacter=profile.character;showPanel('characters-panel')});
$('bot-count').value=botCount;$('bot-count-value').textContent=botCount;

function showRedeemStatus(message,type='error'){
 const status=$('redeem-code-status');status.textContent=message;status.className=`redeem-status ${type}`;
}
function redeemCode(){
 const input=$('redeem-code-input');const code=input.value.trim().toLocaleUpperCase('pt-BR');input.value=code;
 $('redeem-open-characters').classList.add('hidden');
 if(!code){showRedeemStatus('Digite um código para resgatar.','error');return}
 if(profile.redeemedCodes.includes(code)){showRedeemStatus('Esse código já foi resgatado neste perfil.','error');return}
 if(code!=='VINCENT069'){
   showRedeemStatus('Código inválido ou inexistente. Confira e tente novamente.','error');playTone(170,.12,'sawtooth',.035);return;
 }
 if(profile.unlockedCharacters.includes('vincent')){
   profile.redeemedCodes.push(code);saveProfile();showRedeemStatus('VINCENT já está desbloqueado neste perfil.','success');return;
 }
 profile.unlockedCharacters.push('vincent');profile.redeemedCodes.push(code);saveProfile();
 showRedeemStatus('Código resgatado! VINCENT foi desbloqueado e já está na seleção de personagens.','success');
 $('redeem-open-characters').classList.remove('hidden');playTone(720,.12,'sine',.05);setTimeout(()=>playTone(960,.16,'sine',.04),100);
}

// Desktop keyboard and mouse. Click the canvas once to capture the mouse; Esc unlocks it.
window.addEventListener('keydown',e=>{keyDown[e.code]=true;if(multiplayerActive&&e.code==='Space'&&!e.repeat)onlineJumpQueued=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)&&roundActive)e.preventDefault();if(!roundActive)return;
  if(e.code==='Escape'){resetTransientInputs();roundActive=false;showPanel('pause-panel')}
  if(e.code==='KeyC'&&!e.repeat){setCameraMode(cameraMode==='first'?'third':'first')}
  if(e.code==='KeyR')reloadPlayer();if(!multiplayerActive&&e.code==='KeyE'&&!e.repeat){if(activeVehicle||nearestVehicle(player,5.5))toggleVehicle();else collectNearest(player);}
  if(e.code==='KeyF'&&player?.alive&&effectivePlatform()!=='mobile')fireWeapon(player,true);
  if(!multiplayerActive&&e.code==='KeyG'&&!e.repeat&&player?.alive&&effectivePlatform()!=='mobile')throwVerity(player);
  if(!multiplayerActive&&/^Digit[1-5]$/.test(e.code))switchWeapon(+e.code.slice(-1)-1);
});
window.addEventListener('keyup',e=>{keyDown[e.code]=false});
canvas.addEventListener('click',()=>{if(roundActive&&player?.alive&&effectivePlatform()!=='mobile'&&window.matchMedia('(pointer:fine)').matches){canvas.requestPointerLock?.()}});
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement!==canvas){mouseDown=false;fireHeld=false}});
document.addEventListener('mousemove',e=>{if(!roundActive)return;if(document.pointerLockElement===canvas){const sens=profile.settings.sensitivity/1000;cameraYaw+=e.movementX*sens;cameraPitch+=e.movementY*sens*(profile.settings.invert?1:-1);cameraPitch=clamp(cameraPitch,-.62,.78)}else if(dragging){const sens=profile.settings.sensitivity/1000;cameraYaw+=(e.clientX-lastPointer.x)*sens;cameraPitch+=(e.clientY-lastPointer.y)*sens*(profile.settings.invert?1:-1);cameraPitch=clamp(cameraPitch,-.62,.78);lastPointer={x:e.clientX,y:e.clientY}}});
canvas.addEventListener('mousedown',e=>{
  if(!roundActive||effectivePlatform()==='mobile'||e.sourceCapabilities?.firesTouchEvents)return;
  if(e.button===0){mouseDown=true;fireHeld=true;fireWeapon(player,true)}
  if(e.button===2||e.button===1){dragging=true;lastPointer={x:e.clientX,y:e.clientY}}
});
window.addEventListener('mouseup',e=>{if(e.button===0){mouseDown=false;fireHeld=false}if(e.button===2||e.button===1)dragging=false});canvas.addEventListener('contextmenu',e=>e.preventDefault());
// Touch joystick and action buttons: pointer capture preserves controls in landscape orientation.
const stick=$('touch-stick'),knob=$('stick-knob');let stickPointer=null;function setStick(e){const rect=stick.getBoundingClientRect(),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2;let x=(e.clientX-cx)/(rect.width*.34),y=(e.clientY-cy)/(rect.height*.34);const l=Math.hypot(x,y);if(l>1){x/=l;y/=l}touchMove={x,y};const travel=Math.max(8,rect.width*.27);knob.style.transform=`translate(${x*travel}px,${y*travel}px)`}
stick.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();stickPointer=e.pointerId;try{stick.setPointerCapture(e.pointerId)}catch{}setStick(e);getAudio()});stick.addEventListener('pointermove',e=>{if(stickPointer===e.pointerId)setStick(e)});function resetStick(e){if(e&&stickPointer!==null&&e.pointerId!==stickPointer)return;stickPointer=null;touchMove={x:0,y:0};knob.style.transform=''}stick.addEventListener('pointerup',resetStick);stick.addEventListener('pointercancel',resetStick);
const fireButton=$('touch-fire');let firePointerId=null;
function stopMobileFire(e){if(firePointerId===null||(e&&e.pointerId!==firePointerId))return;touchFire=false;firePointerId=null;fireButton.classList.remove('pressed')}
fireButton.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();if(!roundActive||!player?.alive||firePointerId!==null)return;getAudio();firePointerId=e.pointerId;touchFire=true;fireWeapon(player,true);fireButton.classList.add('pressed');try{fireButton.setPointerCapture(e.pointerId)}catch{}});
window.addEventListener('pointerup',stopMobileFire,true);window.addEventListener('pointercancel',stopMobileFire,true);
// Pointer clicks on the button are handled above. This click fallback is only for keyboard activation.
fireButton.addEventListener('click',e=>{if(e.detail===0&&roundActive&&player?.alive){getAudio();fireWeapon(player,true)}});
const verityButton=$('touch-verity');
function verityAction(e){e?.preventDefault?.();e?.stopPropagation?.();getAudio();throwVerity(player)}
verityButton.addEventListener('pointerdown',verityAction);verityButton.addEventListener('click',e=>{if(e.detail===0)verityAction(e)});
const jumpButton=$('touch-jump');
function jumpPlayer(e){e?.preventDefault?.();e?.stopPropagation?.();if(!roundActive||!player?.alive||activeVehicle)return;getAudio();if(multiplayerActive){onlineJumpQueued=true;soundJump();return}if(grounded){jumpVelocity=7.4;grounded=false;soundJump()}}
jumpButton.addEventListener('pointerdown',e=>{try{jumpButton.setPointerCapture(e.pointerId)}catch{}jumpPlayer(e)});
jumpButton.addEventListener('click',e=>{if(e.detail===0)jumpPlayer(e)});
$('touch-reload').addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();reloadPlayer()});$('touch-reload').addEventListener('click',e=>{if(e.detail===0)reloadPlayer()});
const pickupButton=$('touch-pickup');
function pickupAction(e){e?.preventDefault?.();e?.stopPropagation?.();if(!roundActive||!player?.alive||!currentPickup)return;collectNearest(player)}
pickupButton.addEventListener('pointerdown',pickupAction);pickupButton.addEventListener('click',e=>{if(e.detail===0)pickupAction(e)});
$('touch-vehicle').addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();getAudio();toggleVehicle()});$('touch-vehicle').addEventListener('click',e=>{if(e.detail===0){getAudio();toggleVehicle()}});
// Any unoccupied touch surface can drag the camera. The left stick/action buttons are excluded.
let touchAimId=null,touchAimPrev=null;const ignoredTouchSelector='#touch-stick,.touch-actions,button,input,select,textarea,.panel,.hud-top,.hud-left,.hud-bottom,#minimap,.online-status,.pickup-prompt,.vehicle-prompt,.vehicle-hud,.toast,.kill-feed';
document.addEventListener('pointerdown',e=>{if(!roundActive||e.pointerType!=='touch'||touchAimId!==null)return;const target=e.target;if(target?.closest?.(ignoredTouchSelector))return;touchAimId=e.pointerId;touchAimPrev={x:e.clientX,y:e.clientY};try{target?.setPointerCapture?.(e.pointerId)}catch{}},{capture:true});
document.addEventListener('pointermove',e=>{if(touchAimId!==e.pointerId||!touchAimPrev||!roundActive)return;const dx=e.clientX-touchAimPrev.x,dy=e.clientY-touchAimPrev.y;const sens=profile.settings.sensitivity/1000;cameraYaw+=dx*sens*1.8;cameraPitch+=dy*sens*1.8*(profile.settings.invert?1:-1);cameraPitch=clamp(cameraPitch,-.62,.78);touchAimPrev={x:e.clientX,y:e.clientY}},{capture:true});
function clearTouchAim(e){if(touchAimId===e.pointerId){touchAimId=null;touchAimPrev=null}}document.addEventListener('pointerup',clearTouchAim,true);document.addEventListener('pointercancel',clearTouchAim,true);
// Audio starts on the first deliberate interaction; every menu button gets a small UI click.
document.addEventListener('pointerdown',()=>{getAudio()},{once:true,capture:true});document.addEventListener('click',e=>{if(e.target?.closest?.('button')&&!e.target.closest('#touch-fire'))soundUiClick()});

function syncRotateHint(){const rotate=roundActive&&effectivePlatform()==='mobile'&&window.innerHeight>window.innerWidth;$('rotate-hint').classList.toggle('hidden',!rotate)}
function resize(){camera.aspect=window.innerWidth/window.innerHeight;camera.updateProjectionMatrix();renderer.setSize(window.innerWidth,window.innerHeight);applyPlatformLayout();syncRotateHint()}window.addEventListener('resize',resize);

// Restore only metadata first; binary model files are loaded on demand from IndexedDB.
await refreshImportedCharacterMetadata();
ensureDailyMission({persist:false});
if(typeof profile.character==='string'&&profile.character.startsWith('imported:')){
  try{await ensureImportedCharacterLoaded(profile.character);}
  catch(error){console.warn('O personagem salvo não pôde ser restaurado; mantendo o jogo inicializável:',error);profile.character='enzo';try{localStorage.setItem('rr-profile',JSON.stringify(profile));}catch{}}
}
selectedCharacter=profile.character;
bindCharacterImportUI();
// Preview scene at launch.
syncPreview();saveProfile();updateProfileUI();$('coin-count').textContent=profile.coins;$('top-coins').classList.remove('hidden');$('top-coins').classList.add('menu-inline');$('loading-note').classList.add('hidden');applyPlatformLayout();applyCameraMode();
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.05);
  if(roundActive&&player?.alive&&profile.dailyMission?.type==='survive')addDailyMissionProgress('survive',dt);
  dailyMissionClock+=dt;
  if(dailyMissionClock>=1){
    dailyMissionClock=0;const oldDailyId=profile.dailyMission?.id;ensureDailyMission();
    if(dailyMissionDirty){dailyMissionDirty=false;saveProfile()}
    if(!$('missions-panel').classList.contains('hidden'))updateMissions();
    if(oldDailyId!==profile.dailyMission?.id&&!$('missions-panel').classList.contains('hidden'))makeToast('Nova missão diária disponível!');
  }
  if(roundActive&&!matchEnded){
    matchElapsed+=dt;
    if(multiplayerActive){
      // Multiplayer prototype: the server owns movement. No local bots, loot, combat,
      // vehicles or zone simulation runs in this mode.
      updatePlayer(dt);
      updateOnlineInterpolation(dt);
      if(player)updateEntityAnimation(player,dt);
      for(const remote of remotePlayers.values())updateEntityAnimation(remote,dt);
      updateHud();
    }else{
      updatePlayer(dt);updateVehicles(dt);updateBots(dt);
      for(const entity of entities)updateEntityAnimation(entity,dt);
      updateLoot(dt);updateZone(dt);
      if(!training&&matchElapsed>zoneStarts+zoneDuration&&zoneRadius<=zoneFinal&&entities.filter(e=>e.alive).length>1){
        for(const e of entities)if(e.alive&&Math.hypot(e.pos.x,e.pos.z)>zoneFinal)applyDamage(e,8*dt,null,false);
      }
      if(loot.length<14&&matchElapsed>nextLootSpawn){
        const p=randomSpot(30,210),chance=Math.random();
        if(chance<.075)spawnLoot('armor',ARMOR_POOL[Math.floor(Math.random()*ARMOR_POOL.length)],p.x,p.z);
        else if(chance<.53)spawnLoot('weapon',Math.random()<.5?'smg':Math.random()<.5?'rifle':'shotgun',p.x,p.z);
        else if(chance<.76)spawnLoot('ammo','ammo',p.x,p.z);else spawnLoot('shield','shield',p.x,p.z);
        nextLootSpawn=matchElapsed+9;
      }
      if(matchElapsed>=nextVeritySpawn){
        if(!loot.some(l=>l.type==='verity')&&loot.length<20){const p=randomSpot(40,224);spawnLoot('verity','verity',p.x,p.z);addFeed('Um Verity apareceu na arena');playTone(620,.15,'triangle',.035)}
        nextVeritySpawn=matchElapsed+rnd(68,106);
      }
      updateHud();
    }
  }
  if(!multiplayerActive){updateVerityProjectiles(dt);updateVerityEffects(dt);}
  updateCamera(dt);
  for(let i=projectileEffects.length-1;i>=0;i--){const fx=projectileEffects[i];fx.life-=dt;if(fx.expand){fx.obj.scale.multiplyScalar(1+dt*5);fx.obj.material.opacity=Math.max(0,fx.life*2.5)}if(fx.life<=0){world.remove(fx.obj);fx.obj.geometry?.dispose();fx.obj.material?.dispose();projectileEffects.splice(i,1)}}
  if(preview&&!roundActive&&!$('main-menu').classList.contains('hidden'))preview.rotation.y+=dt*.32;
  if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$('toast').classList.add('hidden')}
  renderImportModelPreview(dt);
  renderer.render(scene,camera);
}
// Menu preview camera; the first scene is intentionally simple and fast to load.
camera.position.set(7,5.3,13);camera.lookAt(0,1.4,3);animate();

window.addEventListener('pagehide',()=>{if(dailyMissionDirty){dailyMissionDirty=false;saveProfile()}});
