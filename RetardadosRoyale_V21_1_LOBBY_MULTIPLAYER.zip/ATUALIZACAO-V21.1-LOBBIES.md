# Atualização V21.1 — lobby e controles multiplayer

## Incluído
- Sala de espera antes de iniciar a partida, com nome, código e contador de jogadores.
- Cartões de jogadores com avatar/foto, nickname, personagem e destaque de anfitrião.
- Início de partida, expulsão e transferência de anfitrião protegidos por validação no lado que mantém a sala.
- Promoção automática do participante mais antigo quando alguém com cargo de anfitrião sai normalmente ou desconecta.
- Encerramento do relay quando não restam participantes após a saída do anfitrião.
- Convite por compartilhamento nativo do dispositivo ou cópia do código.
- Código e lista de jogadores movidos para o menu de pausa durante a partida.
- Botões mobile de disparo e recarga mantidos visíveis no multiplayer.
- Novo nome de cache do service worker para forçar a atualização da interface.

## Verificações feitas
- Sintaxe de `src/game.js` e `src/multiplayer-client.js` validada com `node --check`.
- Confirmada a ausência de IDs duplicados no HTML.
- A conexão real entre dois dispositivos não foi validada nesta execução; é necessário testar em duas sessões de navegador com rede externa.

## Limitações
- O projeto usa PeerJS/WebRTC sem servidor de sala dedicado. A página original precisa permanecer aberta como conexão de apoio após a transferência de anfitrião; fechar essa página pode derrubar a sala.
- O combate multiplayer ainda não sincroniza completamente dano, munição, armas, NPCs, loot, veículos e zona segura.
- A lista global de salas públicas permanece indisponível sem um catálogo central.
