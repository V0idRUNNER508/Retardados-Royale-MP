const CACHE_NAME = 'retardados-royale-web-v21-1-online-lobbies';
const CACHE_PREFIX = 'retardados-royale-web-';
const APP_SHELL = [
  './',
  './index.html',
  './style.css',
  './src/game.js',
  './src/profile-missions.js',
  './src/character-importer.js',
  './src/multiplayer-client.js',
  './shared/arena-layout.js',
  './manifest.webmanifest',
  './icons/icon.svg',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(APP_SHELL);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  // Never cache the service-worker script itself: browsers must revalidate it for updates.
  if (url.pathname.endsWith('/service-worker.js')) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const isNavigation = request.mode === 'navigate' || request.destination === 'document';
    try {
      // Network-first means a published update becomes visible immediately online.
      const response = await fetch(request, { cache: 'no-cache' });
      if (response && response.ok) {
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    } catch (error) {
      const cached = await caches.match(request, { ignoreSearch: true });
      if (cached) return cached;
      if (isNavigation) {
        const index = await caches.match('./index.html');
        if (index) return index;
      }
      return new Response(isNavigation ? 'Jogo indisponível offline.' : 'Recurso indisponível offline.', {
        status: 503,
        headers: { 'Content-Type': 'text/plain; charset=utf-8' }
      });
    }
  })());
});
