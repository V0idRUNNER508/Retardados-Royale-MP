# Retardados Royale V16 — câmera, armas, missões e perfil

## Alterações
- Câmera em terceira pessoa com haste de perseguição que acompanha o ângulo do personagem, mantendo o controle de mira.
- Alternância 1ª/3ª pessoa no HUD, também por tecla C no computador.
- Slots de arma renderizados como botões acessíveis e ativados por pointerdown/toque; a troca chama o sistema existente de equipar a arma.
- Missão diária com validade real de 24 horas, progresso salvo localmente, recompensa resgatável e renovação automática; missões normais permanecem disponíveis.
- Intervalo de aparecimento de Verity levemente reduzido (primeiro spawn 40–64 s; reaparecimento 68–106 s).
- Perfil local com ID RR gerado automaticamente, ícones emoji e foto quadrada comprimida para 128×128 guardada no perfil local.
- ID e emoji selecionado compartilhados com o servidor multiplayer para exibição no roster. O ID é uma identificação de cliente, não uma conta autenticada nem proteção antifraude. Foto enviada permanece só no navegador.
- Cache do service worker versionado para V16, incluindo o módulo de missões diárias.

## Persistência e privacidade
Perfil, avatar/foto e missão diária ficam no localStorage do navegador. A foto é redimensionada para 128×128 e JPEG para reduzir armazenamento. O ID fica salvo nesse navegador/dispositivo; não há serviço de contas, recuperação de conta nem sincronização universal. O ID enviado ao servidor é fornecido pelo cliente e pode ser falsificado, portanto não serve como prova de identidade.

## Testes
Testes executados: 2 de arena, 6 do importador, 7 de ajustes V15 mantidos, 5 testes unitários das regras de missão diária e 8 testes estáticos das funcionalidades V16 (28 testes aprovados). A sintaxe Node dos scripts principais também foi verificada. O teste de integração multiplayer exige as dependências do diretório server instaladas; não pôde ser concluído neste ambiente. Testes visuais reais de câmera, toque, foto e missão diária precisam ser feitos no navegador de destino; não se declara teste físico Android nesta entrega.
