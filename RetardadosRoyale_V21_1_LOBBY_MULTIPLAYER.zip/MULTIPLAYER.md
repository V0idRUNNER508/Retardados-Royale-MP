# Retardados Royale — Salas online e lobby (V21.1)

## Fluxo da sala

1. Publique os arquivos do projeto em uma hospedagem HTTPS.
2. No jogo, escolha **JOGAR → SALAS MULTIPLAYER** e crie uma sala pública ou privada.
3. A sala de espera mostra o código e os jogadores conectados. Use **CONVIDAR / COMPARTILHAR CÓDIGO** para enviar o código aos amigos.
4. Os amigos abrem o mesmo site, escolhem **ENTRAR EM SALA**, digitam o código e aguardam no lobby.
5. Somente o anfitrião atual pode iniciar a partida, expulsar participantes ou transferir o cargo. As solicitações são validadas pelo estado da sala, não só pela interface.
6. Durante a partida, código e lista de participantes ficam no menu de pausa. Use **SAIR DA PARTIDA** para voltar ao menu.

## Regras implementadas

- Até oito jogadores por sala nesta configuração.
- Avatar por emoji ou foto de perfil, nickname e personagem são mostrados no lobby.
- O anfitrião recebe uma coroa e a legenda **Anfitrião**.
- O anfitrião pode iniciar, expulsar um participante ou transferir o cargo a outro participante durante a sala de espera.
- Quando um participante sai inesperadamente ou sai pelo botão de saída, o cargo é transferido para o participante mais antigo restante.
- Quando a sala fica sem participantes após o anfitrião sair, o relay PeerJS é encerrado.
- Os controles de toque **ATIRAR** e **R** não são escondidos durante a partida multiplayer.
- A lista e o código da sala não permanecem fixos na HUD; aparecem somente no menu de pausa durante a partida.

## Limitações técnicas que precisam ficar claras

Esta versão usa PeerJS Cloud para sinalização e WebRTC para conectar jogadores. Não há um servidor de jogo independente que continue existindo após a página original ser fechada. Para permitir transferência de anfitrião sem backend, quando o criador sai pelo botão do jogo a página permanece aberta em segundo plano como conexão de apoio, enquanto o cargo visível passa para outro jogador. **Se o navegador/aba que criou a sala for fechado, recarregado ou perder a conexão, a sala atual ainda pode cair.** Para eliminar essa limitação por completo, o jogo precisaria de um servidor de sala dedicado.

A cópia também não possui catálogo central para descobrir todas as salas públicas; os jogadores entram pelo código compartilhado. O multiplayer deste protótipo sincroniza a presença e a movimentação/salto, mas não implementa sincronização autoritativa completa para dano, munição, armas, NPCs, loot, veículos e zona segura. A presença dos botões de disparo e recarga não significa que todo o combate esteja sincronizado entre aparelhos.

## Problemas comuns

- **Código não encontrado:** confira todos os caracteres e peça ao anfitrião para manter a página original aberta e conectada.
- **Não conecta:** a rede precisa permitir WebRTC e o navegador precisa acessar PeerJS Cloud e os CDNs usados pela aplicação.
- **Interface antiga após publicação:** o service worker recebeu um novo nome de cache nesta atualização; recarregue a página. Se necessário, feche e reabra o site.

## Publicação

Envie o conteúdo desta pasta mantendo a estrutura `src/`, `shared/`, `icons/`, `index.html`, `style.css`, `manifest.webmanifest` e `service-worker.js`. Esta alteração prepara os arquivos; não publica automaticamente na sua conta de hospedagem.
