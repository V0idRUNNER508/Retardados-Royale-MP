# Retardados Royale V19 — Interface Royale

## Objetivo
Reformulação visual das telas existentes mantendo os IDs HTML e os sistemas reais de navegação e jogo.

## Alterações
- Novo sistema visual: azul-marinho/grafite, ciano como destaque e laranja discreto, painéis arredondados e estados de foco acessíveis.
- Menu principal reorganizado com navegação por cartões, perfil/moedas e resumo dinâmico do operador e da coleção.
- Seleção de personagens com resumo do selecionado; personagens bloqueados são visíveis com requisito do código em vez de parecerem ausentes. Personagens originais e importados continuam registrados no fluxo existente.
- Loja com abas reais (Destaques/Todos os cosméticos), painel de item selecionado e diálogo de confirmação próprio; a compra revalida saldo e propriedade antes de descontar moedas.
- Inventário organizado em Coleção, Armaduras, Item Especial e Arsenal, usando listas existentes.
- Configurações divididas visualmente em categorias já suportadas pela lógica existente.
- Perfil, missões, resgate de código, menus de pausa e HUD receberam o tema unificado e adaptações responsivas para dispositivos móveis.
- Service worker versionado como V19 para invalidar o cache anterior.

## Preservação
Não foi substituída a engine Three.js, a física, o mapa, a movimentação, a câmera ou o protocolo multiplayer. Os sistemas de loja, perfil, coleção, missões e seleção continuam usando os dados do jogo. Nenhuma categoria de loja fictícia foi adicionada.

## Testes
Verificações estáticas e suíte automatizada do projeto estão listadas no relatório final. O teste visual deve ser concluído em navegador real/Netlify antes de considerar o deploy validado.
