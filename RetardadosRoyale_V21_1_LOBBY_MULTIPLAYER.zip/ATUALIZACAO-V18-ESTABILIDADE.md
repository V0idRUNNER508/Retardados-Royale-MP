# Retardados Royale V18 — Estabilidade e jogabilidade

## Corrigido
- Câmera de terceira pessoa ancorada na posição do jogador; o ângulo de visão controla a órbita e o quadro de movimento.
- Colisão de câmera de terceira pessoa contra obstáculos da arena, com compressão rápida ao se aproximar de paredes e retorno suave.
- Câmera em veículos acompanha sua rotação relativa enquanto mantém controle de órbita manual.
- Hotbar com eventos delegados, persistência dos elementos DOM entre atualizações de munição, destaque acessível do slot e atualização da arma equipada.
- Entradas de teclado, joystick, tiro e arrasto são liberadas ao pausar, retomar, finalizar partida ou voltar ao menu.
- Gestos de câmera ignoram os elementos interativos do HUD.
- Ajustes responsivos para telas estreitas e áreas seguras mobile.
- Identificador visual V18 e nova chave do service worker para invalidar o cache antigo.

## Preservado
- Importador 3D/IndexedDB, personagens originais e personalizados, animações, mapa, itens, veículos, missões, perfis e sistema multiplayer/protocolo.
- Nenhuma nova funcionalidade de multiplayer adicionada.

## Testes
- `npm test` executa verificações da arena, importador, versões anteriores, missões, publicação e testes estáticos da V18.
- As verificações estáticas e de sintaxe não substituem testes visuais em Android e PC.

## Publicação
- Projeto completo: `netlify.toml` publica `RetardadosRoyale_Web_v6`.
- Netlify Drop: use o ZIP separado com `index.html` diretamente na raiz.
