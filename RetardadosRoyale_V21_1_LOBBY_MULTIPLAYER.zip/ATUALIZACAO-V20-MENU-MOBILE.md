# Retardados Royale V20 — ajustes de menu mobile

- Removido visualmente o cartão de lobby local do menu.
- Saldo RC reposicionado ao lado do perfil no menu e nas telas secundárias; no resultado da partida, mantém a posição padrão.
- Restaurada a identidade visual original preta/grafite com acentos laranja, incluindo a marca RR em formato angular.
- Ocultadas as estatísticas abaixo do botão Jogar e o atalho Estatísticas no menu; nível, vitórias e eliminações permanecem no Perfil.
- Painel de escolha de modo mais compacto e demais painéis com margens/altura reduzidas em telas pequenas.
- Atualizada a versão visível e o cache do service worker para V20.

Os elementos de estatísticas mantêm seus IDs no HTML porque `updateProfileUI()` atualiza esses nós; eles são ocultados visualmente pelo CSS. A tela Estatísticas continua preservada no código, mas sem botão no menu principal.
