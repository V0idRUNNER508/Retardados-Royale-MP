# Retardados Royale — V15: orientação, animação e controles móveis

## Alterações

- Adicionado botão de alternância de orientação de 180° na prévia/importador. O offset é salvo nos metadados de cada personagem importado, sem reescrever o arquivo GLB original.
- Arma de jogo anexada ao osso de mão direita quando reconhecido. A orientação da arma é alinhada ao eixo de frente do personagem; quando não há osso de mão identificável, mantém-se o suporte genérico existente.
- Adicionada pose genérica de empunhadura, que tenta orientar os braços e antebraços para segurar a arma depois da animação importada. Isso depende de ossos humanoides reconhecíveis e não é retargeting universal de qualquer esqueleto.
- Melhorado reconhecimento de nomes de ossos de pernas, incluindo rigs que usam nomes simples como `LeftLeg` e `RightLeg`. Quando não há trilhas de caminhada/corrida aplicáveis aos ossos de perna encontrados, o jogo usa uma passada procedural simples como fallback.
- Minimap movido ao canto superior direito do HUD mobile, abaixo da faixa superior e do botão de pausa.
- Botão E/PEGAR reposicionado acima do botão ATIRAR sem alterar sua ação.
- Configurações agora incluem prévia arrastável dos controles móveis e ajustes de posição horizontal/vertical, tamanho e opacidade, além de restaurar posições padrão. As configurações são mantidas no perfil local ao tocar em SALVAR.
- Atualizada a chave de cache do service worker para garantir que a versão publicada solicite os arquivos V15.

## Limitações

- A pose de empunhadura é genérica; esqueletos com convenções de nomes não reconhecidas podem não posicionar os braços corretamente.
- GLB com animações de rig incompatível ainda pode precisar de retargeting específico. Esta alteração não incorpora um serviço de auto-rigging nem envia modelos do usuário a terceiros.
- Ajustes visuais precisam ser verificados em dispositivo real, em particular telas estreitas, modo paisagem e rigs diferentes.

## Verificações automáticas

- `node --check RetardadosRoyale_Web_v6/src/game.js`
- `node --check RetardadosRoyale_Web_v6/src/character-importer.js`
- `npm run test:characters`
- `npm run test:arena`
- `npm run test:v15-ui`

Os testes automatizados verificam sintaxe, regras de importação existentes, layout da arena e presença das integrações V15. Eles não substituem o teste de jogo em Chrome Android/desktop; esse teste visual completo não foi possível neste ambiente.
