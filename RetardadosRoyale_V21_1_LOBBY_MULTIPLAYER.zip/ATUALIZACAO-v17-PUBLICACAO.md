# Retardados Royale V17 — correção de publicação e atualização visível

## Causa encontrada
O ZIP anterior guardava o site dentro de `RetardadosRoyale_Web_v6/`. Para um deploy manual de site estático, se a pasta externa for publicada, o `index.html` fica um nível abaixo da raiz e o Netlify não serve a versão esperada.

## Correções desta entrega
- O pacote de publicação manual tem `index.html` diretamente na raiz.
- O pacote completo contém `netlify.toml` com `publish = "RetardadosRoyale_Web_v6"` para deploy conectado ao Git.
- A versão visível do menu mudou para V17.
- O cache do service worker foi versionado novamente e agora usa rede primeiro para atualizar os arquivos quando estiver online.
- `_headers` impede cache prolongado de `index.html`, do service worker e dos arquivos JavaScript/CSS da aplicação.
- Os sistemas V16 de câmera, hotbar, missões diárias, Verity e perfil foram preservados no código do jogo.

## Como publicar manualmente no Netlify Drop
1. Extraia `Retardados_Royale_V17_NETLIFY_DROP.zip`.
2. Dentro da pasta extraída, confira que `index.html` está diretamente na raiz, ao lado de `style.css`, `_headers`, `service-worker.js` e da pasta `src/`.
3. No site do Netlify, abra Deploys e use a área de upload manual; selecione/arraste a pasta que contém diretamente esses arquivos, não a pasta pai de todo o projeto e não uma pasta que contém apenas `RetardadosRoyale_Web_v6/`.
4. Aguarde o novo deploy terminar e abra a URL de produção. A etiqueta do menu deve mostrar `V17 • CÂMERA, PERFIL E MISSÕES`.
5. Se o app já estava instalado/PWA, atualize a página. Se continuar na versão antiga, limpe os dados/cache do site no navegador e abra novamente para remover o service worker antigo.

## Como publicar por Git
Envie todo o ZIP completo extraído para o repositório. O `netlify.toml` na raiz publica `RetardadosRoyale_Web_v6/` automaticamente. O backend multiplayer em `server/` continua separado e precisa permanecer publicado na hospedagem de servidor que já estava configurada.

## Validação
A suíte do projeto é composta principalmente por testes unitários e verificações estáticas. Ela não prova sozinha o funcionamento em um telefone físico nem a sincronização do backend online.
