# Retardados Royale v12 — leia antes de publicar

Este ZIP mantém o frontend existente e adiciona um backend Colyseus separado. **Não basta enviar o ZIP inteiro à Netlify para obter salas online.** A Netlify publica apenas `RetardadosRoyale_Web_v6/`; o processo Node da pasta `server/` precisa ser hospedado separadamente em um serviço que aceite WebSockets persistentes.

## Teste local

1. Instale Node.js 20.10+ e npm.
2. No terminal na raiz deste projeto, execute `npm run server:install`.
3. Execute `npm run server:dev` e mantenha esse terminal aberto.
4. Em outro terminal, execute `python -m http.server 8000 --directory RetardadosRoyale_Web_v6`.
5. Abra `http://localhost:8000` em duas janelas do navegador.
6. Em uma, clique em **Jogar → Criar sala**; na outra, clique em **Entrar em sala** e informe o código.
7. Mova ambos os jogadores. Teste saída/fechamento de uma janela para verificar se a lista atualiza.

Os testes sem conexão de rede podem ser executados por `npm run test:arena`. Com o servidor rodando e as dependências instaladas, `npm run test:integration` conecta dois clientes Colyseus de teste, verifica que compartilham uma sala, envia movimento e verifica a remoção após desconexão.

## Publicação

- **Frontend Netlify:** com deploy por Git, o `netlify.toml` já aponta para `RetardadosRoyale_Web_v6`. Com upload manual, envie o conteúdo dessa pasta, mantendo `src/`, `shared/` e `icons/`.
- **Backend Node:** em uma hospedagem Node com WebSockets, use `npm --prefix server install` como comando de build e `npm --prefix server start` como comando de inicialização. Use Node 20.10+ (22 LTS recomendado). O servidor usa `PORT` e `0.0.0.0`; se o provedor pedir um health-check path, use `/health`.
- Após a hospedagem do backend, copie sua URL HTTPS pública e edite `RetardadosRoyale_Web_v6/src/multiplayer-config.js`, mudando a linha `COLYSEUS_ENDPOINT = ''` para `COLYSEUS_ENDPOINT = 'https://URL-REAL-DO-SERVIDOR'`. Publique o frontend de novo.

## Estado do recurso

Esta é a primeira fase online: salas privadas por código, lista de participantes, personagem escolhido, posição/rotação/animação, movimento autoritativo e remoção de desconectados. Não sincroniza combate, armas, vida/escudo, inventário, armaduras, loot, bots, carros, Verity ou zona segura. O jogo solo conserva esses sistemas.

O pacote foi validado estaticamente e os testes de geração determinística do mapa passaram. **A sessão com dois clientes não pôde ser executada neste ambiente:** a instalação das dependências de npm expirou. Por isso, o multiplayer não deve ser considerado confirmado até executar o teste de integração e verificar dois clientes no navegador após publicar o backend.
