import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
import { Client } from '@colyseus/sdk';

const endpoint = process.env.MULTIPLAYER_TEST_ENDPOINT || 'http://127.0.0.1:2567';
async function waitFor(predicate, description, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await delay(50);
  }
  throw new Error(`Timeout esperando: ${description}`);
}

const clientA = new Client(endpoint);
const clientB = new Client(endpoint);
let roomA, roomB;
let lastA, lastB;
try {
  roomA = await clientA.create('royale', { nickname: 'TEST_A', characterId: 'enzo' });
  roomA.onMessage('snapshot', (snapshot) => { lastA = snapshot; });
  roomB = await clientB.joinById(roomA.roomId, { nickname: 'TEST_B', characterId: 'luan' });
  roomB.onMessage('snapshot', (snapshot) => { lastB = snapshot; });

  await waitFor(() => lastA?.players?.length === 2 && lastB?.players?.length === 2, 'dois clientes na mesma sala');
  assert.equal(roomA.roomId, roomB.roomId, 'os dois clientes devem estar na mesma sala');
  assert.ok(lastA.players.some((p) => p.sessionId === roomA.sessionId));
  assert.ok(lastA.players.some((p) => p.sessionId === roomB.sessionId));
  assert.ok(lastA.players.find((p) => p.sessionId === roomB.sessionId)?.characterId === 'luan', 'o personagem escolhido deve ser sincronizado');

  const before = lastA.players.find((p) => p.sessionId === roomA.sessionId);
  for (let i = 0; i < 16; i++) {
    roomA.send('input', { forward: 1, right: 0, yaw: 0, run: false, jump: false });
    await delay(50);
  }
  await waitFor(() => {
    const p = lastA?.players?.find((item) => item.sessionId === roomA.sessionId);
    return p && Math.hypot(p.x - before.x, p.z - before.z) > 0.6;
  }, 'movimento validado pelo servidor e recebido no snapshot');

  await roomB.leave();
  roomB = null;
  await waitFor(() => lastA?.players?.length === 1, 'remoção do jogador que desconectou');
  console.log(`PASS: dois clientes conectaram à sala ${roomA.roomId}, observaram movimento autoritativo e a desconexão foi removida do estado.`);
} finally {
  await Promise.allSettled([roomA?.leave(), roomB?.leave()]);
}
