import { Room, ServerError } from 'colyseus';
import { generateArenaLayout, isBlocked } from '../../../RetardadosRoyale_Web_v6/shared/arena-layout.js';

const MAX_PLAYERS = 8;
const INPUT_INTERVAL_MS = 18; // throttle message spam; regular clients send at 20 Hz
const PLAYER_IDS = new Set(['enzo', 'luan', 'eduardo', 'custom', 'vincent']);
const ARENA_LIMIT = 252;

function cleanNickname(value) {
  const text = String(value ?? 'JOGADOR').trim().replace(/[^\p{L}\p{N}_]/gu, '').slice(0, 16);
  return text.length >= 3 ? text : 'JOGADOR';
}
function safeCharacter(value) {
  const id = String(value ?? 'enzo').toLowerCase();
  return PLAYER_IDS.has(id) ? id : 'enzo';
}
function finiteNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}
function normalizeAngle(angle) {
  let result = angle;
  while (result > Math.PI) result -= Math.PI * 2;
  while (result < -Math.PI) result += Math.PI * 2;
  return result;
}
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }

export class RoyaleRoom extends Room {
  maxClients = MAX_PLAYERS;

  async onCreate() {
    await this.setMatchmaking({ private: true, metadata: { title: 'Retardados Royale', mode: 'movement-prototype' } });
    this.mapSeed = (Math.floor(Math.random() * 0xffffffff) >>> 0) || 1;
    this.layout = generateArenaLayout(this.mapSeed);
    this.players = new Map();

    this.onMessage('input', (client, payload) => this.receiveInput(client, payload));
    // Fixed, server-owned movement loop; clients send input intent, never positions.
    this.setTimestep((deltaTime) => this.update(deltaTime), 50);
  }

  onAuth(_client, options) {
    if (!options || typeof options !== 'object') throw new ServerError(400, 'Dados de jogador inválidos.');
    return true;
  }

  onJoin(client, options = {}) {
    const slot = this.players.size;
    const angle = slot * (Math.PI * 2 / MAX_PLAYERS);
    const spawnRadius = slot === 0 ? 0 : 5.5;
    const player = {
      sessionId: client.sessionId,
      name: cleanNickname(options.nickname),
      characterId: safeCharacter(options.characterId),
      x: Math.sin(angle) * spawnRadius,
      y: 0,
      z: Math.cos(angle) * spawnRadius,
      yaw: 0,
      cameraYaw: 0,
      speed: 0,
      moving: false,
      running: false,
      jumping: false,
      verticalVelocity: 0,
      grounded: true,
      inputForward: 0,
      inputRight: 0,
      inputRun: false,
      inputJump: false,
      jumpWasDown: false,
      jumpQueued: false,
      lastInputAt: 0,
      lastSeenInputAt: Date.now()
    };
    this.players.set(client.sessionId, player);
    this.broadcastSnapshot();
    console.log(`[room ${this.roomId}] ${player.name} entrou (${this.players.size}/${MAX_PLAYERS})`);
  }

  onLeave(client) {
    const player = this.players.get(client.sessionId);
    if (player) console.log(`[room ${this.roomId}] ${player.name} saiu`);
    this.players.delete(client.sessionId);
    this.broadcastSnapshot();
  }

  receiveInput(client, payload) {
    const player = this.players.get(client.sessionId);
    if (!player || !payload || typeof payload !== 'object') return;
    const now = Date.now();
    if (now - player.lastInputAt < INPUT_INTERVAL_MS) return;
    player.lastInputAt = now;
    player.lastSeenInputAt = now;

    // Clamp all input values and ignore non-finite values. Position is never accepted from the client.
    let forward = clamp(finiteNumber(payload.forward), -1, 1);
    let right = clamp(finiteNumber(payload.right), -1, 1);
    const magnitude = Math.hypot(forward, right);
    if (magnitude > 1) { forward /= magnitude; right /= magnitude; }
    player.inputForward = forward;
    player.inputRight = right;
    player.inputRun = payload.run === true;
    player.cameraYaw = normalizeAngle(finiteNumber(payload.yaw, player.cameraYaw));
    const jumpNow = payload.jump === true;
    if (jumpNow && !player.jumpWasDown) player.jumpQueued = true;
    player.jumpWasDown = jumpNow;
  }

  update(deltaTimeMs) {
    const dt = clamp(finiteNumber(deltaTimeMs, 50) / 1000, 0.001, 0.08);
    const now = Date.now();
    for (const player of this.players.values()) {
      if (now - player.lastSeenInputAt > 350) {
        player.inputForward = 0;
        player.inputRight = 0;
        player.inputRun = false;
        player.jumpWasDown = false;
      }
      const forward = player.inputForward;
      const right = player.inputRight;
      const magnitude = Math.hypot(forward, right);
      const speed = player.inputRun ? 10 : 6.4;
      const fwdX = Math.sin(player.cameraYaw), fwdZ = -Math.cos(player.cameraYaw);
      const rightX = Math.cos(player.cameraYaw), rightZ = Math.sin(player.cameraYaw);
      const vx = (fwdX * forward + rightX * right) * speed;
      const vz = (fwdZ * forward + rightZ * right) * speed;
      const oldX = player.x, oldZ = player.z;
      const nextX = clamp(player.x + vx * dt, -ARENA_LIMIT, ARENA_LIMIT);
      if (!isBlocked(this.layout, nextX, player.z, 0.48)) player.x = nextX;
      const nextZ = clamp(player.z + vz * dt, -ARENA_LIMIT, ARENA_LIMIT);
      if (!isBlocked(this.layout, player.x, nextZ, 0.48)) player.z = nextZ;
      player.speed = Math.hypot(player.x - oldX, player.z - oldZ) / dt;
      player.moving = player.speed > 0.35;
      player.running = player.moving && player.inputRun;

      if (player.jumpQueued && player.grounded) {
        player.verticalVelocity = 7.4;
        player.grounded = false;
      }
      player.jumpQueued = false;
      if (!player.grounded) {
        player.verticalVelocity -= 20 * dt;
        player.y += player.verticalVelocity * dt;
        if (player.y <= 0) { player.y = 0; player.verticalVelocity = 0; player.grounded = true; }
      }
      player.jumping = !player.grounded;
      if (player.moving && !player.jumping) player.yaw = Math.atan2(player.x - oldX, -(player.z - oldZ));
      else player.yaw = player.cameraYaw;
      player.yaw = normalizeAngle(player.yaw);
    }
    this.broadcastSnapshot();
  }

  broadcastSnapshot() {
    const players = [...this.players.values()].map((p) => ({
      sessionId: p.sessionId,
      name: p.name,
      characterId: p.characterId,
      x: p.x, y: p.y, z: p.z,
      yaw: p.yaw,
      speed: p.speed,
      moving: p.moving,
      running: p.running,
      jumping: p.jumping
    }));
    this.broadcast('snapshot', { roomId: this.roomId, mapSeed: this.mapSeed, players });
  }
}
