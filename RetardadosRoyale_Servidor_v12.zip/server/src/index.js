import { createEndpoint, createRouter, defineRoom, defineServer } from 'colyseus';
import { WebSocketTransport } from '@colyseus/ws-transport';
import { RoyaleRoom } from './rooms/RoyaleRoom.js';

const PORT = Number(process.env.PORT || 2567);
const HOST = process.env.HOST || '0.0.0.0';

const gameServer = defineServer({
  rooms: { royale: defineRoom(RoyaleRoom) },
  transport: new WebSocketTransport(),
  routes: createRouter({
    health: createEndpoint('/health', { method: 'GET' }, async () => ({
      ok: true,
      service: 'retardados-royale-colyseus',
      rooms: 'available'
    }))
  })
});

gameServer.listen(PORT, HOST).then(() => {
  console.log(`Retardados Royale multiplayer server listening on ${HOST}:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
}).catch((error) => {
  console.error('Failed to start the Colyseus server:', error);
  process.exitCode = 1;
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, async () => {
    console.log(`Received ${signal}; shutting down Colyseus...`);
    try { await gameServer.gracefullyShutdown(false); }
    catch (error) { console.error('Graceful shutdown failed:', error); }
    finally { process.exit(0); }
  });
}
